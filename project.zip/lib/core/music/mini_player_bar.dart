import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:on_audio_query/on_audio_query.dart';
import '../design_system/tokens/app_colors.dart';
import 'full_player_sheet.dart';
import 'music_controller.dart';
import 'music_library_sheet.dart';

class MiniPlayerBar extends StatelessWidget {
  const MiniPlayerBar({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = MusicController.instance;

    return ValueListenableBuilder<SongModel?>(
      valueListenable: controller.currentSongNotifier,
      builder: (context, currentSong, _) {
        if (currentSong == null) {
          // If no song is playing, show a discrete "Select Workout Music" pill
          return GestureDetector(
            onTap: () => MusicLibrarySheet.show(context),
            child: Container(
              height: 48,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.primaryBlueSoft, width: 1.5),
                boxShadow: const [
                  BoxShadow(
                     color: Color(0x140891B2),
                    blurRadius: 10,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  const Icon(LucideIcons.music4, size: 18, color: AppColors.primaryBlue),
                  const SizedBox(width: 10),
                  Text(
                    'Select Workout Music',
                    style: GoogleFonts.barlowCondensed(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppColors.ink,
                    ),
                  ),
                  const Spacer(),
                  const Icon(LucideIcons.chevronRight, size: 16, color: AppColors.inkSecondary),
                ],
              ),
            ),
          );
        }

        return GestureDetector(
          onTap: () => FullPlayerSheet.show(context),
          child: Container(
            height: 56,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              boxShadow: const [
                BoxShadow(
                   color: Color(0x1A0891B2),
                  blurRadius: 16,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                // Small thumbnail
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    width: 38,
                    height: 38,
                    color: AppColors.primaryBlueSoft,
                    child: QueryArtworkWidget(
                      id: currentSong.id,
                      type: ArtworkType.AUDIO,
                      artworkBorder: BorderRadius.circular(10),
                      artworkFit: BoxFit.cover,
                      nullArtworkWidget: const Center(
                        child: Icon(
                          LucideIcons.music2,
                          size: 18,
                          color: AppColors.primaryBlue,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),

                // Title and Artist marquee
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        currentSong.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.barlowCondensed(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: AppColors.ink,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        (currentSong.artist == null || currentSong.artist == '<unknown>')
                            ? 'Local Track'
                            : currentSong.artist!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.barlowCondensed(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: AppColors.inkSecondary,
                        ),
                      ),
                    ],
                  ),
                ),

                // Play / Pause
                ValueListenableBuilder<bool>(
                  valueListenable: controller.isPlayingNotifier,
                  builder: (context, isPlaying, _) {
                    return IconButton(
                      icon: Icon(
                        isPlaying ? LucideIcons.pause : LucideIcons.play,
                        color: AppColors.ink,
                        size: 20,
                      ),
                      onPressed: () => controller.togglePlayPause(),
                    );
                  },
                ),

                // Next Track
                IconButton(
                  icon: const Icon(
                    LucideIcons.skipForward,
                    color: AppColors.inkSecondary,
                    size: 20,
                  ),
                  onPressed: () => controller.next(),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
