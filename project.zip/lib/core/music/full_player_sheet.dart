import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:on_audio_query/on_audio_query.dart';
import '../design_system/tokens/app_colors.dart';
import 'music_controller.dart';

class FullPlayerSheet extends StatelessWidget {
  const FullPlayerSheet({super.key});

  static Future<void> show(BuildContext context) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const FullPlayerSheet(),
    );
  }

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final controller = MusicController.instance;

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        boxShadow: AppColors.cardShadow,
      ),
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
      child: ValueListenableBuilder<SongModel?>(
        valueListenable: controller.currentSongNotifier,
        builder: (context, currentSong, _) {
          if (currentSong == null) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 44,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.chipGray,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 32),
                const Icon(LucideIcons.music4, size: 48, color: AppColors.inkSecondary),
                const SizedBox(height: 12),
                Text(
                  'No Track Selected',
                  style: GoogleFonts.barlowCondensed(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.ink,
                  ),
                ),
                const SizedBox(height: 24),
              ],
            );
          }

          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle
              Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.chipGray,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 24),

              // Album Art / Music Visual
              Container(
                width: 180,
                height: 180,
                decoration: BoxDecoration(
                  gradient: AppColors.gradientBlue,
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x330891B2),
                      blurRadius: 24,
                      offset: Offset(0, 10),
                    ),
                  ],
                ),
                child: QueryArtworkWidget(
                  id: currentSong.id,
                  type: ArtworkType.AUDIO,
                  artworkBorder: BorderRadius.circular(28),
                  artworkFit: BoxFit.cover,
                  nullArtworkWidget: const Center(
                    child: Icon(
                      LucideIcons.music2,
                      size: 64,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Title & Artist
              Text(
                currentSong.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: GoogleFonts.barlowCondensed(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: AppColors.ink,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                (currentSong.artist == null || currentSong.artist == '<unknown>')
                    ? 'Local Track'
                    : currentSong.artist!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: GoogleFonts.barlowCondensed(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.inkSecondary,
                ),
              ),
              const SizedBox(height: 20),

              // Position & Duration Stream Seek Bar
              StreamBuilder<Duration?>(
                stream: controller.durationStream,
                builder: (context, durSnap) {
                  final totalDuration = durSnap.data ?? Duration(milliseconds: currentSong.duration ?? 0);

                  return StreamBuilder<Duration>(
                    stream: controller.positionStream,
                    builder: (context, posSnap) {
                      final currentPos = posSnap.data ?? Duration.zero;
                      final double maxMs = totalDuration.inMilliseconds > 0
                          ? totalDuration.inMilliseconds.toDouble()
                          : 1.0;
                      final double valMs = currentPos.inMilliseconds.clamp(0, totalDuration.inMilliseconds).toDouble();

                      return Column(
                        children: [
                          SliderTheme(
                            data: SliderTheme.of(context).copyWith(
                              activeTrackColor: AppColors.primaryBlue,
                              inactiveTrackColor: AppColors.chipGray,
                              thumbColor: AppColors.primaryBlue,
                              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                              overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
                              trackHeight: 4.0,
                            ),
                            child: Slider(
                              value: valMs,
                              max: maxMs,
                              onChanged: (v) {
                                controller.seek(Duration(milliseconds: v.toInt()));
                              },
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  _formatDuration(currentPos),
                                  style: GoogleFonts.barlowCondensed(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.inkSecondary,
                                  ),
                                ),
                                Text(
                                  _formatDuration(totalDuration),
                                  style: GoogleFonts.barlowCondensed(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.inkSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
              const SizedBox(height: 12),

              // Transport Controls: Prev, Play/Pause, Next
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    iconSize: 32,
                    icon: const Icon(LucideIcons.skipBack, color: AppColors.ink),
                    onPressed: () => controller.previous(),
                  ),
                  const SizedBox(width: 20),
                  ValueListenableBuilder<bool>(
                    valueListenable: controller.isPlayingNotifier,
                    builder: (context, isPlaying, _) {
                      return GestureDetector(
                        onTap: () => controller.togglePlayPause(),
                        child: Container(
                          width: 64,
                          height: 64,
                          decoration: BoxDecoration(
                            color: AppColors.lime,
                            shape: BoxShape.circle,
                            boxShadow: const [
                              BoxShadow(
                                 color: Color(0x662DD4BF),
                                blurRadius: 16,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Icon(
                            isPlaying ? LucideIcons.pause : LucideIcons.play,
                            color: AppColors.ink,
                            size: 28,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(width: 20),
                  IconButton(
                    iconSize: 32,
                    icon: const Icon(LucideIcons.skipForward, color: AppColors.ink),
                    onPressed: () => controller.next(),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Volume Slider
              ValueListenableBuilder<double>(
                valueListenable: controller.volumeNotifier,
                builder: (context, vol, _) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        const Icon(LucideIcons.volume1, size: 18, color: AppColors.inkSecondary),
                        Expanded(
                          child: SliderTheme(
                            data: SliderTheme.of(context).copyWith(
                              activeTrackColor: AppColors.ink,
                              inactiveTrackColor: AppColors.chipGray,
                              thumbColor: AppColors.ink,
                              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
                              trackHeight: 3.0,
                            ),
                            child: Slider(
                              value: vol,
                              min: 0.0,
                              max: 1.0,
                              onChanged: (v) => controller.setVolume(v),
                            ),
                          ),
                        ),
                        const Icon(LucideIcons.volume2, size: 18, color: AppColors.inkSecondary),
                      ],
                    ),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }
}
