import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:on_audio_query/on_audio_query.dart';
import '../design_system/tokens/app_colors.dart';
import 'music_controller.dart';
import 'music_permission_sheet.dart';

class MusicLibrarySheet extends StatefulWidget {
  const MusicLibrarySheet({super.key});

  static Future<void> show(BuildContext context) async {
    final hasPermission = await MusicController.instance.checkPermissionsAndLoadSongs();
    if (!hasPermission && context.mounted) {
      await MusicPermissionSheet.show(context);
      return;
    }

    if (context.mounted) {
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (_) => const MusicLibrarySheet(),
      );
    }
  }

  @override
  State<MusicLibrarySheet> createState() => _MusicLibrarySheetState();
}

class _MusicLibrarySheetState extends State<MusicLibrarySheet> {
  final TextEditingController _searchController = TextEditingController();
  List<SongModel> _filteredSongs = [];

  @override
  void initState() {
    super.initState();
    _filteredSongs = List.from(MusicController.instance.allSongs);
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase().trim();
    setState(() {
      if (query.isEmpty) {
        _filteredSongs = List.from(MusicController.instance.allSongs);
      } else {
        _filteredSongs = MusicController.instance.allSongs.where((song) {
          final titleMatch = song.title.toLowerCase().contains(query);
          final artistMatch = (song.artist ?? '').toLowerCase().contains(query);
          return titleMatch || artistMatch;
        }).toList();
      }
    });
  }

  String _formatDuration(int? durationMs) {
    if (durationMs == null || durationMs <= 0) return '0:00';
    final duration = Duration(milliseconds: durationMs);
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final controller = MusicController.instance;

    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        boxShadow: AppColors.cardShadow,
      ),
      child: Column(
        children: [
          const SizedBox(height: 16),
          // Drag Handle
          Container(
            width: 44,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.chipGray,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 16),

          // Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Workout Music',
                  style: GoogleFonts.barlowCondensed(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: AppColors.ink,
                  ),
                ),
                IconButton(
                  icon: const Icon(LucideIcons.x, color: AppColors.inkSecondary, size: 20),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Search Field
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: AppColors.surfaceSoft,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.chipGray),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(
                children: [
                  const Icon(LucideIcons.search, color: AppColors.inkSecondary, size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      style: GoogleFonts.barlowCondensed(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.ink,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Search songs or artists...',
                        hintStyle: GoogleFonts.barlowCondensed(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: AppColors.inkSecondary,
                        ),
                        border: InputBorder.none,
                        isDense: true,
                      ),
                    ),
                  ),
                  if (_searchController.text.isNotEmpty)
                    GestureDetector(
                      onTap: () => _searchController.clear(),
                      child: const Icon(LucideIcons.xCircle, color: AppColors.inkSecondary, size: 18),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Song Count Badge
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
            child: Row(
              children: [
                Text(
                  '${_filteredSongs.length} local tracks',
                  style: GoogleFonts.barlowCondensed(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppColors.inkSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),

          // Song List
          Expanded(
            child: _filteredSongs.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(LucideIcons.music, size: 48, color: AppColors.chipGray),
                        const SizedBox(height: 12),
                        Text(
                          'No local tracks found',
                          style: GoogleFonts.barlowCondensed(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: AppColors.ink,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Add audio files to your device storage to play offline',
                          style: GoogleFonts.barlowCondensed(
                            fontSize: 13,
                            color: AppColors.inkSecondary,
                          ),
                        ),
                      ],
                    ),
                  )
                : ValueListenableBuilder<SongModel?>(
                    valueListenable: controller.currentSongNotifier,
                    builder: (context, currentSong, _) {
                      return ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        itemCount: _filteredSongs.length,
                        itemBuilder: (context, index) {
                          final song = _filteredSongs[index];
                          final isSelected = currentSong?.id == song.id;

                          return InkWell(
                            onTap: () {
                              controller.playSong(song, _filteredSongs);
                              Navigator.pop(context);
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 6),
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                              decoration: BoxDecoration(
                                color: isSelected ? AppColors.primaryBlueSoft : Colors.transparent,
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Row(
                                children: [
                                  // Artwork Thumbnail
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: 44,
                                      height: 44,
                                      color: isSelected ? AppColors.primaryBlue : AppColors.chipGray,
                                      child: QueryArtworkWidget(
                                        id: song.id,
                                        type: ArtworkType.AUDIO,
                                        artworkBorder: BorderRadius.circular(10),
                                        artworkFit: BoxFit.cover,
                                        nullArtworkWidget: Center(
                                          child: Icon(
                                            LucideIcons.music,
                                            size: 20,
                                            color: isSelected ? Colors.white : AppColors.inkSecondary,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 14),

                                  // Title and Artist
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          song.title,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.barlowCondensed(
                                            fontSize: 14,
                                            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w700,
                                            color: isSelected ? AppColors.primaryBlue : AppColors.ink,
                                          ),
                                        ),
                                        const SizedBox(height: 3),
                                        Text(
                                          (song.artist == null || song.artist == '<unknown>')
                                              ? 'Local Artist'
                                              : song.artist!,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.barlowCondensed(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.inkSecondary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  // Duration & playing icon
                                  if (isSelected)
                                    const Icon(
                                      LucideIcons.volume2,
                                      color: AppColors.primaryBlue,
                                      size: 18,
                                    )
                                  else
                                    Text(
                                      _formatDuration(song.duration),
                                      style: GoogleFonts.barlowCondensed(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.inkSecondary,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
