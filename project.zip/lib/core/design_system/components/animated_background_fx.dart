import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../tokens/app_colors.dart';

class AnimatedBackgroundFX extends StatefulWidget {
  final Widget child;
  final bool? reduceMotion;

  static final ValueNotifier<bool> reduceMotionNotifier = ValueNotifier<bool>(false);

  const AnimatedBackgroundFX({
    super.key,
    required this.child,
    this.reduceMotion,
  });

  @override
  State<AnimatedBackgroundFX> createState() => _AnimatedBackgroundFXState();
}

class _AnimatedBackgroundFXState extends State<AnimatedBackgroundFX>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 25),
    );

    if (!_effectiveReduceMotion) {
      _controller.repeat();
    }

    AnimatedBackgroundFX.reduceMotionNotifier.addListener(_onMotionPreferenceChanged);
  }

  bool get _effectiveReduceMotion =>
      widget.reduceMotion ?? AnimatedBackgroundFX.reduceMotionNotifier.value;

  void _onMotionPreferenceChanged() {
    if (!mounted) return;
    final motionReduced = _effectiveReduceMotion;
    if (motionReduced && _controller.isAnimating) {
      _controller.stop();
    } else if (!motionReduced && !_controller.isAnimating) {
      _controller.repeat();
    }
    setState(() {});
  }

  @override
  void didUpdateWidget(covariant AnimatedBackgroundFX oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.reduceMotion != oldWidget.reduceMotion) {
      _onMotionPreferenceChanged();
    }
  }

  @override
  void dispose() {
    AnimatedBackgroundFX.reduceMotionNotifier.removeListener(_onMotionPreferenceChanged);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final motionReduced = _effectiveReduceMotion;

    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFFEAF4F8),
                Color(0xFFF3FBFD),
                Color(0xFFDDF6FB),
              ],
            ),
          ),
        ),
        Positioned.fill(
          child: IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0.88, -0.72),
                  radius: 1.2,
                  colors: [
                    AppColors.primaryBlue.withValues(alpha: 0.16),
                    const Color(0xFF67E8F9).withValues(alpha: 0.08),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 0.42, 1.0],
                ),
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(-0.9, 0.9),
                  radius: 1.15,
                  colors: [
                    AppColors.lime.withValues(alpha: 0.12),
                    AppColors.lime.withValues(alpha: 0.04),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 0.42, 1.0],
                ),
              ),
            ),
          ),
        ),
        const Positioned.fill(
          child: IgnorePointer(
            child: RepaintBoundary(
              child: CustomPaint(
                painter: _DotGridPainter(),
              ),
            ),
          ),
        ),
        if (!motionReduced)
          Positioned.fill(
            child: IgnorePointer(
              child: RepaintBoundary(
                child: AnimatedBuilder(
                  animation: _controller,
                  builder: (context, _) {
                    return CustomPaint(
                      painter: _FloatingBlobsPainter(progress: _controller.value),
                    );
                  },
                ),
              ),
            ),
          ),
        widget.child,
      ],
    );
  }
}

class _DotGridPainter extends CustomPainter {
  const _DotGridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    const double step = 28.0;
    const double radius = 1.05;
    final paint = Paint()
      ..color = AppColors.deepNavy.withValues(alpha: 0.045)
      ..style = PaintingStyle.fill;

    for (double y = 14.0; y < size.height; y += step) {
      for (double x = 14.0; x < size.width; x += step) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _FloatingBlobsPainter extends CustomPainter {
  final double progress;

  _FloatingBlobsPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final double angle = progress * 2 * math.pi;

    final double b1CenterX = size.width * (0.28 + 0.12 * math.sin(angle));
    final double b1CenterY = size.height * (0.28 + 0.10 * math.cos(angle));
    final double b1Radius = size.width * 0.42;

    final Paint blob1Paint = Paint()
      ..shader = RadialGradient(
        colors: [
          AppColors.primaryBlue.withValues(alpha: 0.12),
          AppColors.primaryBlue.withValues(alpha: 0.05),
          Colors.transparent,
        ],
        stops: const [0.0, 0.55, 1.0],
      ).createShader(
        Rect.fromCircle(center: Offset(b1CenterX, b1CenterY), radius: b1Radius),
      );

    canvas.drawCircle(Offset(b1CenterX, b1CenterY), b1Radius, blob1Paint);

    final double b2CenterX = size.width * (0.72 - 0.14 * math.cos(angle * 0.8));
    final double b2CenterY = size.height * (0.68 - 0.10 * math.sin(angle * 0.8));
    final double b2Radius = size.width * 0.46;

    final Paint blob2Paint = Paint()
      ..shader = RadialGradient(
        colors: [
          AppColors.lime.withValues(alpha: 0.10),
          AppColors.lime.withValues(alpha: 0.04),
          Colors.transparent,
        ],
        stops: const [0.0, 0.50, 1.0],
      ).createShader(
        Rect.fromCircle(center: Offset(b2CenterX, b2CenterY), radius: b2Radius),
      );

    canvas.drawCircle(Offset(b2CenterX, b2CenterY), b2Radius, blob2Paint);
  }

  @override
  bool shouldRepaint(covariant _FloatingBlobsPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
