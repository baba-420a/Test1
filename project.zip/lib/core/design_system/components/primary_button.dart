import 'package:flutter/material.dart';
import '../tokens/app_colors.dart';
import '../tokens/radii.dart';
import '../tokens/typography.dart';

class PrimaryButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool isLoading;
  final bool isFullWidth;
  final bool isSecondary;
  final bool isBlue;
  final double height;

  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.isLoading = false,
    this.isFullWidth = true,
    this.isSecondary = false,
    this.isBlue = false,
    this.height = 54.0,
  });

  @override
  State<PrimaryButton> createState() => _PrimaryButtonState();
}

class _PrimaryButtonState extends State<PrimaryButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    final isSecondary = widget.isSecondary;
    final isBlue = widget.isBlue;
    final isLoading = widget.isLoading;
    final isFullWidth = widget.isFullWidth;
    final onPressed = widget.onPressed;
    final label = widget.label;
    final icon = widget.icon;
    final height = widget.height;

    Color backgroundColor = isSecondary
        ? AppColors.chipGray
        : (isBlue ? AppColors.primaryBlue : AppColors.lime);
    Color foregroundColor = isSecondary
        ? AppColors.ink
        : (isBlue ? Colors.white : AppColors.ink);

    final buttonChild = isLoading
        ? SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              valueColor: AlwaysStoppedAnimation<Color>(foregroundColor),
            ),
          )
        : Row(
            mainAxisSize: isFullWidth ? MainAxisSize.max : MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 18, color: foregroundColor),
                const SizedBox(width: 8),
              ],
              Text(
                label,
                style: AppTypography.bodyBold.copyWith(
                  color: foregroundColor,
                  fontSize: 16,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          );

    final sized = SizedBox(
      width: isFullWidth ? double.infinity : null,
      height: height,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: (!isSecondary && !isBlue) ? AppColors.mintCtaGradient : null,
          color: (isSecondary || isBlue) ? backgroundColor : null,
          borderRadius: AppRadii.buttonRadius,
          boxShadow: isSecondary
              ? null
              : [
                  BoxShadow(
                    color: (isBlue ? AppColors.primaryBlue : AppColors.lime)
                        .withValues(alpha: 0.32),
                    blurRadius: 18,
                    offset: const Offset(0, 8),
                  ),
                ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: isLoading ? null : onPressed,
            borderRadius: AppRadii.buttonRadius,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Center(child: buttonChild),
            ),
          ),
        ),
      ),
    );

    return Listener(
      onPointerDown: (_) {
        if (onPressed != null && !isLoading) {
          setState(() => _isPressed = true);
        }
      },
      onPointerUp: (_) {
        if (_isPressed) {
          setState(() => _isPressed = false);
        }
      },
      onPointerCancel: (_) {
        if (_isPressed) {
          setState(() => _isPressed = false);
        }
      },
      child: AnimatedScale(
        scale: _isPressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOutCubic,
        child: sized,
      ),
    );
  }
}
