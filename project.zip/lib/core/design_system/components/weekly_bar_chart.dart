import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../../../data/repositories/workout_repository.dart';
import '../tokens/app_colors.dart';
import '../tokens/typography.dart';
import 'app_card.dart';
import 'empty_state.dart';

/// Clean weekly activity bar chart built with fl_chart.
/// Highlights today in Volt accent, renders rounded-top bars, and faint gridlines.
class WeeklyBarChart extends StatelessWidget {
  final List<DayActivity> weeklyActivity;

  const WeeklyBarChart({
    super.key,
    required this.weeklyActivity,
  });

  @override
  Widget build(BuildContext context) {
    final totalWeekReps = weeklyActivity.fold<int>(0, (sum, d) => sum + d.totalReps);
    if (totalWeekReps == 0) {
      return const AppCard(
        padding: EdgeInsets.symmetric(vertical: 32, horizontal: 16),
        child: EmptyState(
          title: 'No workouts this week',
          description: 'Completed reps will graph here day-by-day.',
        ),
      );
    }

    final maxReps = weeklyActivity.fold<int>(1, (max, d) => d.totalReps > max ? d.totalReps : max);
    final maxY = ((maxReps + 10) / 10).ceil() * 10.0;

    return AppCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'WEEKLY REPS',
                    style: AppTypography.overline,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$totalWeekReps reps logged',
                    style: AppTypography.title.copyWith(fontSize: 16),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.surface2,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(
                  'Last 7 Days',
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textSecondary,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 160,
            child: BarChart(
              BarChartData(
                maxY: maxY,
                minY: 0,
                alignment: BarChartAlignment.spaceAround,
                barTouchData: BarTouchData(
                  enabled: true,
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipColor: (_) => AppColors.surface2,
                    getTooltipItem: (group, groupIndex, rod, rodIndex) {
                      final day = weeklyActivity[group.x.toInt()];
                      return BarTooltipItem(
                        '${day.totalReps} reps\n',
                        AppTypography.bodyMedium.copyWith(
                          color: day.isToday ? AppColors.brandAccent : AppColors.textPrimary,
                          fontWeight: FontWeight.w700,
                        ),
                        children: [
                          TextSpan(
                            text: day.dayLabel,
                            style: AppTypography.caption.copyWith(fontSize: 11),
                          ),
                        ],
                      );
                    },
                  ),
                ),
                titlesData: FlTitlesData(
                  show: true,
                  topTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 20,
                      getTitlesWidget: (value, meta) {
                        final index = value.toInt();
                        if (index < 0 || index >= weeklyActivity.length) {
                          return const SizedBox.shrink();
                        }
                        final day = weeklyActivity[index];
                        if (day.totalReps == 0) return const SizedBox.shrink();
                        return Text(
                          '${day.totalReps}',
                          style: AppTypography.caption.copyWith(
                            fontSize: 10,
                            color: day.isToday ? AppColors.brandAccent : AppColors.textSecondary,
                            fontWeight: FontWeight.w700,
                          ),
                        );
                      },
                    ),
                  ),
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 24,
                      getTitlesWidget: (value, meta) {
                        final index = value.toInt();
                        if (index < 0 || index >= weeklyActivity.length) {
                          return const SizedBox.shrink();
                        }
                        final day = weeklyActivity[index];
                        final isToday = day.isToday;
                        return Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(
                            day.dayLabel,
                            style: AppTypography.caption.copyWith(
                              color: isToday ? AppColors.brandAccent : AppColors.textTertiary,
                              fontWeight: isToday ? FontWeight.w800 : FontWeight.w500,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: maxY / 3,
                  getDrawingHorizontalLine: (_) => const FlLine(
                    color: AppColors.border,
                    strokeWidth: 1,
                  ),
                ),
                borderData: FlBorderData(show: false),
                barGroups: List.generate(weeklyActivity.length, (index) {
                  final day = weeklyActivity[index];
                  final isToday = day.isToday;
                  final hasReps = day.totalReps > 0;

                  Color barColor;
                  if (isToday) {
                    barColor = AppColors.lime;
                  } else if (hasReps) {
                    barColor = AppColors.primaryBlue;
                  } else {
                    barColor = AppColors.chipGray;
                  }

                  return BarChartGroupData(
                    x: index,
                    barRods: [
                      BarChartRodData(
                        toY: hasReps ? day.totalReps.toDouble() : maxY * 0.04,
                        color: barColor,
                        width: 18,
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(5)),
                        backDrawRodData: BackgroundBarChartRodData(
                          show: true,
                          toY: maxY,
                          color: AppColors.surface2.withValues(alpha: 0.4),
                        ),
                      ),
                    ],
                  );
                }),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
