import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../../data/models/workout_session.dart';
import '../tokens/app_colors.dart';
import '../tokens/typography.dart';
import 'app_card.dart';
import 'exercise_photo_tile.dart';
import 'form_badge.dart';

/// Recipe-style workout session card directly matching Reference 1 (Component #6):
/// White card, photo top or prominent banner with rounded-16, bold dark title,
/// form badge pill, and meta row with tiny icons (correct, rejected, time, calories) in inkSecondary.
class SessionRow extends StatelessWidget {
  final WorkoutSession session;
  final VoidCallback? onTap;

  const SessionRow({
    super.key,
    required this.session,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final formattedDate = DateFormat('EEE, MMM d • h:mm a').format(session.startTime);
    final minutes = session.durationSeconds ~/ 60;
    final seconds = session.durationSeconds % 60;
    final durationString = minutes > 0 ? '${minutes}m ${seconds}s' : '${seconds}s';

    return AppCard(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Recipe style: Photo + Title + Form Badge row
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Exercise Photo Cutout / Soft Gradient Tile (Component #6)
              ExercisePhotoTile(
                exerciseId: session.exerciseId,
                width: 60,
                height: 60,
                borderRadius: BorderRadius.circular(16),
              ),
              const SizedBox(width: 14),

              // Title and Date
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            session.exerciseName,
                            style: AppTypography.title.copyWith(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                              color: AppColors.ink,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        FormBadge(score: session.averageFormScore),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      formattedDate,
                      style: AppTypography.caption.copyWith(
                        color: AppColors.inkSecondary,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Hairline divider
          Container(
            height: 1,
            color: AppColors.border,
          ),
          const SizedBox(height: 12),

          // Meta row with tiny icons in inkSecondary: correct ✔ / rejected ✘ / duration / calories
          Row(
            children: [
              // Correct reps
              _buildStatMetric(
                icon: LucideIcons.check,
                color: AppColors.success,
                label: '${session.correctReps} correct',
              ),
              const SizedBox(width: 14),

              // Rejected reps (only if > 0)
              if (session.rejectedReps > 0) ...[
                _buildStatMetric(
                  icon: LucideIcons.x,
                  color: AppColors.danger,
                  label: '${session.rejectedReps} rejected',
                ),
                const SizedBox(width: 14),
              ],

              // Duration
              _buildStatMetric(
                icon: LucideIcons.clock,
                color: AppColors.inkSecondary,
                label: durationString,
              ),

              const Spacer(),

              // Chevron
              const Icon(
                LucideIcons.chevronRight,
                size: 16,
                color: AppColors.inkSecondary,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatMetric({
    required IconData icon,
    required Color color,
    required String label,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 13, color: color),
        const SizedBox(width: 4),
        Text(
          label,
          style: AppTypography.caption.copyWith(
            color: AppColors.inkSecondary,
            fontWeight: FontWeight.w600,
            fontSize: 11,
          ),
        ),
      ],
    );
  }
}
