import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../tokens/app_colors.dart';

class SegmentedRingBadge extends StatelessWidget {
  final IconData icon;
  final double size;

  const SegmentedRingBadge({
    super.key,
    required this.icon,
    this.size = 72.0,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(
            size: Size(size, size),
            painter: _SegmentedRingPainter(),
          ),
          Container(
            width: size * 0.68,
            height: size * 0.68,
            decoration: BoxDecoration(
              gradient: AppColors.gradientBlue,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.primaryBlue.withValues(alpha: 0.28),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            alignment: Alignment.center,
            child: Icon(
              icon,
              size: size * 0.32,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

class _SegmentedRingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 3;
    final strokeWidth = size.width * 0.12;

    const segmentCount = 8;
    const gapAngle = 0.12;
    const sweepAngle = (2 * math.pi / segmentCount) - gapAngle;

    final segmentColors = [
      AppColors.lime,
      const Color(0xFF0E7490),
      const Color(0xFF0891B2),
      const Color(0xFF22D3EE),
      const Color(0xFF67E8F9),
      AppColors.lime,
      const Color(0xFF0891B2),
      const Color(0xFF155E75),
    ];

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i < segmentCount; i++) {
      paint.color = segmentColors[i % segmentColors.length];
      final startAngle = -math.pi / 2 + (i * (sweepAngle + gapAngle));
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
