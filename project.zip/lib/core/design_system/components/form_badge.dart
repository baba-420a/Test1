import 'package:flutter/material.dart';
import '../tokens/app_colors.dart';
import '../tokens/radii.dart';
import '../tokens/typography.dart';

class FormBadge extends StatelessWidget {
  final double score;
  final bool showPercent;

  const FormBadge({
    super.key,
    required this.score,
    this.showPercent = true,
  });

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color textColor;
    Color dotColor;

    if (score >= 85.0) {
      bg = AppColors.lime;
      textColor = AppColors.ink;
      dotColor = AppColors.ink;
    } else if (score >= 70.0) {
      bg = const Color(0x28D97706);
      textColor = AppColors.warning;
      dotColor = AppColors.warning;
    } else {
      bg = const Color(0x28E11D48);
      textColor = AppColors.danger;
      dotColor = AppColors.danger;
    }

    final scoreString = score.toInt().toString();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: AppRadii.pillRadius,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: dotColor,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 5),
          Text(
            showPercent ? '$scoreString% Form' : scoreString,
            style: AppTypography.caption.copyWith(
              color: textColor,
              fontWeight: FontWeight.w700,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}
