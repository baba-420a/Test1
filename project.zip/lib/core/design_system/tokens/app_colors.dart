import 'package:flutter/material.dart';

/// Soft-light athletic palette: mist aqua surfaces, ocean ink,
/// cyan pulse accents, and mint energy for CTAs and live cues.
class AppColors {
  AppColors._();

  static const Color pageBackground = Color(0xFFEAF4F8);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceSoft = Color(0xFFF3FBFD);
  static const Color chipGray = Color(0xFFE4F0F4);
  static const Color ink = Color(0xFF0C2230);
  static const Color inkSecondary = Color(0xFF4D6574);
  static const Color primaryBlue = Color(0xFF0891B2);
  static const Color primaryBlueSoft = Color(0xFFCFF4FC);
  static const Color deepNavy = Color(0xFF164E63);
  static const Color lime = Color(0xFF2DD4BF);

  static const Color success = Color(0xFF059669);
  static const Color warning = Color(0xFFD97706);
  static const Color danger = Color(0xFFE11D48);

  static const List<BoxShadow> cardShadow = [
    BoxShadow(
      color: Color(0x140891B2),
      blurRadius: 28,
      offset: Offset(0, 12),
    ),
    BoxShadow(
      color: Color(0x0A0C2230),
      blurRadius: 8,
      offset: Offset(0, 2),
    ),
  ];

  static const List<BoxShadow> softShadow = [
    BoxShadow(
      color: Color(0x120891B2),
      blurRadius: 16,
      offset: Offset(0, 6),
    ),
  ];

  static const LinearGradient gradientBlue = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF083344),
      Color(0xFF0E7490),
      Color(0xFF22D3EE),
    ],
  );

  static const LinearGradient completedDayGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0xFF155E75),
      Color(0xFF0891B2),
    ],
  );

  static const LinearGradient frostedDayGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0xFFF4FBFD),
      Color(0xFFCFFAFE),
    ],
  );

  static const LinearGradient heroPhotoGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0x000C2230),
      Color(0x990C2230),
    ],
  );

  static const LinearGradient mintCtaGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF5EEAD4),
      Color(0xFF2DD4BF),
    ],
  );

  static const Color background = pageBackground;
  static const Color surface1 = surface;
  static const Color surface2 = surfaceSoft;
  static const Color border = Color(0x140891B2);
  static const Color borderFocused = primaryBlue;
  static const Color textPrimary = ink;
  static const Color textSecondary = inkSecondary;
  static const Color textTertiary = Color(0xFF7A93A3);
  static const Color textMuted = inkSecondary;
  static const Color brandAccent = lime;
  static const Color brandAccentDark = ink;
  static const Color surfaceBorder = border;
  static const Color surfaceElevated = surface;
  static const Color primaryAction = lime;
  static const Color primaryActionText = ink;
  static const Color emerald = success;
  static const Color crimson = danger;
  static const Color error = danger;
}
