import 'package:flutter/material.dart';

class AppRadii {
  AppRadii._();

  static const double chip = 999.0;
  static const double tile = 18.0;
  static const double button = 20.0;
  static const double banner = 24.0;
  static const double card = 24.0;
  static const double bottomSheet = 28.0;
  static const double pill = 999.0;

  static const BorderRadius chipRadius = BorderRadius.all(Radius.circular(chip));
  static const BorderRadius tileRadius = BorderRadius.all(Radius.circular(tile));
  static const BorderRadius buttonRadius = BorderRadius.all(Radius.circular(button));
  static const BorderRadius bannerRadius = BorderRadius.all(Radius.circular(banner));
  static const BorderRadius cardRadius = BorderRadius.all(Radius.circular(card));
  static const BorderRadius bottomSheetRadius = BorderRadius.vertical(top: Radius.circular(bottomSheet));
  static const BorderRadius pillRadius = BorderRadius.all(Radius.circular(pill));
}
