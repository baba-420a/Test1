import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/// Athletic type system: condensed display for impact, Barlow for UI body.
class AppTypography {
  AppTypography._();

  static const List<FontFeature> tabularFigures = [
    FontFeature.tabularFigures(),
  ];

  static TextStyle get display => GoogleFonts.barlowCondensed(
        fontSize: 34,
        fontWeight: FontWeight.w800,
        color: AppColors.ink,
        letterSpacing: 0.2,
        height: 1.05,
        fontFeatures: tabularFigures,
      );

  static TextStyle get giantCounter => GoogleFonts.barlowCondensed(
        fontSize: 68,
        fontWeight: FontWeight.w800,
        color: AppColors.ink,
        letterSpacing: -0.4,
        height: 1.0,
        fontFeatures: tabularFigures,
      );

  static TextStyle get marketingHeadline => GoogleFonts.barlowCondensed(
        fontSize: 36,
        fontWeight: FontWeight.w800,
        color: Colors.white,
        letterSpacing: 0.4,
        height: 1.08,
      );

  static TextStyle get headline => GoogleFonts.barlowCondensed(
        fontSize: 24,
        fontWeight: FontWeight.w800,
        color: AppColors.ink,
        letterSpacing: 0.2,
        fontFeatures: tabularFigures,
      );

  static TextStyle get title => GoogleFonts.barlowCondensed(
        fontSize: 18,
        fontWeight: FontWeight.w700,
        color: AppColors.ink,
        letterSpacing: 0.15,
      );

  static TextStyle get body => GoogleFonts.barlow(
        fontSize: 15,
        fontWeight: FontWeight.w400,
        color: AppColors.inkSecondary,
        height: 1.5,
      );

  static TextStyle get bodyMedium => GoogleFonts.barlow(
        fontSize: 15,
        fontWeight: FontWeight.w600,
        color: AppColors.ink,
      );

  static TextStyle get bodyBold => GoogleFonts.barlow(
        fontSize: 15,
        fontWeight: FontWeight.w700,
        color: AppColors.ink,
      );

  static TextStyle get caption => GoogleFonts.barlow(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: AppColors.inkSecondary,
        height: 1.35,
      );

  static TextStyle get overline => GoogleFonts.barlow(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: AppColors.inkSecondary,
        letterSpacing: 1.6,
      );

  static TextStyle get titleMedium => title;
  static TextStyle get titleLarge => headline;
  static TextStyle get titleSmall => title.copyWith(fontSize: 15);
  static TextStyle get displayLarge => display;
  static TextStyle get displayMedium => display;
  static TextStyle get bodySmall => caption;
  static TextStyle get sectionHeader => overline;
  static TextStyle get repCounter => giantCounter;
  static TextStyle get statNumber => display;
}
