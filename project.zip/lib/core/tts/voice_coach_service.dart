import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/design_system/tokens/app_colors.dart';

class VoiceCoachService {
  VoiceCoachService._internal();
  static final VoiceCoachService instance = VoiceCoachService._internal();

  final FlutterTts _flutterTts = FlutterTts();
  bool _isInitialized = false;
  bool _isEnabled = true;
  double _speechRate = 0.5; // FlutterTts normal speed is 0.5
  DateTime? _lastSpeechTime;
  String? _lastSpokenCue;

  /// Hook for music player volume ducking (Change 4 & 5 integration)
  static void Function(bool duck)? onDuckMusic;

  bool get isEnabled => _isEnabled;
  double get speechRate => _speechRate;

  Future<void> init() async {
    if (_isInitialized) return;

    try {
      await _flutterTts.setLanguage('en-US');
      await _flutterTts.setSpeechRate(_speechRate);
      await _flutterTts.setVolume(1.0);
      await _flutterTts.setPitch(1.0);

      _flutterTts.setStartHandler(() {
        onDuckMusic?.call(true);
      });

      _flutterTts.setCompletionHandler(() {
        onDuckMusic?.call(false);
      });

      _flutterTts.setCancelHandler(() {
        onDuckMusic?.call(false);
      });

      _flutterTts.setErrorHandler((_) {
        onDuckMusic?.call(false);
      });

      _isInitialized = true;
    } catch (e) {
      debugPrint('VoiceCoachService init error: $e');
    }
  }

  void setEnabled(bool enabled) {
    _isEnabled = enabled;
    if (!enabled) {
      stop();
    }
  }

  Future<void> setSpeechRate(double rate) async {
    // Normalizes 0.5 - 1.5 multiplier down to 0.25 - 0.75 for flutter_tts
    _speechRate = (rate * 0.5).clamp(0.2, 0.9);
    try {
      await _flutterTts.setSpeechRate(_speechRate);
    } catch (_) {}
  }

  /// Checks if device has an active TTS engine installed
  Future<bool> hasTtsEngine() async {
    try {
      final dynamic engines = await _flutterTts.getEngines;
      final dynamic defaultEngine = await _flutterTts.getDefaultEngine;
      if (defaultEngine != null && defaultEngine.toString().isNotEmpty) {
        return true;
      }
      if (engines is List && engines.isNotEmpty) {
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error checking TTS engine: $e');
      return true; // Fallback to avoid false negatives on restricted OEM ROMs
    }
  }

  /// Shows the fallback dialog when speech engine is missing
  static Future<void> showMissingEngineDialog(BuildContext context) async {
    if (!context.mounted) return;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Voice coach needs a speech engine',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 18,
            color: AppColors.ink,
          ),
        ),
        content: const Text(
          'Your device does not have a text-to-speech engine configured. Install Google Speech Services or enable TTS in system settings to hear live rep counts and form warnings.',
          style: TextStyle(
            fontSize: 14,
            height: 1.4,
            color: AppColors.inkSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              const marketUri = 'market://details?id=com.google.android.tts';
              const webUri = 'https://play.google.com/store/apps/details?id=com.google.android.tts';
              final uri = Uri.parse(marketUri);
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              } else {
                await launchUrl(Uri.parse(webUri), mode: LaunchMode.externalApplication);
              }
            },
            child: const Text(
              'Install Google TTS',
              style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.primaryBlue),
            ),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              try {
                const channel = MethodChannel('com.fitnessapp.fitness_app/settings');
                await channel.invokeMethod('openTtsSettings');
              } catch (_) {}
            },
            child: const Text(
              'Open TTS settings',
              style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.ink),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> stop() async {
    try {
      await _flutterTts.stop();
    } catch (_) {}
    onDuckMusic?.call(false);
  }

  /// Speaks cue with throttling and warning interruption rules
  Future<void> speak(String text, {bool isWarning = false}) async {
    if (!_isEnabled || text.trim().isEmpty) return;
    await init();

    final now = DateTime.now();

    // Warnings interrupt immediately by calling stop() first
    if (isWarning) {
      // Avoid rapid looping of the exact same warning within 1.5s
      if (_lastSpokenCue == text && _lastSpeechTime != null && now.difference(_lastSpeechTime!).inMilliseconds < 1500) {
        return;
      }
      await stop();
      _lastSpeechTime = now;
      _lastSpokenCue = text;
      await _flutterTts.speak(text);
      return;
    }

    // Standard cues throttle at minimum 1.2s between utterances
    if (_lastSpeechTime != null && now.difference(_lastSpeechTime!).inMilliseconds < 1200) {
      return;
    }

    _lastSpeechTime = now;
    _lastSpokenCue = text;
    await _flutterTts.speak(text);
  }

  /// Session countdown "3, 2, 1, go"
  Future<void> speakCountdown(String count) async {
    await speak(count, isWarning: true);
  }

  /// Rep count number
  Future<void> speakRep(int repNumber) async {
    await speak('$repNumber');
  }

  /// Form warning cues: "Go deeper", "Keep your back straight", "Keep lower body still", etc.
  Future<void> speakWarning(String warning) async {
    await speak(warning, isWarning: true);
  }

  /// Rep rejected cue
  Future<void> speakRejected([String? reason]) async {
    await speak('Not counted', isWarning: true);
  }

  /// Session end summary
  Future<void> speakSessionEnd(int correctReps, int rejectedReps) async {
    await stop();
    final summary = 'Workout complete. $correctReps good reps, $rejectedReps rejected.';
    await speak(summary, isWarning: true);
  }
}
