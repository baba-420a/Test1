import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../core/design_system/components/animated_background_fx.dart';
import '../../core/design_system/components/app_card.dart';
import '../../core/design_system/components/primary_button.dart';
import '../../core/design_system/components/section_header.dart';
import '../../core/design_system/components/segmented_ring_badge.dart';
import '../../core/design_system/components/stat_tile.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../data/models/workout_session.dart';
import '../../data/repositories/workout_repository.dart';

class SessionSummaryScreen extends StatefulWidget {
  final Map<String, dynamic>? sessionData;

  const SessionSummaryScreen({super.key, this.sessionData});

  @override
  State<SessionSummaryScreen> createState() => _SessionSummaryScreenState();
}

class _SessionSummaryScreenState extends State<SessionSummaryScreen> {
  bool _isSaved = false;

  @override
  void initState() {
    super.initState();
    _saveSessionLocally();
  }

  Future<void> _saveSessionLocally() async {
    if (_isSaved) return;
    final sessionData = widget.sessionData;
    if (sessionData == null) return;
    _isSaved = true;

    final exerciseId = sessionData['exerciseId'] as String? ?? 'squats';
    final exerciseName = sessionData['exerciseName'] as String? ?? 'Exercise';
    final durationSeconds = sessionData['durationSeconds'] as int? ?? 0;
    final correctReps = sessionData['correctReps'] as int? ?? 0;
    final rejectedReps = sessionData['rejectedReps'] as int? ?? 0;
    final avgScore = (sessionData['averageFormScore'] as num?)?.toDouble() ?? 0.0;
    final calories = (sessionData['estimatedCalories'] as num?)?.toDouble() ?? 0.0;

    final now = DateTime.now();
    final session = WorkoutSession(
      id: 'session_${now.millisecondsSinceEpoch}',
      exerciseId: exerciseId,
      exerciseName: exerciseName,
      startTime: now.subtract(Duration(seconds: durationSeconds)),
      endTime: now,
      durationSeconds: durationSeconds,
      totalAttempts: correctReps + rejectedReps,
      correctReps: correctReps,
      rejectedReps: rejectedReps,
      averageFormScore: avgScore,
      estimatedCalories: calories,
      notes: rejectedReps == 0
          ? 'Exceptional form and full range of motion maintained throughout.'
          : '$rejectedReps rep(s) flagged for incomplete joint range or posture deviation.',
    );

    await WorkoutRepository.saveSession(session);
  }

  @override
  Widget build(BuildContext context) {
    final sessionData = widget.sessionData;
    final exerciseName = sessionData?['exerciseName'] as String? ?? 'Workout Session';
    final durationSeconds = sessionData?['durationSeconds'] as int? ?? 0;
    final correctReps = sessionData?['correctReps'] as int? ?? 0;
    final rejectedReps = sessionData?['rejectedReps'] as int? ?? 0;
    final avgScore = (sessionData?['averageFormScore'] as num?)?.toDouble() ?? 0.0;
    final calories = (sessionData?['estimatedCalories'] as num?)?.toDouble() ?? 0.0;

    final minutes = durationSeconds ~/ 60;
    final seconds = durationSeconds % 60;
    final durationStr = minutes > 0 ? '${minutes}m ${seconds}s' : '${seconds}s';

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark.copyWith(
        statusBarColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: AnimatedBackgroundFX(
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 12),

                // Floating Segmented Ring Badge Award
                const Center(
                  child: SegmentedRingBadge(
                    icon: LucideIcons.award,
                    size: 84,
                  ),
                ),
                const SizedBox(height: 18),

                Text(
                  'Workout Complete',
                  style: GoogleFonts.barlowCondensed(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: AppColors.ink,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppColors.chipGray,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    exerciseName,
                    style: AppTypography.caption.copyWith(
                      color: AppColors.ink,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(height: 28),

                // Performance Breakdown Card
                const SectionHeader(title: 'Session Summary'),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: StatTile(
                        label: 'Correct Reps',
                        value: '$correctReps',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: StatTile(
                        label: 'Form Score',
                        value: '${avgScore.toInt()}%',
                        subtitle: avgScore >= 85
                            ? 'Optimal'
                            : (avgScore >= 70 ? 'Satisfactory' : 'Needs Review'),
                        subtitleColor: avgScore >= 85 ? AppColors.success : AppColors.warning,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: StatTile(
                        label: 'Duration',
                        value: durationStr,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: StatTile(
                        label: 'Est. Calories',
                        value: '${calories.toStringAsFixed(1)} kcal',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Flagged Reps Card (if any rejected reps)
                if (rejectedReps > 0)
                  AppCard(
                    borderRadius: BorderRadius.circular(16),
                    child: Row(
                      children: [
                        const Icon(LucideIcons.triangleAlert, color: AppColors.danger, size: 20),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            '$rejectedReps rep(s) were flagged for incomplete range of motion or form deviation.',
                            style: AppTypography.caption.copyWith(
                              color: AppColors.inkSecondary,
                              height: 1.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 32),

                // Action Buttons
                PrimaryButton(
                  label: 'Save & Return to Dashboard',
                  icon: LucideIcons.home,
                  height: 52,
                  onPressed: () async {
                    await _saveSessionLocally();
                    if (context.mounted) context.go('/home');
                  },
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () async {
                      await _saveSessionLocally();
                      if (context.mounted) context.go('/history');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.chipGray,
                      foregroundColor: AppColors.ink,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    child: Text(
                      'View Workout History',
                      style: GoogleFonts.barlowCondensed(
                        color: AppColors.ink,
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
