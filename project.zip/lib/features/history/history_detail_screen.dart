import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../core/design_system/components/app_card.dart';
import '../../core/design_system/components/form_badge.dart';
import '../../core/design_system/components/primary_button.dart';
import '../../core/design_system/components/section_header.dart';
import '../../core/design_system/components/stat_tile.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../data/models/workout_session.dart';
import '../../data/repositories/workout_repository.dart';

class HistoryDetailScreen extends StatelessWidget {
  final String sessionId;

  const HistoryDetailScreen({super.key, required this.sessionId});

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('EEEE, MMMM d, yyyy');
    final timeFormat = DateFormat('h:mm a');

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark.copyWith(
        statusBarColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: AppColors.pageBackground,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          scrolledUnderElevation: 0,
          leading: IconButton(
            icon: const Icon(LucideIcons.arrowLeft, color: AppColors.ink, size: 22),
            onPressed: () => context.pop(),
          ),
          title: Text(
            'Workout Summary',
            style: GoogleFonts.barlowCondensed(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(LucideIcons.trash2, color: AppColors.inkSecondary, size: 20),
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: AppColors.surface,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    title: Text(
                      'Delete Session?',
                      style: GoogleFonts.barlowCondensed(
                        color: AppColors.ink,
                        fontWeight: FontWeight.w800,
                        fontSize: 18,
                      ),
                    ),
                    content: Text(
                      'This workout record will be permanently deleted from your history.',
                      style: AppTypography.body.copyWith(color: AppColors.inkSecondary),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: Text(
                          'Cancel',
                          style: AppTypography.body.copyWith(
                            color: AppColors.inkSecondary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: Text(
                          'Delete',
                          style: AppTypography.body.copyWith(
                            color: AppColors.danger,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
                if (confirm == true) {
                  await WorkoutRepository.deleteSession(sessionId);
                  if (context.mounted) context.pop();
                }
              },
            ),
          ],
        ),
        body: FutureBuilder<WorkoutSession?>(
          future: WorkoutRepository.getSessionById(sessionId),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(color: AppColors.primaryBlue),
              );
            }

            final session = snapshot.data;
            if (session == null) {
              return Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(LucideIcons.alertCircle, size: 48, color: AppColors.warning),
                    const SizedBox(height: 16),
                    Text('Session Not Found', style: AppTypography.title),
                    const SizedBox(height: 16),
                    PrimaryButton(
                      label: 'Go Back',
                      isFullWidth: false,
                      onPressed: () => context.pop(),
                    ),
                  ],
                ),
              );
            }

            final durationMin = session.durationSeconds ~/ 60;
            final durationSec = session.durationSeconds % 60;
            final durationStr = durationMin > 0 ? '${durationMin}m ${durationSec}s' : '${durationSec}s';

            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Session Header Card
                  AppCard(
                    borderRadius: BorderRadius.circular(24),
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    session.exerciseName,
                                    style: GoogleFonts.barlowCondensed(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w800,
                                      color: AppColors.ink,
                                      letterSpacing: -0.4,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    children: [
                                      const Icon(
                                        LucideIcons.calendar,
                                        size: 14,
                                        color: AppColors.inkSecondary,
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        dateFormat.format(session.startTime),
                                        style: AppTypography.caption.copyWith(
                                          color: AppColors.inkSecondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Row(
                                    children: [
                                      const Icon(
                                        LucideIcons.clock,
                                        size: 14,
                                        color: AppColors.inkSecondary,
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        '${timeFormat.format(session.startTime)} – ${timeFormat.format(session.endTime)}',
                                        style: AppTypography.caption.copyWith(
                                          color: AppColors.inkSecondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            FormBadge(score: session.averageFormScore),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Metrics Grid
                  const SectionHeader(title: 'Performance Breakdown'),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: StatTile(
                          label: 'Correct Reps',
                          value: '${session.correctReps}',
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: StatTile(
                          label: 'Rejected Reps',
                          value: '${session.rejectedReps}',
                          valueColor: session.rejectedReps > 0
                              ? AppColors.danger
                              : AppColors.ink,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: StatTile(
                          label: 'Duration',
                          value: durationStr,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: StatTile(
                          label: 'Est. Calories',
                          value: '${session.estimatedCalories.toStringAsFixed(1)} kcal',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Coaching / Form Analysis Notes
                  const SectionHeader(title: 'AI Form Analysis'),
                  const SizedBox(height: 12),
                  AppCard(
                    borderRadius: BorderRadius.circular(20),
                    padding: const EdgeInsets.all(18),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            color: AppColors.primaryBlueSoft,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          alignment: Alignment.center,
                          child: const Icon(
                            LucideIcons.sparkles,
                            color: AppColors.primaryBlue,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Biomechanics Summary',
                                style: GoogleFonts.barlowCondensed(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.ink,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                session.notes ??
                                    'Clean repetition cadence and controlled eccentric contraction recorded.',
                                style: AppTypography.body.copyWith(
                                  color: AppColors.inkSecondary,
                                  height: 1.45,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Action to restart exercise
                  PrimaryButton(
                    label: 'Repeat This Exercise',
                    icon: LucideIcons.play,
                    height: 52,
                    onPressed: () => context.push('/live-workout/${session.exerciseId}'),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
