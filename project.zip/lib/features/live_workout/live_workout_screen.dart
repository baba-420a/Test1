import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../core/design_system/components/floating_stat_chip.dart';
import '../../core/design_system/components/primary_button.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../core/permissions/permission_service.dart';
import '../../data/models/exercise.dart';
import '../../pose/pose_engine.dart';
import '../../pose/pose_landmark.dart';
import '../../pose/pose_painter.dart';
import '../../pose/rep_counter.dart';
import '../../core/tts/voice_coach_service.dart';
import '../../core/music/mini_player_bar.dart';
import '../../core/music/music_library_sheet.dart';
import '../../data/repositories/user_profile_repository.dart';

class LiveWorkoutScreen extends StatefulWidget {
  final String exerciseId;

  const LiveWorkoutScreen({super.key, required this.exerciseId});

  @override
  State<LiveWorkoutScreen> createState() => _LiveWorkoutScreenState();
}

class _LiveWorkoutScreenState extends State<LiveWorkoutScreen> {
  late Exercise _exercise;

  // Camera & Detection
  List<CameraDescription> _availableCameras = [];
  CameraController? _cameraController;
  int _selectedCameraIndex = 0;
  bool _isCameraInitialized = false;
  bool _isProcessingFrame = false;
  bool _hasCameraPermission = true;

  // Pose Engine & Rep Counter
  final MlKitPoseEngine _poseEngine = MlKitPoseEngine();
  late AutomaticRepCounter _repCounter;
  List<PoseLandmark> _currentLandmarks = [];

  // Workout state
  bool _isWorkoutActive = false;
  bool _isPaused = false;
  int _secondsElapsed = 0;
  Timer? _timer;
  Timer? _countdownTimer;
  int _countdown = 0;

  RepCounterResult _repState = const RepCounterResult(
    correctReps: 0,
    rejectedReps: 0,
    currentPhase: MovementPhase.idle,
    formScore: 100,
    feedbackMessage: 'Step back into frame and press Start',
    isPersonDetected: false,
  );

  int _lastCorrectCount = 0;
  int _lastRejectedCount = 0;

  @override
  void initState() {
    super.initState();
    _exercise = Exercise.defaultExercises.firstWhere(
      (e) => e.id == widget.exerciseId,
      orElse: () => Exercise.defaultExercises.first,
    );

    _repCounter = AutomaticRepCounter(exerciseId: _exercise.id);
    UserProfileRepository.getUserProfile().then((profile) {
      VoiceCoachService.instance.setEnabled(profile.audioFeedbackEnabled);
      VoiceCoachService.instance.setSpeechRate(profile.speechRate);
    });
    _initCamera();
  }

  Future<void> _initCamera() async {
    final hasPermission = await PermissionService.isCameraGranted();
    if (!hasPermission) {
      final granted = await PermissionService.requestCamera();
      if (!granted) {
        if (mounted) {
          setState(() {
            _hasCameraPermission = false;
          });
        }
        return;
      }
    }

    try {
      _availableCameras = await availableCameras();
      if (_availableCameras.isEmpty) {
        if (mounted) {
          setState(() {
            _hasCameraPermission = false;
          });
        }
        return;
      }

      _selectedCameraIndex = _availableCameras.indexWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
      );
      if (_selectedCameraIndex == -1) {
        _selectedCameraIndex = 0;
      }

      await _setupCameraController(_availableCameras[_selectedCameraIndex]);
      await _poseEngine.initialize();
    } catch (e) {
      debugPrint('Error initializing camera: $e');
      if (mounted) {
        setState(() {
          _isCameraInitialized = false;
        });
      }
    }
  }

  Future<void> _setupCameraController(CameraDescription camera) async {
    await _cameraController?.dispose();

    final controller = CameraController(
      camera,
      ResolutionPreset.medium,
      enableAudio: false,
      imageFormatGroup: defaultTargetPlatform == TargetPlatform.android
          ? ImageFormatGroup.nv21
          : ImageFormatGroup.bgra8888,
    );

    _cameraController = controller;

    try {
      await controller.initialize();
      if (!mounted) return;

      setState(() {
        _isCameraInitialized = true;
        _hasCameraPermission = true;
      });

      _startPoseStream();
    } catch (e) {
      debugPrint('Error starting camera controller: $e');
    }
  }

  void _startPoseStream() {
    if (_cameraController == null || !_cameraController!.value.isInitialized) return;

    _cameraController!.startImageStream((CameraImage image) async {
      if (_isProcessingFrame || !_isWorkoutActive || _isPaused) return;

      _isProcessingFrame = true;

      try {
        final landmarks = await _poseEngine.processCameraImage(
          image,
          _cameraController!.description,
          DeviceOrientation.portraitUp,
        );

        if (mounted) {
          final result = _repCounter.processLandmarks(landmarks);

          // Haptic & Voice coach on rep completion
          if (result.correctReps > _lastCorrectCount) {
            HapticFeedback.mediumImpact();
            _lastCorrectCount = result.correctReps;
            VoiceCoachService.instance.speakRep(result.correctReps);
          } else if (result.rejectedReps > _lastRejectedCount) {
            _lastRejectedCount = result.rejectedReps;
            VoiceCoachService.instance.speakRejected();
          } else if (result.feedbackMessage.isNotEmpty) {
            final msg = result.feedbackMessage;
            if (msg.contains('Go deeper') ||
                msg.contains('Keep lower body still') ||
                msg.contains('Keep your back straight') ||
                msg.contains('Hips too low') ||
                msg.contains('Lift your hips less') ||
                msg.contains('Full lockout') ||
                msg.contains('Hands under shoulders')) {
              VoiceCoachService.instance.speakWarning(msg);
            }
          }

          setState(() {
            _currentLandmarks = landmarks;
            _repState = result;
          });
        }
      } catch (e) {
        debugPrint('Pose processing error: $e');
      } finally {
        _isProcessingFrame = false;
      }
    });
  }

  Future<void> _switchCamera() async {
    if (_availableCameras.length < 2) return;

    _selectedCameraIndex = (_selectedCameraIndex + 1) % _availableCameras.length;
    await _setupCameraController(_availableCameras[_selectedCameraIndex]);
  }

  void _startWorkout() {
    if (_countdown > 0) return;

    setState(() {
      _countdown = 3;
      _isPaused = false;
      _secondsElapsed = 0;
      _lastCorrectCount = 0;
      _lastRejectedCount = 0;
      _repCounter.reset();
    });

    VoiceCoachService.instance.speakCountdown('3');

    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_countdown > 1) {
        setState(() {
          _countdown--;
        });
        VoiceCoachService.instance.speakCountdown('$_countdown');
      } else if (_countdown == 1) {
        setState(() {
          _countdown = 0;
          _isWorkoutActive = true;
        });
        VoiceCoachService.instance.speakCountdown('Go');
        _countdownTimer?.cancel();

        _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
          if (!_isPaused && mounted) {
            setState(() {
              _secondsElapsed++;
            });
          }
        });
      }
    });
  }

  void _pauseWorkout() {
    setState(() {
      _isPaused = !_isPaused;
    });
  }

  void _stopAndFinishWorkout() {
    _timer?.cancel();
    _countdownTimer?.cancel();

    VoiceCoachService.instance.speakSessionEnd(
      _repState.correctReps,
      _repState.rejectedReps,
    );

    context.pushReplacement(
      '/session-summary',
      extra: {
        'exerciseId': _exercise.id,
        'exerciseName': _exercise.name,
        'durationSeconds': _secondsElapsed,
        'correctReps': _repState.correctReps,
        'rejectedReps': _repState.rejectedReps,
        'averageFormScore': _repState.formScore,
        'estimatedCalories': _repState.correctReps * _exercise.caloriesPerRep,
      },
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _countdownTimer?.cancel();
    VoiceCoachService.instance.stop();
    if (_cameraController != null && _cameraController!.value.isStreamingImages) {
      _cameraController!.stopImageStream();
    }
    _cameraController?.dispose();
    _poseEngine.dispose();
    super.dispose();
  }

  Widget _buildIconButton({required IconData icon, required VoidCallback onPressed}) {
    return Container(
      width: 44,
      height: 44,
      decoration: const BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Color(0x1A0891B2),
            blurRadius: 14,
            offset: Offset(0, 4),
          ),
        ],
      ),
      alignment: Alignment.center,
      child: IconButton(
        icon: Icon(icon, color: AppColors.ink, size: 20),
        onPressed: onPressed,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final minutes = _secondsElapsed ~/ 60;
    final seconds = _secondsElapsed % 60;
    final timeFormatted = '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
    final isFrontCam = _availableCameras.isNotEmpty &&
        _availableCameras[_selectedCameraIndex].lensDirection == CameraLensDirection.front;

    // Feedback banner styling: lime (good rep), warning, danger (rejected) with dark/white bold text
    Color bannerBg;
    Color bannerTextColor;
    IconData bannerIcon;

    if (_repState.rejectedReps > 0 || _repState.formScore < 70) {
      bannerBg = AppColors.danger;
      bannerTextColor = Colors.white;
      bannerIcon = LucideIcons.alertCircle;
    } else if (!_repState.isPersonDetected) {
      bannerBg = AppColors.warning;
      bannerTextColor = AppColors.ink;
      bannerIcon = LucideIcons.userX;
    } else {
      bannerBg = AppColors.lime;
      bannerTextColor = AppColors.ink;
      bannerIcon = LucideIcons.checkCircle2;
    }

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark.copyWith(
        statusBarColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: AppColors.pageBackground,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Column(
              children: [
                // Top Navigation Bar: Close button, Timer & Exercise Name, Camera Flip
                Row(
                  children: [
                    _buildIconButton(
                      icon: LucideIcons.x,
                      onPressed: () {
                        if (_isWorkoutActive) {
                          _stopAndFinishWorkout();
                        } else {
                          context.pop();
                        }
                      },
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(999),
                          boxShadow: const [
                            BoxShadow(
                               color: Color(0x140891B2),
                              blurRadius: 12,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              _exercise.name,
                              style: GoogleFonts.barlowCondensed(
                                color: AppColors.ink,
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                              ),
                            ),
                            Row(
                              children: [
                                const Icon(
                                  LucideIcons.clock,
                                  size: 13,
                                  color: AppColors.primaryBlue,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  timeFormatted,
                                  style: GoogleFonts.barlowCondensed(
                                    color: AppColors.primaryBlue,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    _buildIconButton(
                      icon: LucideIcons.music4,
                      onPressed: () => MusicLibrarySheet.show(context),
                    ),
                    const SizedBox(width: 8),
                    _buildIconButton(
                      icon: LucideIcons.refreshCw,
                      onPressed: _switchCamera,
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // Player Card: White rounded-24 card framing camera preview inside rounded-20
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: AppColors.cardShadow,
                    ),
                    padding: const EdgeInsets.all(8),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Stack(
                        children: [
                          // 1. Camera Viewport
                          Positioned.fill(
                            child: _buildCameraViewport(isFrontCam),
                          ),

                          // 2. Floating Stat Chips (Component #4)
                          // Reps floating chip top-left
                          Positioned(
                            top: 12,
                            left: 12,
                            child: FloatingStatChip(
                              value: '${_repState.correctReps}',
                              unit: 'reps',
                              label: 'Total Lockout',
                              icon: LucideIcons.flame,
                              iconColor: AppColors.primaryBlue,
                              intensityLevel: _repState.correctReps == 0
                                  ? 1
                                  : ((_repState.correctReps - 1) % 5) + 1,
                            ),
                          ),

                          // Form Score floating chip top-right
                          Positioned(
                            top: 12,
                            right: 12,
                            child: FloatingStatChip(
                              value: '${_repState.formScore.toInt()}',
                              unit: '%',
                              label: 'AI Form Score',
                              icon: LucideIcons.heart,
                              iconColor: _repState.formScore >= 70 ? AppColors.lime : AppColors.danger,
                              intensityLevel: (_repState.formScore / 20).clamp(1, 5).toInt(),
                            ),
                          ),

                          // 3. Joint Angle badge bottom-right
                          if (_repState.currentAngle > 0 && _repState.currentAngle < 180)
                            Positioned(
                              bottom: 12,
                              right: 12,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.7),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  '${_repState.currentAngle.toInt()}°',
                                  style: GoogleFonts.barlowCondensed(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ),

                          // 4. Session Countdown Overlay
                          if (_countdown > 0)
                            Positioned.fill(
                              child: Container(
                                color: Colors.black.withValues(alpha: 0.45),
                                alignment: Alignment.center,
                                child: Container(
                                  width: 110,
                                  height: 110,
                                  decoration: BoxDecoration(
                                    color: AppColors.ink.withValues(alpha: 0.85),
                                    shape: BoxShape.circle,
                                    border: Border.all(color: AppColors.lime, width: 3),
                                    boxShadow: const [
                                      BoxShadow(
                                         color: Color(0x662DD4BF),
                                        blurRadius: 20,
                                        spreadRadius: 4,
                                      ),
                                    ],
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    '$_countdown',
                                    style: GoogleFonts.barlowCondensed(
                                      fontSize: 52,
                                      fontWeight: FontWeight.w900,
                                      color: AppColors.lime,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                // Real-Time Feedback Banner: Lime (good rep), Warning, Danger (rejected) with bold text
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: bannerBg,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: const [
                      BoxShadow(
                         color: Color(0x1A0C2230),
                        blurRadius: 14,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(bannerIcon, size: 18, color: bannerTextColor),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _repState.feedbackMessage,
                          textAlign: TextAlign.center,
                          style: GoogleFonts.barlowCondensed(
                            color: bannerTextColor,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                const MiniPlayerBar(),
                const SizedBox(height: 12),

                // Bottom Workout Controls: Start / Pause / Finish
                if (_isWorkoutActive)
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 52,
                          child: ElevatedButton.icon(
                            onPressed: _pauseWorkout,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.chipGray,
                              foregroundColor: AppColors.ink,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                            icon: Icon(
                              _isPaused ? LucideIcons.play : LucideIcons.pause,
                              size: 18,
                              color: AppColors.ink,
                            ),
                            label: Text(
                              _isPaused ? 'Resume' : 'Pause',
                              style: GoogleFonts.barlowCondensed(
                                color: AppColors.ink,
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: SizedBox(
                          height: 52,
                          child: ElevatedButton.icon(
                            onPressed: _stopAndFinishWorkout,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.lime,
                              foregroundColor: AppColors.ink,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                            icon: const Icon(LucideIcons.check, size: 18, color: AppColors.ink),
                            label: Text(
                              'Finish',
                              style: GoogleFonts.barlowCondensed(
                                color: AppColors.ink,
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  )
                else
                  PrimaryButton(
                    label: 'Start Workout',
                    icon: LucideIcons.play,
                    height: 52,
                    onPressed: _startWorkout,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCameraViewport(bool isFrontCam) {
    if (!_hasCameraPermission) {
      return Container(
        color: AppColors.surfaceSoft,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(LucideIcons.cameraOff, size: 48, color: AppColors.warning),
                const SizedBox(height: 16),
                Text('Camera Permission Required', style: AppTypography.title),
                const SizedBox(height: 8),
                Text(
                  'Camera is needed for real-time on-device pose tracking',
                  textAlign: TextAlign.center,
                  style: AppTypography.body.copyWith(color: AppColors.inkSecondary),
                ),
                const SizedBox(height: 20),
                PrimaryButton(
                  label: 'Grant Camera Permission',
                  isFullWidth: false,
                  onPressed: _initCamera,
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (!_isCameraInitialized || _cameraController == null) {
      return Container(
        color: AppColors.surfaceSoft,
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: AppColors.primaryBlue),
              SizedBox(height: 16),
              Text(
                'Starting camera and offline pose engine...',
                style: TextStyle(color: AppColors.inkSecondary),
              ),
            ],
          ),
        ),
      );
    }

    final cameraValue = _cameraController!.value;
    final imageSize = Size(cameraValue.previewSize?.height ?? 1, cameraValue.previewSize?.width ?? 1);

    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Center(
        child: AspectRatio(
          aspectRatio: 1 / cameraValue.aspectRatio,
          child: Stack(
            fit: StackFit.expand,
            children: [
              CameraPreview(_cameraController!),
              if (_currentLandmarks.isNotEmpty)
                CustomPaint(
                  painter: PosePainter(
                    landmarks: _currentLandmarks,
                    imageSize: imageSize,
                    isFrontCamera: isFrontCam,
                    isValidForm: _repState.formScore >= 70,
                    currentAngle: _repState.currentAngle,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
