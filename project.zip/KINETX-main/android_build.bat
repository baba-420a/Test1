@echo off
set "GRADLE_USER_HOME=E:\.gradle"
set "PUB_CACHE=E:\pub-cache"
set "ANDROID_HOME=E:\Android\sdk"
set "ANDROID_SDK_ROOT=E:\Android\sdk"
call E:\flutter\bin\flutter.bat build apk --debug
