import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/design_system/components/animated_background_fx.dart';
import '../models/user_profile.dart';

class UserProfileRepository {
  static const String _keyUserProfile = 'kinetx_user_profile';

  /// Load user profile from persistent storage
  static Future<UserProfile> getUserProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyUserProfile);

    if (raw == null || raw.isEmpty) {
      // Check legacy fitness_level if present
      final legacyLevel = prefs.getString('fitness_level') ?? 'Beginner';
      final defaultProfile = UserProfile(
        id: 'user_local_primary',
        name: 'Athlete',
        weightKg: 72.0,
        heightCm: 178.0,
        age: 26,
        gender: 'Male',
        fitnessLevel: legacyLevel,
        goal: 'Build Strength & Lean Muscle',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      await saveUserProfile(defaultProfile);
      AnimatedBackgroundFX.reduceMotionNotifier.value = defaultProfile.reduceMotionEnabled;
      return defaultProfile;
    }

    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      final profile = UserProfile.fromMap(map);
      AnimatedBackgroundFX.reduceMotionNotifier.value = profile.reduceMotionEnabled;
      return profile;
    } catch (_) {
      final fallback = UserProfile(
        id: 'user_local_primary',
        name: 'Athlete',
        fitnessLevel: 'Beginner',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      AnimatedBackgroundFX.reduceMotionNotifier.value = fallback.reduceMotionEnabled;
      return fallback;
    }
  }

  /// Save user profile to persistent storage
  static Future<void> saveUserProfile(UserProfile profile) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonStr = jsonEncode(profile.toMap());
    await prefs.setString(_keyUserProfile, jsonStr);
    // Also keep legacy fitness_level in sync
    await prefs.setString('fitness_level', profile.fitnessLevel);
    AnimatedBackgroundFX.reduceMotionNotifier.value = profile.reduceMotionEnabled;
  }

  /// Quick update for biometrics
  static Future<UserProfile> updateBiometrics({
    String? name,
    double? weightKg,
    double? heightCm,
    int? age,
    String? gender,
    String? fitnessLevel,
    String? goal,
  }) async {
    final current = await getUserProfile();
    final updated = current.copyWith(
      name: name,
      weightKg: weightKg,
      heightCm: heightCm,
      age: age,
      gender: gender,
      fitnessLevel: fitnessLevel,
      goal: goal,
      updatedAt: DateTime.now(),
    );
    await saveUserProfile(updated);
    return updated;
  }
}
