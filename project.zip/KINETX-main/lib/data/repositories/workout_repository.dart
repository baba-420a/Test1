import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/workout_session.dart';

class WorkoutRepository {
  static const String _keyWorkoutHistory = 'kinetx_workout_history';

  /// Save a completed workout session to persistent local storage
  static Future<void> saveSession(WorkoutSession session) async {
    final prefs = await SharedPreferences.getInstance();
    final currentSessions = await getSessions();
    
    // Add to front of list (newest first)
    currentSessions.insert(0, session);

    final jsonList = currentSessions.map((s) => jsonEncode(s.toMap())).toList();
    await prefs.setStringList(_keyWorkoutHistory, jsonList);
  }

  /// Get all workout sessions from storage (newest first)
  static Future<List<WorkoutSession>> getSessions() async {
    final prefs = await SharedPreferences.getInstance();
    final rawList = prefs.getStringList(_keyWorkoutHistory);

    if (rawList == null || rawList.isEmpty) {
      return <WorkoutSession>[];
    }

    try {
      final sessions = rawList.map((item) {
        final map = jsonDecode(item) as Map<String, dynamic>;
        return WorkoutSession.fromMap(map);
      }).where((s) => !s.id.startsWith('session_init_')).toList();

      // If legacy mock sessions were purged, synchronize local storage
      if (sessions.length != rawList.length) {
        final cleanedJson = sessions.map((s) => jsonEncode(s.toMap())).toList();
        await prefs.setStringList(_keyWorkoutHistory, cleanedJson);
      }

      return sessions;
    } catch (_) {
      return <WorkoutSession>[];
    }
  }

  /// Get workout session by ID
  static Future<WorkoutSession?> getSessionById(String id) async {
    final sessions = await getSessions();
    try {
      return sessions.firstWhere((s) => s.id == id);
    } catch (_) {
      return null;
    }
  }

  /// Delete a workout session
  static Future<void> deleteSession(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final currentSessions = await getSessions();
    currentSessions.removeWhere((s) => s.id == id);

    final jsonList = currentSessions.map((s) => jsonEncode(s.toMap())).toList();
    await prefs.setStringList(_keyWorkoutHistory, jsonList);
  }

  /// Returns 7-day activity metrics for the past 7 days (today is index 6)
  static Future<List<DayActivity>> getLast7DaysActivity() async {
    final sessions = await getSessions();
    final now = DateTime.now();
    final List<DayActivity> days = [];

    for (int i = 6; i >= 0; i--) {
      final targetDate = DateTime(now.year, now.month, now.day).subtract(Duration(days: i));
      int reps = 0;
      int durationSecs = 0;

      for (final s in sessions) {
        final sDate = DateTime(s.startTime.year, s.startTime.month, s.startTime.day);
        if (sDate.isAtSameMomentAs(targetDate)) {
          reps += s.correctReps;
          durationSecs += s.durationSeconds;
        }
      }

      final dayLabels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
      final weekdayIndex = targetDate.weekday - 1; // 0=Mon, 6=Sun

      days.add(
        DayActivity(
          date: targetDate,
          dayLabel: dayLabels[weekdayIndex],
          totalReps: reps,
          durationSeconds: durationSecs,
          isToday: i == 0,
        ),
      );
    }

    return days;
  }

  /// Compute real consecutive active workout day streak
  static int computeCurrentStreak(List<WorkoutSession> sessions) {
    if (sessions.isEmpty) return 0;

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final workoutDays = sessions
        .map((s) => DateTime(s.startTime.year, s.startTime.month, s.startTime.day))
        .toSet()
        .toList()
      ..sort((a, b) => b.compareTo(a)); // Newest first

    if (workoutDays.isEmpty) return 0;

    // Check if the most recent workout was today or yesterday
    final diffFromToday = today.difference(workoutDays.first).inDays;
    if (diffFromToday > 1) {
      return 0; // Streak broken
    }

    int streak = 1;
    for (int i = 0; i < workoutDays.length - 1; i++) {
      final diff = workoutDays[i].difference(workoutDays[i + 1]).inDays;
      if (diff == 1) {
        streak++;
      } else if (diff > 1) {
        break;
      }
    }

    return streak;
  }

  /// Overall aggregate stats
  static Future<TotalWorkoutStats> getTotalStats() async {
    final sessions = await getSessions();
    if (sessions.isEmpty) {
      return const TotalWorkoutStats(
        totalWorkouts: 0,
        totalReps: 0,
        totalCalories: 0.0,
        averageFormScore: 0.0,
        totalMinutes: 0,
      );
    }

    int totalReps = 0;
    double totalCalories = 0.0;
    double sumFormScore = 0.0;
    int totalSecs = 0;

    for (final s in sessions) {
      totalReps += s.correctReps;
      totalCalories += s.estimatedCalories;
      sumFormScore += s.averageFormScore;
      totalSecs += s.durationSeconds;
    }

    return TotalWorkoutStats(
      totalWorkouts: sessions.length,
      totalReps: totalReps,
      totalCalories: totalCalories,
      averageFormScore: sumFormScore / sessions.length,
      totalMinutes: totalSecs ~/ 60,
    );
  }
}

class DayActivity {
  final DateTime date;
  final String dayLabel;
  final int totalReps;
  final int durationSeconds;
  final bool isToday;

  const DayActivity({
    required this.date,
    required this.dayLabel,
    required this.totalReps,
    required this.durationSeconds,
    required this.isToday,
  });
}

class TotalWorkoutStats {
  final int totalWorkouts;
  final int totalReps;
  final double totalCalories;
  final double averageFormScore;
  final int totalMinutes;

  const TotalWorkoutStats({
    required this.totalWorkouts,
    required this.totalReps,
    required this.totalCalories,
    required this.averageFormScore,
    required this.totalMinutes,
  });
}
