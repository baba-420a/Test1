class DailyStats {
  final String date; // YYYY-MM-DD
  final int workoutCount;
  final int totalReps;
  final int correctReps;
  final int rejectedReps;
  final double estimatedCalories;
  final int activeDurationSeconds;
  final int streakDays;

  const DailyStats({
    required this.date,
    required this.workoutCount,
    required this.totalReps,
    required this.correctReps,
    required this.rejectedReps,
    required this.estimatedCalories,
    required this.activeDurationSeconds,
    required this.streakDays,
  });

  static DailyStats empty(String date) {
    return DailyStats(
      date: date,
      workoutCount: 0,
      totalReps: 0,
      correctReps: 0,
      rejectedReps: 0,
      estimatedCalories: 0,
      activeDurationSeconds: 0,
      streakDays: 0,
    );
  }
}
