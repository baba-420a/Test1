class WorkoutSession {
  final String id;
  final String exerciseId;
  final String exerciseName;
  final DateTime startTime;
  final DateTime endTime;
  final int durationSeconds;
  final int totalAttempts;
  final int correctReps;
  final int rejectedReps;
  final double averageFormScore;
  final double estimatedCalories;
  final String? notes;

  const WorkoutSession({
    required this.id,
    required this.exerciseId,
    required this.exerciseName,
    required this.startTime,
    required this.endTime,
    required this.durationSeconds,
    required this.totalAttempts,
    required this.correctReps,
    required this.rejectedReps,
    required this.averageFormScore,
    required this.estimatedCalories,
    this.notes,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'exerciseId': exerciseId,
      'exerciseName': exerciseName,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'durationSeconds': durationSeconds,
      'totalAttempts': totalAttempts,
      'correctReps': correctReps,
      'rejectedReps': rejectedReps,
      'averageFormScore': averageFormScore,
      'estimatedCalories': estimatedCalories,
      'notes': notes,
    };
  }

  factory WorkoutSession.fromMap(Map<String, dynamic> map) {
    return WorkoutSession(
      id: map['id'] as String,
      exerciseId: map['exerciseId'] as String,
      exerciseName: map['exerciseName'] as String,
      startTime: DateTime.parse(map['startTime'] as String),
      endTime: DateTime.parse(map['endTime'] as String),
      durationSeconds: map['durationSeconds'] as int,
      totalAttempts: map['totalAttempts'] as int,
      correctReps: map['correctReps'] as int,
      rejectedReps: map['rejectedReps'] as int,
      averageFormScore: (map['averageFormScore'] as num).toDouble(),
      estimatedCalories: (map['estimatedCalories'] as num).toDouble(),
      notes: map['notes'] as String?,
    );
  }
}
