class Exercise {
  final String id;
  final String name;
  final String description;
  final String cameraPlacement; // e.g. "Side view", "Front view"
  final String targetMuscles;
  final String difficulty; // Beginner, Intermediate, Advanced
  final double caloriesPerRep;
  final bool isEnabled;

  const Exercise({
    required this.id,
    required this.name,
    required this.description,
    required this.cameraPlacement,
    required this.targetMuscles,
    required this.difficulty,
    required this.caloriesPerRep,
    this.isEnabled = true,
  });

  static const List<Exercise> defaultExercises = [
    Exercise(
      id: 'squats',
      name: 'Bodyweight Squats',
      description:
          'A premier compound strength builder targeting the lower posterior chain. Hinge at hips, track knees along toe lines, descend until thighs break parallel, and power up through heels while keeping lumbar spine neutral.',
      cameraPlacement: 'Side view (full body visible)',
      targetMuscles: 'Quadriceps, Glutes, Hamstrings, Core',
      difficulty: 'Beginner',
      caloriesPerRep: 0.32,
    ),
    Exercise(
      id: 'pushups',
      name: 'Push-ups',
      description:
          'The ultimate closed-chain upper body test. Maintain a rigid plank from head to heels, retract scapulae on a controlled 3-second descent, graze chest near floor, and drive explosively back to full lockout.',
      cameraPlacement: 'Side view (diagonal to camera)',
      targetMuscles: 'Pectorals, Anterior Deltoids, Triceps, Core',
      difficulty: 'Intermediate',
      caloriesPerRep: 0.45,
    ),
    Exercise(
      id: 'bicep_curls',
      name: 'Bicep Curls',
      description:
          'Precision isolation movement for upper-arm hypertrophy. Anchor elbows tightly to your ribcage, eliminate momentum or hip swing, and curl with peak tension through the full anatomical range.',
      cameraPlacement: 'Front or side view',
      targetMuscles: 'Biceps Brachii, Brachialis, Forearms',
      difficulty: 'Beginner',
      caloriesPerRep: 0.25,
    ),
  ];
}
