class UserProfile {
  final String id;
  final String name;
  final double weightKg;
  final double heightCm;
  final int age;
  final String gender;
  final String fitnessLevel; // Beginner, Intermediate, Advanced
  final String goal; // Build Muscle, Lose Fat, Form & Mobility, General Fitness
  final DateTime createdAt;
  final DateTime updatedAt;
  final String? preferredReminderTime;
  final bool notificationsEnabled;
  final bool cameraMirrorEnabled;
  final bool audioFeedbackEnabled;
  final bool reduceMotionEnabled;
  final double speechRate;

  const UserProfile({
    required this.id,
    required this.name,
    this.weightKg = 70.0,
    this.heightCm = 175.0,
    this.age = 25,
    this.gender = 'Male',
    required this.fitnessLevel,
    this.goal = 'Build Strength & Form',
    required this.createdAt,
    required this.updatedAt,
    this.preferredReminderTime,
    this.notificationsEnabled = true,
    this.cameraMirrorEnabled = true,
    this.audioFeedbackEnabled = true,
    this.reduceMotionEnabled = false,
    this.speechRate = 1.0,
  });

  /// Body Mass Index (BMI) = weight (kg) / [height (m)]^2
  double get bmi {
    if (heightCm <= 0) return 0.0;
    final heightM = heightCm / 100.0;
    return weightKg / (heightM * heightM);
  }

  String get bmiCategory {
    final value = bmi;
    if (value < 18.5) return 'Underweight';
    if (value < 25.0) return 'Normal Weight';
    if (value < 30.0) return 'Overweight';
    return 'Obese';
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'weightKg': weightKg,
      'heightCm': heightCm,
      'age': age,
      'gender': gender,
      'fitnessLevel': fitnessLevel,
      'goal': goal,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'preferredReminderTime': preferredReminderTime,
      'notificationsEnabled': notificationsEnabled,
      'cameraMirrorEnabled': cameraMirrorEnabled,
      'audioFeedbackEnabled': audioFeedbackEnabled,
      'reduceMotionEnabled': reduceMotionEnabled,
      'speechRate': speechRate,
    };
  }

  factory UserProfile.fromMap(Map<String, dynamic> map) {
    return UserProfile(
      id: map['id'] as String? ?? 'user_default',
      name: map['name'] as String? ?? 'Athlete',
      weightKg: (map['weightKg'] as num?)?.toDouble() ?? 70.0,
      heightCm: (map['heightCm'] as num?)?.toDouble() ?? 175.0,
      age: (map['age'] as num?)?.toInt() ?? 25,
      gender: map['gender'] as String? ?? 'Male',
      fitnessLevel: map['fitnessLevel'] as String? ?? 'Beginner',
      goal: map['goal'] as String? ?? 'Build Strength & Form',
      createdAt: map['createdAt'] != null
          ? DateTime.parse(map['createdAt'] as String)
          : DateTime.now(),
      updatedAt: map['updatedAt'] != null
          ? DateTime.parse(map['updatedAt'] as String)
          : DateTime.now(),
      preferredReminderTime: map['preferredReminderTime'] as String?,
      notificationsEnabled: map['notificationsEnabled'] as bool? ?? true,
      cameraMirrorEnabled: map['cameraMirrorEnabled'] as bool? ?? true,
      audioFeedbackEnabled: map['audioFeedbackEnabled'] as bool? ?? true,
      reduceMotionEnabled: map['reduceMotionEnabled'] as bool? ?? false,
      speechRate: (map['speechRate'] as num?)?.toDouble() ?? 1.0,
    );
  }

  UserProfile copyWith({
    String? id,
    String? name,
    double? weightKg,
    double? heightCm,
    int? age,
    String? gender,
    String? fitnessLevel,
    String? goal,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? preferredReminderTime,
    bool? notificationsEnabled,
    bool? cameraMirrorEnabled,
    bool? audioFeedbackEnabled,
    bool? reduceMotionEnabled,
    double? speechRate,
  }) {
    return UserProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      weightKg: weightKg ?? this.weightKg,
      heightCm: heightCm ?? this.heightCm,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      fitnessLevel: fitnessLevel ?? this.fitnessLevel,
      goal: goal ?? this.goal,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      preferredReminderTime: preferredReminderTime ?? this.preferredReminderTime,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      cameraMirrorEnabled: cameraMirrorEnabled ?? this.cameraMirrorEnabled,
      audioFeedbackEnabled: audioFeedbackEnabled ?? this.audioFeedbackEnabled,
      reduceMotionEnabled: reduceMotionEnabled ?? this.reduceMotionEnabled,
      speechRate: speechRate ?? this.speechRate,
    );
  }
}
