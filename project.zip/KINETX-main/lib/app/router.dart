import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../features/exercise_library/exercise_detail_screen.dart';
import '../features/exercise_library/exercise_library_screen.dart';
import '../features/history/history_detail_screen.dart';
import '../features/history/history_screen.dart';
import '../features/home/dashboard_screen.dart';
import '../features/live_workout/live_workout_screen.dart';
import '../features/onboarding/onboarding_screen.dart';
import '../features/onboarding/splash_screen.dart';
import '../features/reminders/reminders_screen.dart';
import '../features/session_summary/session_summary_screen.dart';
import '../features/settings/settings_screen.dart';
import '../features/shell/main_shell_screen.dart';

final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>();

final GoRouter appRouter = GoRouter(
  navigatorKey: _rootNavigatorKey,
  initialLocation: '/splash',
  routes: [
    // Splash Screen
    GoRoute(
      path: '/splash',
      builder: (context, state) => const SplashScreen(),
    ),

    // Onboarding Screen
    GoRoute(
      path: '/onboarding',
      builder: (context, state) => const OnboardingScreen(),
    ),

    // Stateful Nested Bottom Navigation Shell (4 tabs: Home, Plan, Stats, Profile)
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) {
        return MainShellScreen(navigationShell: navigationShell);
      },
      branches: [
        // Tab 0: Home Dashboard
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/home',
              builder: (context, state) => const DashboardScreen(),
            ),
          ],
        ),

        // Tab 1: Plan / Exercise Library
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/exercises',
              builder: (context, state) => const ExerciseLibraryScreen(),
            ),
          ],
        ),

        // Tab 2: Stats / Workout History
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/history',
              builder: (context, state) => const HistoryScreen(),
            ),
          ],
        ),

        // Tab 3: Profile / Settings
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/settings',
              builder: (context, state) => const SettingsScreen(),
            ),
          ],
        ),
      ],
    ),

    // Full-screen Subroutes
    GoRoute(
      parentNavigatorKey: _rootNavigatorKey,
      path: '/reminders',
      builder: (context, state) => const RemindersScreen(),
    ),

    GoRoute(
      parentNavigatorKey: _rootNavigatorKey,
      path: '/exercise-detail/:exerciseId',
      builder: (context, state) {
        final exerciseId = state.pathParameters['exerciseId'] ?? 'squats';
        return ExerciseDetailScreen(exerciseId: exerciseId);
      },
    ),

    GoRoute(
      parentNavigatorKey: _rootNavigatorKey,
      path: '/live-workout/:exerciseId',
      builder: (context, state) {
        final exerciseId = state.pathParameters['exerciseId'] ?? 'squats';
        return LiveWorkoutScreen(exerciseId: exerciseId);
      },
    ),

    GoRoute(
      parentNavigatorKey: _rootNavigatorKey,
      path: '/session-summary',
      builder: (context, state) {
        final extra = state.extra as Map<String, dynamic>?;
        return SessionSummaryScreen(sessionData: extra);
      },
    ),

    GoRoute(
      parentNavigatorKey: _rootNavigatorKey,
      path: '/history/:id',
      builder: (context, state) {
        final id = state.pathParameters['id'] ?? '';
        return HistoryDetailScreen(sessionId: id);
      },
    ),
  ],
);
