import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../tokens/app_colors.dart';
import '../tokens/radii.dart';

/// Exercise photo tile / cutout with seamless fallback:
/// If a photo asset is missing at runtime, falls back to a dark navy-to-blue
/// gradient tile with a glowing icon well — layout never breaks.
class ExercisePhotoTile extends StatelessWidget {
  final String exerciseId;
  final double width;
  final double height;
  final BorderRadius? borderRadius;
  final bool isLargeBanner;

  const ExercisePhotoTile({
    super.key,
    required this.exerciseId,
    this.width = 64.0,
    this.height = 64.0,
    this.borderRadius,
    this.isLargeBanner = false,
  });

  IconData _getExerciseIcon(String id) {
    switch (id.toLowerCase()) {
      case 'squats':
      case 'bodyweight_squats':
        return LucideIcons.activity;
      case 'pushups':
      case 'push_ups':
        return LucideIcons.flame;
      case 'curls':
      case 'bicep_curls':
        return LucideIcons.dumbbell;
      default:
        return LucideIcons.zap;
    }
  }

  String _getAssetPath(String id) {
    final cleanId = id.toLowerCase().replaceAll(' ', '_');
    return 'assets/exercises/$cleanId.png';
  }

  @override
  Widget build(BuildContext context) {
    final effectiveRadius = borderRadius ?? AppRadii.tileRadius;
    final icon = _getExerciseIcon(exerciseId);
    final assetPath = _getAssetPath(exerciseId);

    // Sleek soft blue gradient fallback tile
    Widget fallbackTile = Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF12233A),
            Color(0xFF1B3A63),
          ],
        ),
        borderRadius: effectiveRadius,
      ),
      alignment: Alignment.center,
      child: Container(
        width: isLargeBanner ? 56 : (width * 0.55).clamp(28.0, 48.0),
        height: isLargeBanner ? 56 : (height * 0.55).clamp(28.0, 48.0),
        decoration: BoxDecoration(
          color: AppColors.surface,
          shape: BoxShape.circle,
          boxShadow: AppColors.glow(AppColors.primaryBlue, alpha: 0.35, blur: 12),
        ),
        alignment: Alignment.center,
        child: Icon(
          icon,
          size: isLargeBanner ? 28 : (width * 0.28).clamp(16.0, 26.0),
          color: AppColors.primaryBlue,
        ),
      ),
    );

    return ClipRRect(
      borderRadius: effectiveRadius,
      child: Image.asset(
        assetPath,
        width: width,
        height: height,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => fallbackTile,
      ),
    );
  }
}
