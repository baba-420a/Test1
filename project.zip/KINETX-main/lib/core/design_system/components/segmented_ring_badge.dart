import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../tokens/app_colors.dart';

/// Signature floating circular badge from Reference 1, 2 & 4:
/// Segmented ring (8 segments alternating blue shades + 2 lime segments)
/// surrounding a deep navy circle with a white lucide icon.
class SegmentedRingBadge extends StatelessWidget {
  final IconData icon;
  final double size;

  const SegmentedRingBadge({
    super.key,
    required this.icon,
    this.size = 72.0,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Segmented Ring Custom Painter
          CustomPaint(
            size: Size(size, size),
            painter: _SegmentedRingPainter(),
          ),

          // Inner Deep Navy Circle with White Icon
          Container(
            width: size * 0.68,
            height: size * 0.68,
            decoration: const BoxDecoration(
              color: AppColors.deepNavy,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Icon(
              icon,
              size: size * 0.32,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

class _SegmentedRingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 3;
    final strokeWidth = size.width * 0.12;

    const segmentCount = 8;
    const gapAngle = 0.12; // Gap in radians between segments
    const sweepAngle = (2 * math.pi / segmentCount) - gapAngle;

    // Segment colors matching Reference Screenshots (blue shades + 2 lime segments)
    final segmentColors = [
      AppColors.lime, // segment 0 (lime highlight)
      const Color(0xFF1E6FD9),
      const Color(0xFF2E86F5),
      const Color(0xFF4FA0FF),
      const Color(0xFF6AB0FF),
      AppColors.lime, // segment 5 (lime highlight)
      const Color(0xFF2E86F5),
      const Color(0xFF1B5CB3),
    ];

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i < segmentCount; i++) {
      paint.color = segmentColors[i % segmentColors.length];
      final startAngle = -math.pi / 2 + (i * (sweepAngle + gapAngle));
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
