import 'package:flutter/material.dart';
import '../tokens/app_colors.dart';
import '../tokens/radii.dart';
import '../tokens/typography.dart';

/// Primary action button in Lime (#B4EF3C) or Primary Blue, matching reference CTAs.
/// Scales to 0.97 while pressed via AnimatedScale.
class PrimaryButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool isLoading;
  final bool isFullWidth;
  final bool isSecondary;
  final bool isBlue;
  final double height;

  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.isLoading = false,
    this.isFullWidth = true,
    this.isSecondary = false,
    this.isBlue = false,
    this.height = 52.0,
  });

  @override
  State<PrimaryButton> createState() => _PrimaryButtonState();
}

class _PrimaryButtonState extends State<PrimaryButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    final isSecondary = widget.isSecondary;
    final isBlue = widget.isBlue;
    final isLoading = widget.isLoading;
    final isFullWidth = widget.isFullWidth;
    final onPressed = widget.onPressed;
    final label = widget.label;
    final icon = widget.icon;
    final height = widget.height;

    Color backgroundColor = isSecondary
        ? AppColors.chipGray
        : (isBlue ? AppColors.primaryBlue : AppColors.lime);
    Color foregroundColor = isSecondary
        ? AppColors.ink
        : (isBlue ? Colors.white : AppColors.onLime);
    final showGlow = !isSecondary && onPressed != null && !isLoading;

    final buttonWidget = ElevatedButton(
      onPressed: isLoading ? null : onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: backgroundColor,
        foregroundColor: foregroundColor,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: AppRadii.buttonRadius,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20),
      ),
      child: isLoading
          ? SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(
                strokeWidth: 2.5,
                valueColor: AlwaysStoppedAnimation<Color>(foregroundColor),
              ),
            )
          : Row(
              mainAxisSize: isFullWidth ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 18, color: foregroundColor),
                  const SizedBox(width: 8),
                ],
                Text(
                  label,
                  style: AppTypography.bodyBold.copyWith(
                    color: foregroundColor,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
    );

    final sized = Container(
      width: isFullWidth ? double.infinity : null,
      height: height,
      decoration: BoxDecoration(
        borderRadius: AppRadii.buttonRadius,
        boxShadow: showGlow ? AppColors.glow(backgroundColor, alpha: 0.35, blur: 20) : const [],
      ),
      child: buttonWidget,
    );

    return Listener(
      onPointerDown: (_) {
        if (onPressed != null && !isLoading) {
          setState(() => _isPressed = true);
        }
      },
      onPointerUp: (_) {
        if (_isPressed) {
          setState(() => _isPressed = false);
        }
      },
      onPointerCancel: (_) {
        if (_isPressed) {
          setState(() => _isPressed = false);
        }
      },
      child: AnimatedScale(
        scale: _isPressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 100),
        curve: Curves.easeInOutCubic,
        child: sized,
      ),
    );
  }
}
