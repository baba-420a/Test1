import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../tokens/app_colors.dart';
import '../tokens/radii.dart';
import '../tokens/typography.dart';
import 'micro_interactions.dart';

/// Floating stat chip:
/// Small dark-glass rounded-16 card (works over camera feed or page bg),
/// big Montserrat-800 number, tiny unit, icon + label,
/// row of 5 tiny dots (blue/lime/amber/red) as intensity scale.
class FloatingStatChip extends StatelessWidget {
  final String value;
  final String? unit;
  final String label;
  final IconData icon;
  final Color iconColor;
  final int intensityLevel; // 1 to 5

  const FloatingStatChip({
    super.key,
    required this.value,
    this.unit,
    required this.label,
    this.icon = LucideIcons.heart,
    this.iconColor = AppColors.danger,
    this.intensityLevel = 3,
  });

  @override
  Widget build(BuildContext context) {
    // 5 intensity dots matching reference 3
    final dotColors = [
      AppColors.primaryBlue,
      AppColors.lime,
      AppColors.warning,
      const Color(0xFFFF7A00), // amber-orange
      AppColors.danger,
    ];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surface.withValues(alpha: 0.94),
        borderRadius: AppRadii.tileRadius,
        border: Border.all(color: AppColors.hairline, width: 1),
        boxShadow: const [
          BoxShadow(
            color: Color(0x40000000),
            blurRadius: 16,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Value + Unit + Icon Row
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              CountUpText.fromString(
                value,
                style: AppTypography.display.copyWith(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: AppColors.ink,
                  height: 1.0,
                ),
              ),
              if (unit != null) ...[
                const SizedBox(width: 3),
                Text(
                  unit!,
                  style: AppTypography.caption.copyWith(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: AppColors.inkSecondary,
                  ),
                ),
              ],
              const SizedBox(width: 8),
              Icon(
                icon,
                size: 14,
                color: iconColor,
              ),
            ],
          ),
          const SizedBox(height: 3),
          Text(
            label,
            style: AppTypography.caption.copyWith(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: AppColors.inkSecondary,
            ),
          ),
          const SizedBox(height: 6),
          // Row of 5 intensity dots
          Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(5, (index) {
              final isActive = index < intensityLevel;
              return Container(
                margin: const EdgeInsets.only(right: 3),
                width: 8,
                height: 3.5,
                decoration: BoxDecoration(
                  color: isActive ? dotColors[index] : AppColors.chipGray,
                  borderRadius: BorderRadius.circular(2),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}
