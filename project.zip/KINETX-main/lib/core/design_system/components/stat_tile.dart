import 'package:flutter/material.dart';
import '../tokens/app_colors.dart';
import '../tokens/typography.dart';
import 'app_card.dart';
import 'micro_interactions.dart';

/// Clean stat tile featuring overline title and Montserrat 800 tabular value.
class StatTile extends StatelessWidget {
  final String label;
  final String value;
  final String? unit;
  final String? subtitle;
  final IconData? icon;
  final Color? valueColor;
  final Color? subtitleColor;
  final Color? iconColor;

  const StatTile({
    super.key,
    required this.label,
    required this.value,
    this.unit,
    this.subtitle,
    this.icon,
    this.valueColor,
    this.subtitleColor,
    this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label.toUpperCase(),
                style: AppTypography.overline.copyWith(
                  fontSize: 10,
                  letterSpacing: 1.1,
                  color: AppColors.inkSecondary,
                ),
              ),
              if (icon != null)
                Icon(
                  icon,
                  size: 15,
                  color: iconColor ?? AppColors.inkSecondary,
                ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Expanded(
                child: CountUpText.fromString(
                  value,
                  style: AppTypography.headline.copyWith(
                    color: valueColor ?? AppColors.ink,
                    fontSize: value.length > 8 ? 16 : 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              if (unit != null) ...[
                const SizedBox(width: 4),
                Text(
                  unit!,
                  style: AppTypography.caption.copyWith(color: AppColors.inkSecondary),
                ),
              ],
            ],
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 3),
            Text(
              subtitle!,
              style: AppTypography.caption.copyWith(
                color: subtitleColor ?? AppColors.inkSecondary,
                fontSize: 11,
                fontWeight: subtitleColor != null ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
