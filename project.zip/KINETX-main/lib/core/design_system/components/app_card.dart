import 'package:flutter/material.dart';
import '../tokens/app_colors.dart';
import '../tokens/radii.dart';
import '../tokens/spacing.dart';

/// Dark elevated card. Since drop shadows barely read against a near-black
/// page background, elevation here comes primarily from the lighter
/// [AppColors.surface] fill plus a subtle hairline rim-light border
/// (overridable via [border]), with a soft shadow for extra depth.
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? backgroundColor;
  final List<BoxShadow>? shadows;
  final BorderRadius? borderRadius;
  final Border? border;

  const AppCard({
    super.key,
    required this.child,
    this.padding = AppSpacing.cardPadding,
    this.onTap,
    this.backgroundColor,
    this.shadows,
    this.borderRadius,
    this.border,
  });

  @override
  Widget build(BuildContext context) {
    final effectiveRadius = borderRadius ?? AppRadii.cardRadius;
    final cardContent = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: backgroundColor ?? AppColors.surface,
        borderRadius: effectiveRadius,
        boxShadow: shadows ?? AppColors.cardShadow,
        border: border ?? Border.all(color: AppColors.hairline, width: 1),
      ),
      child: child,
    );

    if (onTap != null) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: effectiveRadius,
          child: cardContent,
        ),
      );
    }

    return cardContent;
  }
}
