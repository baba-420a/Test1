import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../tokens/app_colors.dart';
import '../tokens/radii.dart';
import '../tokens/typography.dart';
import 'micro_interactions.dart';

enum ChipVariant {
  neutral,
  lime,
  blue,
  navy,
  selected,
  success,
  warning,
  danger,
}

/// Pill chip matching reference screenshots with full rounded radius (999).
class AppChip extends StatelessWidget {
  final String label;
  final IconData? icon;
  final ChipVariant variant;
  final VoidCallback? onTap;

  const AppChip({
    super.key,
    required this.label,
    this.icon,
    this.variant = ChipVariant.neutral,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color text;

    switch (variant) {
      case ChipVariant.neutral:
        bg = AppColors.chipGray;
        text = AppColors.inkSecondary;
        break;
      case ChipVariant.lime:
        bg = AppColors.lime;
        text = AppColors.onLime;
        break;
      case ChipVariant.blue:
      case ChipVariant.selected:
        bg = AppColors.primaryBlue;
        text = Colors.white;
        break;
      case ChipVariant.navy:
        bg = AppColors.deepNavy;
        text = Colors.white;
        break;
      case ChipVariant.success:
        bg = const Color(0x3322A06B);
        text = AppColors.success;
        break;
      case ChipVariant.warning:
        bg = const Color(0x33F5A524);
        text = AppColors.warning;
        break;
      case ChipVariant.danger:
        bg = const Color(0x33E5484D);
        text = AppColors.danger;
        break;
    }

    final chipWidget = Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: AppRadii.pillRadius,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (icon != null) ...[
            if (icon == LucideIcons.flame)
              PulsingFlameIcon(icon: icon!, size: 12, color: text)
            else
              Icon(icon, size: 12, color: text),
            const SizedBox(width: 5),
          ],
          Text(
            label,
            style: AppTypography.caption.copyWith(
              color: text,
              fontWeight: FontWeight.w700,
              fontSize: 11,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );

    if (onTap != null) {
      return GestureDetector(
        onTap: onTap,
        child: chipWidget,
      );
    }

    return chipWidget;
  }
}
