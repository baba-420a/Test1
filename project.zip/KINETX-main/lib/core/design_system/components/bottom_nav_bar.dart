import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../tokens/app_colors.dart';
import '../tokens/typography.dart';

class BottomNavItem {
  final IconData icon;
  final String label;

  const BottomNavItem({required this.icon, required this.label});
}

/// 4-tab bottom navigation bar:
/// Dark elevated bar with a soft hairline top border,
/// unselected = inkSecondary icon+label;
/// selected = primaryBlue icon+label with a glowing primaryBlueSoft circular halo behind the icon.
class AppBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const AppBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  static const List<BottomNavItem> items = [
    BottomNavItem(icon: LucideIcons.home, label: 'Home'),
    BottomNavItem(icon: LucideIcons.calendarCheck2, label: 'Plan'),
    BottomNavItem(icon: LucideIcons.barChart2, label: 'Stats'),
    BottomNavItem(icon: LucideIcons.user, label: 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(
          top: BorderSide(color: AppColors.hairline, width: 1),
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0x4D000000),
            blurRadius: 20,
            offset: Offset(0, -6),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(
            children: List.generate(items.length, (index) {
              final item = items[index];
              final isSelected = currentIndex == index;

              return Expanded(
                child: InkWell(
                  onTap: () => onTap(index),
                  splashColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 38,
                        height: 30,
                        decoration: BoxDecoration(
                          color: isSelected ? AppColors.primaryBlueSoft : Colors.transparent,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: isSelected
                              ? AppColors.glow(AppColors.primaryBlue, alpha: 0.3, blur: 12)
                              : const [],
                        ),
                        alignment: Alignment.center,
                        child: Icon(
                          item.icon,
                          size: 19,
                          color: isSelected ? AppColors.primaryBlue : AppColors.inkSecondary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        item.label,
                        style: AppTypography.caption.copyWith(
                          fontSize: 10,
                          fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                          color: isSelected ? AppColors.primaryBlue : AppColors.inkSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
