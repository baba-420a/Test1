import 'package:flutter/material.dart';
import 'animated_background_fx.dart';

/// Micro-interaction 1: Number count-up animation via TweenAnimationBuilder
class CountUpText extends StatelessWidget {
  final num value;
  final String? prefix;
  final String? suffix;
  final int decimalPlaces;
  final TextStyle? style;
  final Duration duration;

  const CountUpText({
    super.key,
    required this.value,
    this.prefix,
    this.suffix,
    this.decimalPlaces = 0,
    this.style,
    this.duration = const Duration(milliseconds: 900),
  });

  /// Helper constructor to count up string containing a number (e.g. "42", "95%")
  static Widget fromString(
    String rawValue, {
    Key? key,
    TextStyle? style,
    Duration duration = const Duration(milliseconds: 900),
  }) {
    final match = RegExp(r'(\d+(\.\d+)?)').firstMatch(rawValue);
    if (match == null) {
      return Text(rawValue, key: key, style: style);
    }
    final numVal = num.tryParse(match.group(1)!) ?? 0;
    final prefix = rawValue.substring(0, match.start);
    final suffix = rawValue.substring(match.end);
    final isDecimal = match.group(1)!.contains('.');
    final decimalPlaces = isDecimal ? match.group(1)!.split('.')[1].length : 0;

    return CountUpText(
      key: key,
      value: numVal,
      prefix: prefix.isNotEmpty ? prefix : null,
      suffix: suffix.isNotEmpty ? suffix : null,
      decimalPlaces: decimalPlaces,
      style: style,
      duration: duration,
    );
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = AnimatedBackgroundFX.reduceMotionNotifier.value;
    final effectiveDuration = reduceMotion ? Duration.zero : duration;

    return ValueListenableBuilder<bool>(
      valueListenable: AnimatedBackgroundFX.reduceMotionNotifier,
      builder: (context, motionReduced, _) {
        if (motionReduced) {
          final formatted = decimalPlaces > 0
              ? value.toStringAsFixed(decimalPlaces)
              : value.toInt().toString();
          return Text(
            '${prefix ?? ''}$formatted${suffix ?? ''}',
            style: style,
          );
        }

        return TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: 0.0, end: value.toDouble()),
          duration: effectiveDuration,
          curve: Curves.easeOutCubic,
          builder: (context, val, _) {
            final formatted = decimalPlaces > 0
                ? val.toStringAsFixed(decimalPlaces)
                : val.toInt().toString();
            return Text(
              '${prefix ?? ''}$formatted${suffix ?? ''}',
              style: style,
            );
          },
        );
      },
    );
  }
}

/// Micro-interaction 2: 30ms Staggered slide+fade entrance for cards and tiles
class StaggeredEntrance extends StatefulWidget {
  final int index;
  final Widget child;
  final Duration baseDelay;
  final Duration duration;
  final double slideOffset;

  const StaggeredEntrance({
    super.key,
    required this.index,
    required this.child,
    this.baseDelay = const Duration(milliseconds: 30),
    this.duration = const Duration(milliseconds: 320),
    this.slideOffset = 18.0,
  });

  @override
  State<StaggeredEntrance> createState() => _StaggeredEntranceState();
}

class _StaggeredEntranceState extends State<StaggeredEntrance>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animCtrl;
  late final Animation<double> _fadeAnim;
  late final Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: widget.duration);
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic);
    _slideAnim = Tween<Offset>(
      begin: Offset(0, widget.slideOffset / 100),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic));

    if (AnimatedBackgroundFX.reduceMotionNotifier.value) {
      _animCtrl.value = 1.0;
    } else {
      final totalDelay = widget.baseDelay * widget.index;
      Future.delayed(totalDelay, () {
        if (mounted) {
          _animCtrl.forward();
        }
      });
    }
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (AnimatedBackgroundFX.reduceMotionNotifier.value || _animCtrl.isCompleted) {
      return widget.child;
    }

    return AnimatedBuilder(
      animation: _animCtrl,
      builder: (context, child) {
        return Opacity(
          opacity: _fadeAnim.value.clamp(0.0, 1.0),
          child: FractionalTranslation(
            translation: _slideAnim.value,
            child: child,
          ),
        );
      },
      child: widget.child,
    );
  }
}

/// Micro-interaction 3: Button press scale to 0.97
class PressableScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onPressed;
  final double targetScale;
  final Duration duration;

  const PressableScale({
    super.key,
    required this.child,
    this.onPressed,
    this.targetScale = 0.97,
    this.duration = const Duration(milliseconds: 100),
  });

  @override
  State<PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<PressableScale> {
  bool _isPressed = false;

  void _onTapDown(TapDownDetails _) {
    if (widget.onPressed != null) {
      setState(() => _isPressed = true);
    }
  }

  void _onTapUp(TapUpDetails _) {
    if (_isPressed) {
      setState(() => _isPressed = false);
    }
  }

  void _onTapCancel() {
    if (_isPressed) {
      setState(() => _isPressed = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scale = _isPressed ? widget.targetScale : 1.0;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: _onTapDown,
      onTapUp: _onTapUp,
      onTapCancel: _onTapCancel,
      onTap: widget.onPressed,
      child: AnimatedScale(
        scale: scale,
        duration: widget.duration,
        curve: Curves.easeInOutCubic,
        child: widget.child,
      ),
    );
  }
}

/// Micro-interaction 4: Pulsing flame animation on streak chip
class PulsingFlameIcon extends StatefulWidget {
  final IconData icon;
  final double size;
  final Color color;

  const PulsingFlameIcon({
    super.key,
    required this.icon,
    this.size = 14.0,
    this.color = Colors.white,
  });

  @override
  State<PulsingFlameIcon> createState() => _PulsingFlameIconState();
}

class _PulsingFlameIconState extends State<PulsingFlameIcon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    if (!AnimatedBackgroundFX.reduceMotionNotifier.value) {
      _pulseCtrl.repeat(reverse: true);
    }

    AnimatedBackgroundFX.reduceMotionNotifier.addListener(_onMotionChanged);
  }

  void _onMotionChanged() {
    if (!mounted) return;
    if (AnimatedBackgroundFX.reduceMotionNotifier.value) {
      _pulseCtrl.stop();
      _pulseCtrl.value = 0.0;
    } else if (!_pulseCtrl.isAnimating) {
      _pulseCtrl.repeat(reverse: true);
    }
    setState(() {});
  }

  @override
  void dispose() {
    AnimatedBackgroundFX.reduceMotionNotifier.removeListener(_onMotionChanged);
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (AnimatedBackgroundFX.reduceMotionNotifier.value) {
      return Icon(widget.icon, size: widget.size, color: widget.color);
    }

    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (context, _) {
        final scale = 1.0 + 0.16 * _pulseCtrl.value;
        final opacity = 0.85 + 0.15 * _pulseCtrl.value;
        return Transform.scale(
          scale: scale,
          child: Opacity(
            opacity: opacity.clamp(0.0, 1.0),
            child: Icon(widget.icon, size: widget.size, color: widget.color),
          ),
        );
      },
    );
  }
}

/// Micro-interaction 5: Weekly/Day tiles pop with a spring when saved/completed
class SpringPopTile extends StatefulWidget {
  final Widget child;
  final bool trigger;
  final Duration duration;

  const SpringPopTile({
    super.key,
    required this.child,
    this.trigger = true,
    this.duration = const Duration(milliseconds: 650),
  });

  @override
  State<SpringPopTile> createState() => _SpringPopTileState();
}

class _SpringPopTileState extends State<SpringPopTile>
    with SingleTickerProviderStateMixin {
  late final AnimationController _springCtrl;
  late final Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _springCtrl = AnimationController(vsync: this, duration: widget.duration);
    _scaleAnim = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 1.18).chain(CurveTween(curve: Curves.easeOut)),
        weight: 35,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.18, end: 0.95).chain(CurveTween(curve: Curves.easeInOut)),
        weight: 35,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.95, end: 1.0).chain(CurveTween(curve: Curves.elasticOut)),
        weight: 30,
      ),
    ]).animate(_springCtrl);

    if (widget.trigger && !AnimatedBackgroundFX.reduceMotionNotifier.value) {
      _springCtrl.forward();
    }
  }

  @override
  void didUpdateWidget(covariant SpringPopTile oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.trigger && !oldWidget.trigger) {
      if (!AnimatedBackgroundFX.reduceMotionNotifier.value) {
        _springCtrl.forward(from: 0.0);
      }
    }
  }

  @override
  void dispose() {
    _springCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (AnimatedBackgroundFX.reduceMotionNotifier.value) {
      return widget.child;
    }

    return AnimatedBuilder(
      animation: _springCtrl,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnim.value,
          child: child,
        );
      },
      child: widget.child,
    );
  }
}
