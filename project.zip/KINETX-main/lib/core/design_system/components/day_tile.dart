import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../tokens/app_colors.dart';
import '../tokens/radii.dart';
import '../tokens/typography.dart';
import 'micro_interactions.dart';

enum DayTileState {
  completed,
  today,
  empty,
}

/// Day tile component:
/// - completed: deepNavy -> blue gradient tile w/ blue glow, white bold "Day N", lime circle with dark check icon
/// - today: dark elevated tile with lime-glowing flame icon + bold "TODAY"
/// - empty/future: dim frosted dark gradient tile, muted text
class DayTile extends StatelessWidget {
  final String dayNumber;
  final String dayLabel; // e.g. "MO", "TU"
  final DayTileState state;
  final int reps;
  final VoidCallback? onTap;

  const DayTile({
    super.key,
    required this.dayNumber,
    required this.dayLabel,
    required this.state,
    this.reps = 0,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget content;

    switch (state) {
      case DayTileState.completed:
        content = Container(
          decoration: BoxDecoration(
            gradient: AppColors.completedDayGradient,
            borderRadius: AppRadii.tileRadius,
            boxShadow: AppColors.glow(AppColors.primaryBlue, alpha: 0.28, blur: 16),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Day $dayNumber',
                style: AppTypography.caption.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 11,
                ),
              ),
              Container(
                width: 26,
                height: 26,
                decoration: const BoxDecoration(
                  color: AppColors.lime,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: const Icon(
                  LucideIcons.check,
                  size: 15,
                  color: AppColors.onLime,
                ),
              ),
              if (reps > 0)
                Text(
                  '$reps reps',
                  style: AppTypography.caption.copyWith(
                    color: Colors.white70,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                )
              else
                const SizedBox(height: 10),
            ],
          ),
        );
        break;

      case DayTileState.today:
        content = Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: AppRadii.tileRadius,
            boxShadow: AppColors.glow(AppColors.lime, alpha: 0.22, blur: 18),
            border: Border.all(color: AppColors.primaryBlue, width: 2),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: AppColors.primaryBlueSoft,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: const Icon(
                  LucideIcons.flame,
                  size: 18,
                  color: AppColors.primaryBlue,
                ),
              ),
              Text(
                'TODAY',
                style: AppTypography.caption.copyWith(
                  color: AppColors.primaryBlue,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        );
        break;

      case DayTileState.empty:
        content = Container(
          decoration: BoxDecoration(
            gradient: AppColors.frostedDayGradient,
            borderRadius: AppRadii.tileRadius,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Day $dayNumber',
                style: AppTypography.caption.copyWith(
                  color: AppColors.inkSecondary,
                  fontWeight: FontWeight.w700,
                  fontSize: 11,
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                  color: Color(0x33FFFFFF),
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
        );
        break;
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          dayLabel,
          style: AppTypography.overline.copyWith(
            fontSize: 10,
            color: state == DayTileState.today ? AppColors.primaryBlue : AppColors.inkSecondary,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 6),
        GestureDetector(
          onTap: onTap,
          child: SizedBox(
            width: 58,
            height: 74,
            child: SpringPopTile(
              trigger: state == DayTileState.completed,
              child: content,
            ),
          ),
        ),
      ],
    );
  }
}
