import 'package:flutter/material.dart';

/// 4pt base grid spacing tokens
class AppSpacing {
  AppSpacing._();

  static const double xxs = 4.0;
  static const double xs = 8.0;
  static const double sm = 12.0;
  static const double md = 16.0;
  static const double lg = 20.0;
  static const double xl = 24.0;
  static const double xxl = 32.0;
  static const double xxxl = 40.0;

  /// Standard screen edge padding
  static const double screenHorizontal = 20.0;
  static const double screenVertical = 16.0;

  /// Standard card internal padding
  static const EdgeInsets cardPadding = EdgeInsets.all(16.0);
  static const EdgeInsets cardPaddingLg = EdgeInsets.all(20.0);
}
