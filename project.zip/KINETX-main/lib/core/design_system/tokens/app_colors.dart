import 'package:flutter/material.dart';

/// Design system color tokens — "KINETX Pulse": a bold, energetic dark theme.
/// Near-black surfaces, electric blue + neon lime accents, and glow-style
/// shadows replace the previous light/pastel palette so the app reads as a
/// high-energy, immersive fitness companion (think night-mode gym HUD).
class AppColors {
  AppColors._();

  // Core Dark Palette
  static const Color pageBackground = Color(0xFF0A0E16); // near-black, cool navy undertone
  static const Color surface = Color(0xFF161B26); // elevated card surface
  static const Color surfaceSoft = Color(0xFF10141D); // recessed panels / inputs
  static const Color chipGray = Color(0xFF1E2530); // neutral dark chip background
  static const Color ink = Color(0xFFF5F7FA); // primary text/icons (near-white)
  static const Color inkSecondary = Color(0xFF98A5B5); // secondary text
  static const Color primaryBlue = Color(0xFF4C9EFF); // electric blue
  static const Color primaryBlueSoft = Color(0xFF17263D); // dark blue halo / selected bg
  static const Color deepNavy = Color(0xFF05070C); // darkest anchor for gradients
  static const Color lime = Color(0xFFC6FF4D); // neon lime — signature CTA / energy accent

  /// Guaranteed-dark color for text/icons drawn ON TOP of bright accent
  /// surfaces (lime buttons, amber warning banners, etc). Unlike [ink], this
  /// never flips with the theme — bright accents always need dark content.
  static const Color onLime = Color(0xFF0A0E16);

  // Semantic Status (brightened for legibility on dark surfaces)
  static const Color success = Color(0xFF3DDC97);
  static const Color warning = Color(0xFFFFB238);
  static const Color danger = Color(0xFFFF5C5C);

  // Hairline borders for definition on dark/near-black surfaces
  static const Color hairline = Color(0x1FFFFFFF); // ~12% white
  static const Color hairlineFaint = Color(0x12FFFFFF); // ~7% white

  // Elevation shadow (subtle — dark UIs lean on lighter surfaces + hairlines
  // for depth more than drop shadows, but a soft shadow still helps on the
  // gradient marketing screens).
  static const List<BoxShadow> cardShadow = [
    BoxShadow(
      color: Color(0x59000000),
      blurRadius: 28,
      offset: Offset(0, 12),
    ),
  ];

  static const List<BoxShadow> softShadow = [
    BoxShadow(
      color: Color(0x3D000000),
      blurRadius: 14,
      offset: Offset(0, 6),
    ),
  ];

  /// Reusable colored glow shadow for energetic CTAs / hero elements —
  /// e.g. `boxShadow: AppColors.glow(AppColors.lime)`.
  static List<BoxShadow> glow(Color color, {double alpha = 0.42, double blur = 26}) {
    return [
      BoxShadow(
        color: color.withValues(alpha: alpha),
        blurRadius: blur,
        offset: const Offset(0, 10),
      ),
    ];
  }

  // Signature Diagonal/Vertical Energy Gradient (deepNavy -> blue -> electric blue)
  static const LinearGradient gradientBlue = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0xFF05070C),
      Color(0xFF1D4FA6),
      Color(0xFF4C9EFF),
    ],
  );

  // Completed Day Tile Gradient (navy -> vivid electric blue)
  static const LinearGradient completedDayGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0xFF0C1E33),
      Color(0xFF2166D6),
    ],
  );

  // Dim / No-Data Day Tile Gradient — recedes quietly against completed & today tiles
  static const LinearGradient frostedDayGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0xFF141924),
      Color(0xFF1B2230),
    ],
  );

  // Backward compatibility aliases mapping to the new Dark design system
  static const Color background = pageBackground;
  static const Color surface1 = surface;
  static const Color surface2 = surfaceSoft;
  static const Color border = hairline;
  static const Color borderFocused = primaryBlue;
  static const Color textPrimary = ink;
  static const Color textSecondary = inkSecondary;
  static const Color textTertiary = Color(0xFF5C6675);
  static const Color textMuted = inkSecondary;
  static const Color brandAccent = lime;
  static const Color brandAccentDark = onLime;
  static const Color surfaceBorder = hairline;
  static const Color surfaceElevated = surface;
  static const Color primaryAction = lime;
  static const Color primaryActionText = onLime;
  static const Color emerald = success;
  static const Color crimson = danger;
  static const Color error = danger;
}
