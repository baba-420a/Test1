import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/// Design system typography tokens.
/// Headings and numbers: Montserrat (weights 700/800, letterSpacing -0.5)
/// Body and UI: Inter (400/500/600)
class AppTypography {
  AppTypography._();

  // Tabular figures feature for precise alignment of stats and counters
  static const List<FontFeature> tabularFigures = [
    FontFeature.tabularFigures(),
  ];

  /// Display 32 — Hero stats, main numbers, page titles
  static TextStyle get display => GoogleFonts.montserrat(
        fontSize: 30,
        fontWeight: FontWeight.w800,
        color: AppColors.ink,
        letterSpacing: -0.5,
        fontFeatures: tabularFigures,
      );

  /// Giant Rep Counter — Live workout display
  static TextStyle get giantCounter => GoogleFonts.montserrat(
        fontSize: 64,
        fontWeight: FontWeight.w800,
        color: AppColors.ink,
        letterSpacing: -1.0,
        height: 1.0,
        fontFeatures: tabularFigures,
      );

  /// Marketing Headline — Huge white 2-line centered headline (from references)
  static TextStyle get marketingHeadline => GoogleFonts.montserrat(
        fontSize: 34,
        fontWeight: FontWeight.w800,
        color: Colors.white,
        letterSpacing: -0.5,
        height: 1.15,
      );

  /// Headline 24 — Primary card headlines, section titles
  static TextStyle get headline => GoogleFonts.montserrat(
        fontSize: 22,
        fontWeight: FontWeight.w800,
        color: AppColors.ink,
        letterSpacing: -0.5,
        fontFeatures: tabularFigures,
      );

  /// Title 18 — Card titles, sheet headers, emphasized list items
  static TextStyle get title => GoogleFonts.montserrat(
        fontSize: 17,
        fontWeight: FontWeight.w700,
        color: AppColors.ink,
        letterSpacing: -0.4,
      );

  /// Body 15 — Primary reading text, descriptions
  static TextStyle get body => GoogleFonts.inter(
        fontSize: 14,
        fontWeight: FontWeight.w400,
        color: AppColors.inkSecondary,
        height: 1.45,
      );

  /// Body Medium 15 — Button labels, highlighted body text
  static TextStyle get bodyMedium => GoogleFonts.inter(
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: AppColors.ink,
      );

  /// Body Bold 15 — High-emphasis body copy
  static TextStyle get bodyBold => GoogleFonts.inter(
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: AppColors.ink,
      );

  /// Caption 13 — Secondary details, metadata rows
  static TextStyle get caption => GoogleFonts.inter(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: AppColors.inkSecondary,
      );

  /// Overline 11 — Uppercase category badges, stat labels
  static TextStyle get overline => GoogleFonts.inter(
        fontSize: 11,
        fontWeight: FontWeight.w600,
        color: AppColors.inkSecondary,
        letterSpacing: 1.2,
      );

  // Backward compatibility alias
  static TextStyle get titleMedium => title;
  static TextStyle get titleLarge => headline;
  static TextStyle get titleSmall => title.copyWith(fontSize: 15);
  static TextStyle get displayLarge => display;
  static TextStyle get displayMedium => display;
  static TextStyle get bodySmall => caption;
  static TextStyle get sectionHeader => overline;
  static TextStyle get repCounter => giantCounter;
  static TextStyle get statNumber => display;
}
