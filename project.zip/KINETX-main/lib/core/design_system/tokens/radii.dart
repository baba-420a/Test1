import 'package:flutter/material.dart';

/// Design system border radius tokens matching reference styling:
/// Radii: pills = full; buttons/banners 16–24; cards 20–24; tiles 16
class AppRadii {
  AppRadii._();

  static const double chip = 999.0; // Pills are full rounded
  static const double tile = 16.0;
  static const double button = 18.0;
  static const double banner = 22.0;
  static const double card = 22.0;
  static const double bottomSheet = 24.0;
  static const double pill = 999.0;

  static const BorderRadius chipRadius = BorderRadius.all(Radius.circular(chip));
  static const BorderRadius tileRadius = BorderRadius.all(Radius.circular(tile));
  static const BorderRadius buttonRadius = BorderRadius.all(Radius.circular(button));
  static const BorderRadius bannerRadius = BorderRadius.all(Radius.circular(banner));
  static const BorderRadius cardRadius = BorderRadius.all(Radius.circular(card));
  static const BorderRadius bottomSheetRadius = BorderRadius.vertical(top: Radius.circular(bottomSheet));
  static const BorderRadius pillRadius = BorderRadius.all(Radius.circular(pill));
}
