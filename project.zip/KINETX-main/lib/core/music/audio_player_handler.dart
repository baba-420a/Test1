import 'dart:async';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

/// Background audio handler that manages audio playback and system lock-screen / notification controls
class AppAudioHandler extends BaseAudioHandler with SeekHandler {
  final AudioPlayer _player = AudioPlayer();

  VoidCallback? onSkipNext;
  VoidCallback? onSkipPrevious;

  double _preDuckVolume = 1.0;
  bool _isDucked = false;

  AudioPlayer get player => _player;

  AppAudioHandler() {
    _initStreams();
  }

  void _initStreams() {
    // Forward playback events from just_audio to audio_service
    _player.playbackEventStream.listen((PlaybackEvent event) {
      final playing = _player.playing;
      playbackState.add(playbackState.value.copyWith(
        controls: [
          MediaControl.skipToPrevious,
          if (playing) MediaControl.pause else MediaControl.play,
          MediaControl.stop,
          MediaControl.skipToNext,
        ],
        systemActions: const {
          MediaAction.seek,
          MediaAction.seekForward,
          MediaAction.seekBackward,
        },
        androidCompactActionIndices: const [0, 1, 3],
        processingState: const {
          ProcessingState.idle: AudioProcessingState.idle,
          ProcessingState.loading: AudioProcessingState.loading,
          ProcessingState.buffering: AudioProcessingState.buffering,
          ProcessingState.ready: AudioProcessingState.ready,
          ProcessingState.completed: AudioProcessingState.completed,
        }[_player.processingState]!,
        playing: playing,
        updatePosition: _player.position,
        bufferedPosition: _player.bufferedPosition,
        speed: _player.speed,
        queueIndex: event.currentIndex,
      ));
    });

    // Auto-advance when track finishes
    _player.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        skipToNext();
      }
    });
  }

  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> stop() async {
    await _player.stop();
    await super.stop();
  }

  @override
  Future<void> skipToNext() async {
    onSkipNext?.call();
  }

  @override
  Future<void> skipToPrevious() async {
    onSkipPrevious?.call();
  }

  Future<void> setAudioSource(Uri uri, MediaItem item) async {
    try {
      mediaItem.add(item);
      await _player.setAudioSource(AudioSource.uri(uri));
    } catch (e) {
      debugPrint('Error setting audio source: $e');
    }
  }

  Future<void> setVolume(double volume) async {
    if (!_isDucked) {
      _preDuckVolume = volume;
    }
    await _player.setVolume(volume);
  }

  /// Lowers volume to 0.25 while Voice Coach speaks
  void duck() {
    _isDucked = true;
    _preDuckVolume = _player.volume;
    _player.setVolume(0.25);
  }

  /// Restores volume to user's selected level after speech ends
  void unduck() {
    _isDucked = false;
    _player.setVolume(_preDuckVolume);
  }
}
