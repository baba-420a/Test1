import 'dart:async';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../tts/voice_coach_service.dart';
import 'audio_player_handler.dart';

class MusicController {
  MusicController._internal();
  static final MusicController instance = MusicController._internal();

  final OnAudioQuery _audioQuery = OnAudioQuery();
  AppAudioHandler? _handler;
  bool _isInitialized = false;

  List<SongModel> _allSongs = [];
  List<SongModel> _queue = [];
  int _currentIndex = -1;

  final ValueNotifier<SongModel?> currentSongNotifier = ValueNotifier<SongModel?>(null);
  final ValueNotifier<bool> isPlayingNotifier = ValueNotifier<bool>(false);
  final ValueNotifier<double> volumeNotifier = ValueNotifier<double>(1.0);
  final ValueNotifier<bool> hasPermissionNotifier = ValueNotifier<bool>(false);

  List<SongModel> get allSongs => _allSongs;
  List<SongModel> get queue => _queue;
  SongModel? get currentSong => currentSongNotifier.value;
  bool get isPlaying => isPlayingNotifier.value;
  double get volume => volumeNotifier.value;
  Stream<Duration>? get positionStream => _handler?.player.positionStream;
  Stream<Duration?>? get durationStream => _handler?.player.durationStream;

  Future<void> init() async {
    if (_isInitialized) return;

    try {
      _handler = await AudioService.init(
        builder: () => AppAudioHandler(),
        config: const AudioServiceConfig(
          androidNotificationChannelId: 'com.fitnessapp.kinetx.audio',
          androidNotificationChannelName: 'KINETX Workout Music',
          androidNotificationOngoing: true,
          androidStopForegroundOnPause: true,
        ),
      );

      _handler!.onSkipNext = next;
      _handler!.onSkipPrevious = previous;

      _handler!.player.playerStateStream.listen((state) {
        isPlayingNotifier.value = state.playing;
      });

      // Hook up VoiceCoach TTS ducking
      VoiceCoachService.onDuckMusic = (bool duck) {
        if (duck) {
          this.duck();
        } else {
          unduck();
        }
      };

      // Restore volume & queue from SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      final savedVolume = prefs.getDouble('music_volume') ?? 1.0;
      volumeNotifier.value = savedVolume;
      await _handler!.setVolume(savedVolume);

      _isInitialized = true;
      await checkPermissionsAndLoadSongs();
    } catch (e) {
      debugPrint('MusicController init error: $e');
    }
  }

  Future<bool> checkPermissionsAndLoadSongs() async {
    try {
      bool permissionStatus = await _audioQuery.permissionsStatus();
      if (!permissionStatus) {
        permissionStatus = await _audioQuery.permissionsRequest();
      }

      hasPermissionNotifier.value = permissionStatus;

      if (permissionStatus) {
        _allSongs = await _audioQuery.querySongs(
          sortType: SongSortType.TITLE,
          orderType: OrderType.ASC_OR_SMALLER,
          uriType: UriType.EXTERNAL,
        );

        // Filter out very short ringtones/notifications (< 10 seconds)
        _allSongs = _allSongs.where((s) => (s.duration ?? 0) > 10000).toList();

        // Restore last saved queue
        final prefs = await SharedPreferences.getInstance();
        final lastQueueIds = prefs.getStringList('music_queue_ids') ?? [];
        final lastSongId = prefs.getInt('music_last_song_id');

        if (lastQueueIds.isNotEmpty && _allSongs.isNotEmpty) {
          final Set<String> idSet = lastQueueIds.toSet();
          _queue = _allSongs.where((s) => idSet.contains(s.id.toString())).toList();
        }
        if (_queue.isEmpty && _allSongs.isNotEmpty) {
          _queue = List.from(_allSongs);
        }

        if (lastSongId != null && _queue.isNotEmpty) {
          final foundIndex = _queue.indexWhere((s) => s.id == lastSongId);
          if (foundIndex != -1) {
            _currentIndex = foundIndex;
            currentSongNotifier.value = _queue[_currentIndex];
          }
        }
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error querying audio songs: $e');
      return false;
    }
  }

  Future<void> playSong(SongModel song, [List<SongModel>? newQueue]) async {
    if (_handler == null) await init();

    if (newQueue != null && newQueue.isNotEmpty) {
      _queue = List.from(newQueue);
    } else if (_queue.isEmpty) {
      _queue = List.from(_allSongs);
    }

    _currentIndex = _queue.indexWhere((s) => s.id == song.id);
    if (_currentIndex == -1) {
      _queue.insert(0, song);
      _currentIndex = 0;
    }

    currentSongNotifier.value = song;

    final mediaItem = MediaItem(
      id: song.id.toString(),
      title: song.title,
      artist: (song.artist == null || song.artist == '<unknown>') ? 'Local Artist' : song.artist!,
      album: song.album ?? 'KINETX Local',
      duration: Duration(milliseconds: song.duration ?? 0),
    );

    final uri = Uri.parse(song.uri ?? song.data);
    await _handler!.setAudioSource(uri, mediaItem);
    await _handler!.play();

    _saveQueueState();
  }

  Future<void> play() async {
    if (_handler == null) return;
    if (currentSongNotifier.value == null && _queue.isNotEmpty) {
      await playSong(_queue.first);
    } else {
      await _handler!.play();
    }
  }

  Future<void> pause() async {
    await _handler?.pause();
  }

  Future<void> togglePlayPause() async {
    if (isPlaying) {
      await pause();
    } else {
      await play();
    }
  }

  Future<void> next() async {
    if (_queue.isEmpty) return;
    final nextIndex = (_currentIndex + 1) % _queue.length;
    await playSong(_queue[nextIndex]);
  }

  Future<void> previous() async {
    if (_queue.isEmpty) return;
    final prevIndex = (_currentIndex - 1 + _queue.length) % _queue.length;
    await playSong(_queue[prevIndex]);
  }

  Future<void> seek(Duration position) async {
    await _handler?.seek(position);
  }

  Future<void> setVolume(double volume) async {
    volumeNotifier.value = volume;
    await _handler?.setVolume(volume);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('music_volume', volume);
  }

  void duck() {
    _handler?.duck();
  }

  void unduck() {
    _handler?.unduck();
  }

  Future<void> _saveQueueState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (currentSongNotifier.value != null) {
        await prefs.setInt('music_last_song_id', currentSongNotifier.value!.id);
      }
      final queueIds = _queue.map((s) => s.id.toString()).toList();
      await prefs.setStringList('music_queue_ids', queueIds);
    } catch (_) {}
  }
}
