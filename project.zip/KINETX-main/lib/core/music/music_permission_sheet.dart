import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:permission_handler/permission_handler.dart';
import '../design_system/components/primary_button.dart';
import '../design_system/tokens/app_colors.dart';
import 'music_controller.dart';

class MusicPermissionSheet extends StatelessWidget {
  const MusicPermissionSheet({super.key});

  static Future<void> show(BuildContext context) {
    return showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const MusicPermissionSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 44,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.chipGray,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 24),
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: AppColors.primaryBlueSoft,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              LucideIcons.headphones,
              color: AppColors.primaryBlue,
              size: 30,
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'Local Music Access',
            textAlign: TextAlign.center,
            style: GoogleFonts.montserrat(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'KINETX plays workout music stored directly on your phone with zero data usage or streaming. To browse and play your local audio files, please grant audio permission.',
            textAlign: TextAlign.center,
            style: GoogleFonts.montserrat(
              fontSize: 14,
              height: 1.4,
              color: AppColors.inkSecondary,
            ),
          ),
          const SizedBox(height: 24),
          PrimaryButton(
            label: 'Allow Music Access',
            icon: LucideIcons.checkCircle2,
            onPressed: () async {
              Navigator.pop(context);
              final granted = await MusicController.instance.checkPermissionsAndLoadSongs();
              if (!granted) {
                await openAppSettings();
              }
            },
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Not Now',
              style: GoogleFonts.montserrat(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppColors.inkSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
