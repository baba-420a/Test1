import 'package:permission_handler/permission_handler.dart';

class PermissionService {
  PermissionService._();

  static Future<bool> isCameraGranted() async {
    return await Permission.camera.isGranted;
  }

  static Future<bool> requestCamera() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  static Future<bool> isNotificationGranted() async {
    return await Permission.notification.isGranted;
  }

  static Future<bool> requestNotification() async {
    final status = await Permission.notification.request();
    return status.isGranted;
  }

  /// Automatically requests camera and notification permissions when app opens
  static Future<Map<Permission, PermissionStatus>> requestInitialAppPermissions() async {
    final List<Permission> toRequest = [];
    if (!await Permission.camera.isGranted) {
      toRequest.add(Permission.camera);
    }
    if (!await Permission.notification.isGranted) {
      toRequest.add(Permission.notification);
    }
    if (toRequest.isNotEmpty) {
      return await toRequest.request();
    }
    return {};
  }

  static Future<bool> openSettings() async {
    return await openAppSettings();
  }
}
