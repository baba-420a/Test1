import 'package:flutter/material.dart';

/// Design system color palette inspired by the reference design:
/// Deep obsidian, dark crimson / wine gradients, crisp white pill accents,
/// and neon emerald execution cues.
class AppColors {
  AppColors._();

  // Backgrounds
  static const Color background = Color(0xFF0C0C0E);
  static const Color backgroundSecondary = Color(0xFF121216);
  static const Color surface = Color(0xFF16161A);
  static const Color surfaceElevated = Color(0xFF1F1F24);
  static const Color surfaceBorder = Color(0xFF282832);

  // Brand Accents & Wine Glow
  static const Color crimson = Color(0xFFDC2626);
  static const Color crimsonDark = Color(0xFF7F1D1D);
  static const Color wine = Color(0xFF4A0E17);

  // Primary Action (Crisp White Pill from reference)
  static const Color primaryAction = Color(0xFFFFFFFF);
  static const Color primaryActionText = Color(0xFF0C0C0E);

  // Execution & Accuracy Accents (Emerald Green)
  static const Color emerald = Color(0xFF22C55E);
  static const Color emeraldLight = Color(0xFF4ADE80);
  static const Color emeraldDark = Color(0xFF15803D);

  // Backward compatibility & theme mappings
  static const Color primary = emerald;
  static const Color primaryLight = emeraldLight;
  static const Color primaryDark = emeraldDark;
  static const Color secondaryLight = Color(0xFF67E8F9);

  // Status & Badges
  static const Color warning = Color(0xFFF97316); // Amber / Difficulty
  static const Color error = Color(0xFFEF4444); // Rep rejected
  static const Color secondary = Color(0xFF06B6D4); // Cyan / Motion

  // Reference Tag Colors
  static const Color tagCrimsonBg = Color(0xFF2D1217);
  static const Color tagCrimsonText = Color(0xFFF87171);

  static const Color tagEmeraldBg = Color(0xFF12281D);
  static const Color tagEmeraldText = Color(0xFF34D399);

  // Typography
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFA1A1AA);
  static const Color textMuted = Color(0xFF71717A);

  // Gradients
  static const LinearGradient wineHeroGradient = LinearGradient(
    colors: [
      Color(0xFF5B101D),
      Color(0xFF2C0B12),
      Color(0xFF0C0C0E),
    ],
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
  );

  static const LinearGradient cardGradient = LinearGradient(
    colors: [Color(0xFF1B1B22), Color(0xFF141418)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient buttonPillGradient = LinearGradient(
    colors: [Color(0xFFFFFFFF), Color(0xFFE4E4E7)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient primaryGradient = wineHeroGradient;
  static const LinearGradient heroWineGradient = wineHeroGradient;
}
