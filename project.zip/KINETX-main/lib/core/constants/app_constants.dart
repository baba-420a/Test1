class AppConstants {
  AppConstants._();

  static const String appName = 'KINETX';
  static const String appVersion = '1.0.0';

  // Storage Keys
  static const String keyOnboardingCompleted = 'onboarding_completed';
  static const String keyUserProfile = 'user_profile';
  static const String keyNotificationsEnabled = 'notifications_enabled';
  static const String keyCameraMirror = 'camera_mirror';

  // Exercise IDs
  static const String exerciseSquats = 'squats';
  static const String exercisePushups = 'pushups';
  static const String exerciseBicepCurls = 'bicep_curls';

  // Default Form Thresholds
  static const double defaultMinFormScore = 70.0;
  static const double defaultSquatBottomAngle = 100.0;
  static const double defaultSquatStandingAngle = 160.0;
  static const double defaultPushupBottomAngle = 90.0;
  static const double defaultPushupTopAngle = 160.0;
  static const double defaultCurlContractedAngle = 50.0;
  static const double defaultCurlExtendedAngle = 160.0;
}
