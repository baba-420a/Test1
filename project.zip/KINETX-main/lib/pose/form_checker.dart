class FormFeedback {
  final double score;
  final bool isValid;
  final String message;
  final String? warning;

  const FormFeedback({
    required this.score,
    required this.isValid,
    required this.message,
    this.warning,
  });

  static const FormFeedback ready = FormFeedback(
    score: 100,
    isValid: true,
    message: 'Ready. Begin your exercise.',
  );
}
