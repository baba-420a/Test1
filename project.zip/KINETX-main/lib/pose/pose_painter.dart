import 'package:flutter/material.dart';
import '../core/design_system/tokens/app_colors.dart';
import 'pose_landmark.dart';

/// Renders a real-time biomechanical posture skeleton over the live camera preview.
/// Shows Volt accent posture lines, spine neutrality line, and joint angle indicator.
/// Flashes danger red when form deviation or rejected rep is detected.
class PosePainter extends CustomPainter {
  final List<PoseLandmark> landmarks;
  final Size imageSize;
  final bool isFrontCamera;
  final bool isValidForm;
  final double currentAngle;

  PosePainter({
    required this.landmarks,
    required this.imageSize,
    required this.isFrontCamera,
    required this.isValidForm,
    required this.currentAngle,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (landmarks.isEmpty || imageSize.width == 0 || imageSize.height == 0) return;

    final double scaleX = size.width / imageSize.width;
    final double scaleY = size.height / imageSize.height;

    // High-visibility Primary Blue posture bone paint, flashes danger red when form deviates
    final linePaint = Paint()
      ..color = isValidForm ? AppColors.primaryBlue : AppColors.danger
      ..strokeWidth = 3.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    // Clean white spine neutrality line
    final spinePaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 3.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final jointInnerPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    final jointRingPaint = Paint()
      ..color = isValidForm ? AppColors.primaryBlue : AppColors.danger
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    Offset? getOffset(int index) {
      for (final l in landmarks) {
        if (l.index == index && l.likelihood > 0.35) {
          double px = l.x * scaleX;
          // Mirror horizontally for front-facing camera for natural mirror reflection
          if (isFrontCamera) {
            px = size.width - px;
          }
          final py = l.y * scaleY;
          return Offset(px, py);
        }
      }
      return null;
    }

    void drawBone(int a, int b, {Paint? customPaint}) {
      final pA = getOffset(a);
      final pB = getOffset(b);
      if (pA != null && pB != null) {
        final p = customPaint ?? linePaint;
        canvas.drawLine(pA, pB, p);
      }
    }

    // 1. Draw Upper Body Posture Lines (Shoulders & Arms)
    drawBone(PoseLandmark.leftShoulder, PoseLandmark.rightShoulder);
    drawBone(PoseLandmark.leftShoulder, PoseLandmark.leftElbow);
    drawBone(PoseLandmark.leftElbow, PoseLandmark.leftWrist);
    drawBone(PoseLandmark.rightShoulder, PoseLandmark.rightElbow);
    drawBone(PoseLandmark.rightElbow, PoseLandmark.rightWrist);

    // 2. Draw Torso Frame Posture Lines
    drawBone(PoseLandmark.leftShoulder, PoseLandmark.leftHip);
    drawBone(PoseLandmark.rightShoulder, PoseLandmark.rightHip);
    drawBone(PoseLandmark.leftHip, PoseLandmark.rightHip);

    // 3. Draw Spine Neutrality Centerline (Mid-Shoulder to Mid-Hip)
    final leftSh = getOffset(PoseLandmark.leftShoulder);
    final rightSh = getOffset(PoseLandmark.rightShoulder);
    final leftHp = getOffset(PoseLandmark.leftHip);
    final rightHp = getOffset(PoseLandmark.rightHip);

    if (leftSh != null && rightSh != null && leftHp != null && rightHp != null) {
      final midShoulder = Offset((leftSh.dx + rightSh.dx) / 2, (leftSh.dy + rightSh.dy) / 2);
      final midHip = Offset((leftHp.dx + rightHp.dx) / 2, (leftHp.dy + rightHp.dy) / 2);
      canvas.drawLine(midShoulder, midHip, spinePaint);

      // Head to neck pointer
      final nose = getOffset(PoseLandmark.nose);
      if (nose != null) {
        canvas.drawLine(nose, midShoulder, linePaint);
      }
    }

    // 4. Draw Lower Body Posture Lines (Legs & Depth)
    drawBone(PoseLandmark.leftHip, PoseLandmark.leftKnee);
    drawBone(PoseLandmark.leftKnee, PoseLandmark.leftAnkle);
    drawBone(PoseLandmark.rightHip, PoseLandmark.rightKnee);
    drawBone(PoseLandmark.rightKnee, PoseLandmark.rightAnkle);

    // 5. Draw Joint Rings & Centers
    final keyJoints = [
      PoseLandmark.nose,
      PoseLandmark.leftShoulder,
      PoseLandmark.rightShoulder,
      PoseLandmark.leftElbow,
      PoseLandmark.rightElbow,
      PoseLandmark.leftWrist,
      PoseLandmark.rightWrist,
      PoseLandmark.leftHip,
      PoseLandmark.rightHip,
      PoseLandmark.leftKnee,
      PoseLandmark.rightKnee,
      PoseLandmark.leftAnkle,
      PoseLandmark.rightAnkle,
    ];

    for (final index in keyJoints) {
      final p = getOffset(index);
      if (p != null) {
        canvas.drawCircle(p, 5.0, jointInnerPaint);
        canvas.drawCircle(p, 6.5, jointRingPaint);
      }
    }

    // 6. Draw Joint Angle Floating Tag at Left Knee / Elbow if active
    final targetOffset = getOffset(PoseLandmark.leftKnee) ?? getOffset(PoseLandmark.rightKnee);
    if (targetOffset != null && currentAngle > 0 && currentAngle < 180) {
      final textSpan = TextSpan(
        text: ' ${currentAngle.toInt()}° ',
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11,
          fontWeight: FontWeight.bold,
          backgroundColor: Colors.black87,
        ),
      );
      final textPainter = TextPainter(
        text: textSpan,
        textDirection: TextDirection.ltr,
      );
      textPainter.layout();
      textPainter.paint(canvas, Offset(targetOffset.dx + 12, targetOffset.dy - 8));
    }
  }

  @override
  bool shouldRepaint(covariant PosePainter oldDelegate) {
    return oldDelegate.landmarks != landmarks ||
        oldDelegate.isValidForm != isValidForm ||
        oldDelegate.currentAngle != currentAngle;
  }
}
