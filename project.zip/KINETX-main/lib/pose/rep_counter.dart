import 'dart:math';
import 'pose_landmark.dart';

enum MovementPhase {
  idle,
  starting,
  descending,
  inflection, // bottom for squat/pushup
  ascending,
  completed,
}

class RepCounterResult {
  final int correctReps;
  final int rejectedReps;
  final MovementPhase currentPhase;
  final double currentAngle;
  final double formScore;
  final String feedbackMessage;
  final bool isPersonDetected;
  final String? rejectionReason;

  const RepCounterResult({
    this.correctReps = 0,
    this.rejectedReps = 0,
    this.currentPhase = MovementPhase.idle,
    this.currentAngle = 0.0,
    this.formScore = 100.0,
    this.feedbackMessage = 'Get into position',
    this.isPersonDetected = false,
    this.rejectionReason,
  });

  RepCounterResult copyWith({
    int? correctReps,
    int? rejectedReps,
    MovementPhase? currentPhase,
    double? currentAngle,
    double? formScore,
    String? feedbackMessage,
    bool? isPersonDetected,
    String? rejectionReason,
  }) {
    return RepCounterResult(
      correctReps: correctReps ?? this.correctReps,
      rejectedReps: rejectedReps ?? this.rejectedReps,
      currentPhase: currentPhase ?? this.currentPhase,
      currentAngle: currentAngle ?? this.currentAngle,
      formScore: formScore ?? this.formScore,
      feedbackMessage: feedbackMessage ?? this.feedbackMessage,
      isPersonDetected: isPersonDetected ?? this.isPersonDetected,
      rejectionReason: rejectionReason ?? this.rejectionReason,
    );
  }
}

class ExerciseSignalConfig {
  final String exerciseId;
  final Set<int> primaryCountingLandmarks;
  final Set<int> gatingLandmarks;
  final String primaryMetric;

  const ExerciseSignalConfig({
    required this.exerciseId,
    required this.primaryCountingLandmarks,
    this.gatingLandmarks = const {},
    required this.primaryMetric,
  });

  static const Map<String, ExerciseSignalConfig> configs = {
    'squats': ExerciseSignalConfig(
      exerciseId: 'squats',
      primaryCountingLandmarks: {
        PoseLandmark.leftHip,       // 23
        PoseLandmark.rightHip,      // 24
        PoseLandmark.leftKnee,      // 25
        PoseLandmark.rightKnee,     // 26
        PoseLandmark.leftAnkle,     // 27
        PoseLandmark.rightAnkle,    // 28
      },
      primaryMetric: 'knee angle (23-28)',
    ),
    'pushups': ExerciseSignalConfig(
      exerciseId: 'pushups',
      primaryCountingLandmarks: {
        PoseLandmark.leftShoulder,  // 11
        PoseLandmark.rightShoulder, // 12
        PoseLandmark.leftElbow,     // 13
        PoseLandmark.rightElbow,    // 14
        PoseLandmark.leftWrist,     // 15
        PoseLandmark.rightWrist,    // 16
      },
      gatingLandmarks: {
        PoseLandmark.leftHip,       // 23
        PoseLandmark.rightHip,      // 24
        PoseLandmark.leftAnkle,     // 27
        PoseLandmark.rightAnkle,    // 28
      },
      primaryMetric: 'elbow + trunk line (11-16, 23-28)',
    ),
    'bicep_curls': ExerciseSignalConfig(
      exerciseId: 'bicep_curls',
      primaryCountingLandmarks: {
        PoseLandmark.leftShoulder,  // 11
        PoseLandmark.rightShoulder, // 12
        PoseLandmark.leftElbow,     // 13
        PoseLandmark.rightElbow,    // 14
        PoseLandmark.leftWrist,     // 15
        PoseLandmark.rightWrist,    // 16
      },
      gatingLandmarks: {
        PoseLandmark.leftHip,       // 23
        PoseLandmark.rightHip,      // 24
        PoseLandmark.leftKnee,      // 25
        PoseLandmark.rightKnee,     // 26
        PoseLandmark.leftAnkle,     // 27
        PoseLandmark.rightAnkle,    // 28
      },
      primaryMetric: 'elbow angle + elbow stability + leg gate (11-16 only for counting)',
    ),
  };

  static ExerciseSignalConfig forExercise(String exerciseId) {
    if (exerciseId == 'pushups') return configs['pushups']!;
    if (exerciseId == 'bicep_curls' || exerciseId.contains('curl')) {
      return configs['bicep_curls']!;
    }
    return configs['squats']!;
  }
}

class _LegSample {
  final DateTime timestamp;
  final double kneeAngle;
  final double hipAnkleDisp;

  const _LegSample({
    required this.timestamp,
    required this.kneeAngle,
    required this.hipAnkleDisp,
  });
}

/// Automatic rep counter driven by real-time joint angles and biomechanical state machines
class AutomaticRepCounter {
  final String exerciseId;

  int _correctReps = 0;
  int _rejectedReps = 0;
  MovementPhase _phase = MovementPhase.idle;
  double _minAngleObserved = 180.0;
  double _currentAngle = 180.0;
  double _formScore = 100.0;
  String _feedbackMessage = 'Position your full body in frame';
  String? _rejectionReason;

  // Bicep Curl State
  double? _smoothedCurlElbowAngle;
  DateTime? _curlRepStartTime;
  double _minCurlAngleObserved = 180.0;
  bool _hadIncompleteFlexion = false;
  bool _hadElbowInstability = false;
  bool _wristArcedProperly = false;
  bool _hadLegMotionDuringRep = false;
  Point<double>? _startElbowRelHip;
  Point<double>? _startElbowRelShoulder;
  final List<_LegSample> _legWindow = [];

  AutomaticRepCounter({required this.exerciseId});

  int get correctReps => _correctReps;
  int get rejectedReps => _rejectedReps;
  MovementPhase get phase => _phase;

  void reset() {
    _correctReps = 0;
    _rejectedReps = 0;
    _phase = MovementPhase.idle;
    _minAngleObserved = 180.0;
    _currentAngle = 180.0;
    _formScore = 100.0;
    _feedbackMessage = 'Get into position';
    _rejectionReason = null;
    _smoothedElbowAngle = null;
    _resetPushupRepForm();
    _resetCurlRepForm();
    _smoothedCurlElbowAngle = null;
    _legWindow.clear();
  }

  RepCounterResult processLandmarks(List<PoseLandmark> landmarks, [DateTime? timestamp]) {
    final now = timestamp ?? DateTime.now();
    if (landmarks.isEmpty) {
      return RepCounterResult(
        correctReps: _correctReps,
        rejectedReps: _rejectedReps,
        currentPhase: MovementPhase.idle,
        currentAngle: _currentAngle,
        formScore: _formScore,
        feedbackMessage: 'No person detected. Step back into frame.',
        isPersonDetected: false,
      );
    }

    if (exerciseId == 'pushups') {
      return _processPushups(landmarks, now);
    } else if (exerciseId == 'bicep_curls' || exerciseId.contains('curl')) {
      return _processBicepCurls(landmarks, now);
    } else {
      // Default & Squats: Hip-Knee-Ankle chain
      return _processSquats(landmarks);
    }
  }

  RepCounterResult _processSquats(List<PoseLandmark> landmarks) {
    // Find left & right hip, knee, ankle
    final leftHip = _findLandmark(landmarks, PoseLandmark.leftHip);
    final leftKnee = _findLandmark(landmarks, PoseLandmark.leftKnee);
    final leftAnkle = _findLandmark(landmarks, PoseLandmark.leftAnkle);

    final rightHip = _findLandmark(landmarks, PoseLandmark.rightHip);
    final rightKnee = _findLandmark(landmarks, PoseLandmark.rightKnee);
    final rightAnkle = _findLandmark(landmarks, PoseLandmark.rightAnkle);

    // Pick side with highest visibility
    PoseLandmark? hip, knee, ankle;
    final leftLikelihood = (leftHip?.likelihood ?? 0) + (leftKnee?.likelihood ?? 0) + (leftAnkle?.likelihood ?? 0);
    final rightLikelihood = (rightHip?.likelihood ?? 0) + (rightKnee?.likelihood ?? 0) + (rightAnkle?.likelihood ?? 0);

    if (leftLikelihood >= rightLikelihood && leftLikelihood > 1.5) {
      hip = leftHip;
      knee = leftKnee;
      ankle = leftAnkle;
    } else if (rightLikelihood > 1.5) {
      hip = rightHip;
      knee = rightKnee;
      ankle = rightAnkle;
    }

    if (hip == null || knee == null || ankle == null) {
      return RepCounterResult(
        correctReps: _correctReps,
        rejectedReps: _rejectedReps,
        currentPhase: _phase,
        currentAngle: _currentAngle,
        formScore: _formScore,
        feedbackMessage: 'Make sure your legs and hips are visible',
        isPersonDetected: true,
      );
    }

    final double kneeAngle = PoseLandmark.calculateAngle(hip, knee, ankle);
    _currentAngle = kneeAngle;

    // Squat State Machine
    // Standing: angle ~ 160-180
    // Squat depth: angle <= 100
    switch (_phase) {
      case MovementPhase.idle:
      case MovementPhase.starting:
      case MovementPhase.completed:
        if (kneeAngle > 155.0) {
          _phase = MovementPhase.starting;
          _feedbackMessage = 'Standing tall. Begin descent.';
          _minAngleObserved = 180.0;
        } else if (kneeAngle < 145.0) {
          _phase = MovementPhase.descending;
          _minAngleObserved = kneeAngle;
          _feedbackMessage = 'Descending... Keep chest up!';
        }
        break;

      case MovementPhase.descending:
        if (kneeAngle < _minAngleObserved) {
          _minAngleObserved = kneeAngle;
        }

        if (kneeAngle <= 100.0) {
          _phase = MovementPhase.inflection;
          _feedbackMessage = 'Great depth reached! Now drive upward.';
        } else if (kneeAngle > _minAngleObserved + 15.0) {
          // Began rising early without reaching full depth
          _phase = MovementPhase.ascending;
          _feedbackMessage = 'Rising... (Depth was shallow)';
        }
        break;

      case MovementPhase.inflection:
        if (kneeAngle < _minAngleObserved) {
          _minAngleObserved = kneeAngle;
        }
        if (kneeAngle > _minAngleObserved + 10.0) {
          _phase = MovementPhase.ascending;
          _feedbackMessage = 'Driving up through heels!';
        }
        break;

      case MovementPhase.ascending:
        if (kneeAngle > 155.0) {
          // Rep completed - validate depth
          if (_minAngleObserved <= 100.0) {
            _correctReps++;
            _formScore = min(100.0, max(85.0, 100.0 - (_minAngleObserved - 85.0).abs()));
            _feedbackMessage = 'Rep Counted! Excellent full depth.';
            _rejectionReason = null;
          } else {
            _rejectedReps++;
            _formScore = 60.0;
            _feedbackMessage = 'Rep Rejected: Incomplete depth (${_minAngleObserved.toInt()}°). Go lower!';
            _rejectionReason = 'Incomplete squat depth';
          }
          _phase = MovementPhase.completed;
          _minAngleObserved = 180.0;
        }
        break;
    }

    return RepCounterResult(
      correctReps: _correctReps,
      rejectedReps: _rejectedReps,
      currentPhase: _phase,
      currentAngle: _currentAngle,
      formScore: _formScore,
      feedbackMessage: _feedbackMessage,
      isPersonDetected: true,
      rejectionReason: _rejectionReason,
    );
  }

  // Push-up v2 State
  double? _smoothedElbowAngle;
  DateTime? _repStartTime;
  DateTime? _bottomEnteredTime;
  int _bottomDwellMs = 0;
  bool _hadHipSag = false;
  bool _hadPike = false;
  bool _hadHandsMisaligned = false;
  bool _hadIncompleteDepth = false;
  bool _hadIncompleteLockout = false;
  double _maxAngleObservedInAscent = 0.0;

  static const Set<int> pushupLandmarkWhitelist = {
    PoseLandmark.leftShoulder,  // 11
    PoseLandmark.rightShoulder, // 12
    PoseLandmark.leftElbow,     // 13
    PoseLandmark.rightElbow,    // 14
    PoseLandmark.leftWrist,     // 15
    PoseLandmark.rightWrist,    // 16
    PoseLandmark.leftHip,       // 23
    PoseLandmark.rightHip,      // 24
    PoseLandmark.leftAnkle,     // 27
    PoseLandmark.rightAnkle,    // 28
  };

  void _resetPushupRepForm() {
    _hadHipSag = false;
    _hadPike = false;
    _hadHandsMisaligned = false;
    _hadIncompleteDepth = false;
    _hadIncompleteLockout = false;
    _maxAngleObservedInAscent = 0.0;
    _bottomDwellMs = 0;
    _bottomEnteredTime = null;
    _repStartTime = null;
  }

  RepCounterResult _processPushups(List<PoseLandmark> landmarks, [DateTime? timestamp]) {
    final now = timestamp ?? DateTime.now();
    // 1. Landmark Whitelist Filtering (MediaPipe 11,12,13,14,15,16,23,24,27,28 only)
    final filtered = landmarks.where((l) => pushupLandmarkWhitelist.contains(l.index)).toList();

    final leftShoulder = _findLandmark(filtered, PoseLandmark.leftShoulder);
    final rightShoulder = _findLandmark(filtered, PoseLandmark.rightShoulder);
    final leftElbow = _findLandmark(filtered, PoseLandmark.leftElbow);
    final rightElbow = _findLandmark(filtered, PoseLandmark.rightElbow);
    final leftWrist = _findLandmark(filtered, PoseLandmark.leftWrist);
    final rightWrist = _findLandmark(filtered, PoseLandmark.rightWrist);
    final leftHip = _findLandmark(filtered, PoseLandmark.leftHip);
    final rightHip = _findLandmark(filtered, PoseLandmark.rightHip);
    final leftAnkle = _findLandmark(filtered, PoseLandmark.leftAnkle);
    final rightAnkle = _findLandmark(filtered, PoseLandmark.rightAnkle);

    // 2. Visibility Check (If elbow/wrist visibility < 0.6, pause counting)
    final bool leftArmVisible = (leftShoulder != null && leftElbow != null && leftWrist != null) &&
        (leftElbow.likelihood >= 0.6 && leftWrist.likelihood >= 0.6);
    final bool rightArmVisible = (rightShoulder != null && rightElbow != null && rightWrist != null) &&
        (rightElbow.likelihood >= 0.6 && rightWrist.likelihood >= 0.6);

    if (!leftArmVisible && !rightArmVisible) {
      return RepCounterResult(
        correctReps: _correctReps,
        rejectedReps: _rejectedReps,
        currentPhase: _phase,
        currentAngle: _smoothedElbowAngle ?? 180.0,
        formScore: _formScore,
        feedbackMessage: 'Step fully into frame',
        isPersonDetected: true,
      );
    }

    // 3. Camera Guidance: if trunk line is near-vertical in frame, show "Move camera to a side view"
    final PoseLandmark refShoulder = (leftArmVisible ? leftShoulder : rightShoulder)!;
    final PoseLandmark? refHip = (leftHip?.likelihood ?? 0) >= (rightHip?.likelihood ?? 0) ? leftHip : rightHip;

    String cameraGuidance = '';
    if (refHip != null && refHip.likelihood >= 0.5) {
      final double dx = (refHip.x - refShoulder.x).abs();
      final double dy = (refHip.y - refShoulder.y).abs();
      final double angleFromVertical = atan2(dx, dy) * 180.0 / pi;
      if (angleFromVertical < 35.0) {
        cameraGuidance = 'Move camera to a side view';
      }
    }

    // 4. Primary Signal: Elbow angle averaged over visible sides, smoothed with EMA (alpha = 0.35)
    double? leftAngle;
    if (leftArmVisible) {
      leftAngle = PoseLandmark.calculateAngle(leftShoulder, leftElbow, leftWrist);
    }
    double? rightAngle;
    if (rightArmVisible) {
      rightAngle = PoseLandmark.calculateAngle(rightShoulder, rightElbow, rightWrist);
    }

    double rawAngle;
    if (leftAngle != null && rightAngle != null) {
      rawAngle = (leftAngle + rightAngle) / 2.0;
    } else if (leftAngle != null) {
      rawAngle = leftAngle;
    } else {
      rawAngle = rightAngle!;
    }

    const double alpha = 0.35;
    _smoothedElbowAngle = _smoothedElbowAngle == null
        ? rawAngle
        : (alpha * rawAngle + (1.0 - alpha) * _smoothedElbowAngle!);
    _currentAngle = _smoothedElbowAngle!;

    // 5. Form Checks (Hip Sag, Pike, Hands Under Shoulders)
    final PoseLandmark shoulder = (leftArmVisible ? leftShoulder : rightShoulder)!;
    final PoseLandmark wrist = (leftArmVisible ? leftWrist : rightWrist)!;
    final PoseLandmark? hip = (leftHip?.likelihood ?? 0) >= (rightHip?.likelihood ?? 0) ? leftHip : rightHip;
    final PoseLandmark? ankle = (leftAnkle?.likelihood ?? 0) >= (rightAnkle?.likelihood ?? 0) ? leftAnkle : rightAnkle;

    // Hip sag / Pike check relative to shoulder -> ankle line
    if (hip != null && ankle != null && hip.likelihood >= 0.5 && ankle.likelihood >= 0.5) {
      final double bodyAngle = PoseLandmark.calculateAngle(shoulder, hip, ankle);
      final double angleDeviation = (180.0 - bodyAngle).abs();

      if (angleDeviation > 8.0) {
        final double vx = ankle.x - shoulder.x;
        final double vy = ankle.y - shoulder.y;
        final double vLenSq = vx * vx + vy * vy;
        if (vLenSq > 0.001) {
          final double t = ((hip.x - shoulder.x) * vx + (hip.y - shoulder.y) * vy) / vLenSq;
          final double expectedY = shoulder.y + t * vy;
          if (hip.y > expectedY) {
            _hadHipSag = true;
          } else {
            _hadPike = true;
          }
        }
      }
    }

    // Hands not under shoulders: wrist horizontal offset > 0.35 * torso length
    if (hip != null && hip.likelihood >= 0.5) {
      final double torsoLength = sqrt(pow(hip.x - shoulder.x, 2) + pow(hip.y - shoulder.y, 2));
      final double wristHorizontalOffset = (wrist.x - shoulder.x).abs();
      if (torsoLength > 0.05 && wristHorizontalOffset > 0.35 * torsoLength) {
        _hadHandsMisaligned = true;
      }
    }

    // 6. State Machine with Hysteresis
    // TOP: elbow >= 160° | BOTTOM: elbow <= 100°
    // count rep only on TOP -> BOTTOM -> TOP transition
    // bottom dwell >= 150ms | total rep duration 0.7–6s
    switch (_phase) {
      case MovementPhase.idle:
      case MovementPhase.completed:
      case MovementPhase.starting:
        if (_smoothedElbowAngle! >= 160.0) {
          _phase = MovementPhase.starting;
          _minAngleObserved = _smoothedElbowAngle!;
          _resetPushupRepForm();
          _feedbackMessage = cameraGuidance.isNotEmpty ? cameraGuidance : 'Plank hold locked. Lower chest.';
        } else if (_smoothedElbowAngle! < 155.0) {
          _phase = MovementPhase.descending;
          _repStartTime = now;
          _minAngleObserved = _smoothedElbowAngle!;
          _feedbackMessage = cameraGuidance.isNotEmpty ? cameraGuidance : 'Lowering chest...';
        }
        break;

      case MovementPhase.descending:
        if (_smoothedElbowAngle! < _minAngleObserved) {
          _minAngleObserved = _smoothedElbowAngle!;
        }
        if (_smoothedElbowAngle! <= 100.0) {
          _phase = MovementPhase.inflection; // BOTTOM reached
          _bottomEnteredTime = now;
          _feedbackMessage = 'Chest depth reached! Drive upward.';
        } else if (_smoothedElbowAngle! > _minAngleObserved + 15.0) {
          _phase = MovementPhase.ascending;
          _hadIncompleteDepth = true;
          _maxAngleObservedInAscent = _smoothedElbowAngle!;
          _feedbackMessage = 'Pushing up early. Go deeper!';
        }
        break;

      case MovementPhase.inflection:
        if (_smoothedElbowAngle! < _minAngleObserved) {
          _minAngleObserved = _smoothedElbowAngle!;
        }
        if (_smoothedElbowAngle! > 105.0) {
          if (_bottomEnteredTime != null) {
            _bottomDwellMs = now.difference(_bottomEnteredTime!).inMilliseconds;
          }
          _phase = MovementPhase.ascending;
          _maxAngleObservedInAscent = _smoothedElbowAngle!;
          _feedbackMessage = 'Driving back to lockout!';
        }
        break;

      case MovementPhase.ascending:
        if (_smoothedElbowAngle! > _maxAngleObservedInAscent) {
          _maxAngleObservedInAscent = _smoothedElbowAngle!;
        }

        if (_smoothedElbowAngle! >= 160.0) {
          // Full lockout reached! Evaluate rep duration & form score
          final double durationSec = _repStartTime != null
              ? now.difference(_repStartTime!).inMilliseconds / 1000.0
              : 2.0;

          double score = 100.0;
          String? primaryWarning;

          if (_hadIncompleteDepth || _minAngleObserved > 100.0) {
            score -= 35.0;
            primaryWarning ??= 'Go deeper';
          }
          if (_hadHipSag) {
            score -= 32.0;
            primaryWarning ??= 'Hips too low';
          }
          if (_hadPike) {
            score -= 32.0;
            primaryWarning ??= 'Lift your hips less';
          }
          if (_hadHandsMisaligned) {
            score -= 32.0;
            primaryWarning ??= 'Hands under shoulders';
          }
          if (_hadIncompleteLockout) {
            score -= 32.0;
            primaryWarning ??= 'Full lockout';
          }
          if (_bottomDwellMs < 150) {
            score -= 15.0;
            primaryWarning ??= 'Pause at bottom';
          }
          if (durationSec < 0.7 || durationSec > 6.0) {
            score -= 15.0;
            primaryWarning ??= 'Controlled pace';
          }

          if (score >= 70.0) {
            _correctReps++;
            _formScore = score;
            _rejectionReason = null;
            _feedbackMessage = primaryWarning ?? 'Rep Counted! Great push-up.';
          } else {
            _rejectedReps++;
            _formScore = score;
            _rejectionReason = primaryWarning ?? 'Form score below 70';
            _feedbackMessage = 'Not counted: $_rejectionReason';
          }

          _phase = MovementPhase.completed;
          _minAngleObserved = 180.0;
          _resetPushupRepForm();
        } else if (_smoothedElbowAngle! < _maxAngleObservedInAscent - 12.0 && _maxAngleObservedInAscent < 160.0) {
          _hadIncompleteLockout = true;
          _feedbackMessage = 'Full lockout';
        }
        break;
    }

    return RepCounterResult(
      correctReps: _correctReps,
      rejectedReps: _rejectedReps,
      currentPhase: _phase,
      currentAngle: _currentAngle,
      formScore: _formScore,
      feedbackMessage: _feedbackMessage,
      isPersonDetected: true,
      rejectionReason: _rejectionReason,
    );
  }

  void _resetCurlRepForm([Point<double>? elbowRelHip, Point<double>? elbowRelShoulder]) {
    _minCurlAngleObserved = 180.0;
    _hadIncompleteFlexion = false;
    _hadElbowInstability = false;
    _wristArcedProperly = false;
    _hadLegMotionDuringRep = false;
    _curlRepStartTime = null;
    _startElbowRelHip = elbowRelHip;
    _startElbowRelShoulder = elbowRelShoulder;
  }

  RepCounterResult _processBicepCurls(List<PoseLandmark> landmarks, [DateTime? timestamp]) {
    final now = timestamp ?? DateTime.now();
    final config = ExerciseSignalConfig.forExercise('bicep_curls');

    // 1. Leg-Stillness Gate Calculation
    // Tracks knee angle (23-25-27 or 24-26-28) and hip-ankle vertical displacement over 1s window
    final leftHip = _findLandmark(landmarks, PoseLandmark.leftHip);
    final leftKnee = _findLandmark(landmarks, PoseLandmark.leftKnee);
    final leftAnkle = _findLandmark(landmarks, PoseLandmark.leftAnkle);
    final rightHip = _findLandmark(landmarks, PoseLandmark.rightHip);
    final rightKnee = _findLandmark(landmarks, PoseLandmark.rightKnee);
    final rightAnkle = _findLandmark(landmarks, PoseLandmark.rightAnkle);

    PoseLandmark? legHip, legKnee, legAnkle;
    final leftLegConf = (leftHip?.likelihood ?? 0) + (leftKnee?.likelihood ?? 0) + (leftAnkle?.likelihood ?? 0);
    final rightLegConf = (rightHip?.likelihood ?? 0) + (rightKnee?.likelihood ?? 0) + (rightAnkle?.likelihood ?? 0);
    if (leftLegConf >= rightLegConf && leftLegConf > 1.2) {
      legHip = leftHip;
      legKnee = leftKnee;
      legAnkle = leftAnkle;
    } else if (rightLegConf > 1.2) {
      legHip = rightHip;
      legKnee = rightKnee;
      legAnkle = rightAnkle;
    }

    bool isLegMoving = false;
    if (legHip != null && legKnee != null && legAnkle != null) {
      final double kneeAngle = PoseLandmark.calculateAngle(legHip, legKnee, legAnkle);
      final double hipAnkleDisp = (legHip.y - legAnkle.y).abs();
      _legWindow.add(_LegSample(timestamp: now, kneeAngle: kneeAngle, hipAnkleDisp: hipAnkleDisp));

      // 1.0s window pruning
      _legWindow.removeWhere((s) => now.difference(s.timestamp).inMilliseconds > 1000);

      if (_legWindow.length >= 3) {
        double sumK = 0.0;
        double sumD = 0.0;
        for (final s in _legWindow) {
          sumK += s.kneeAngle;
          sumD += s.hipAnkleDisp;
        }
        final meanK = sumK / _legWindow.length;
        final meanD = sumD / _legWindow.length;

        double varK = 0.0;
        double varD = 0.0;
        for (final s in _legWindow) {
          varK += (s.kneeAngle - meanK) * (s.kneeAngle - meanK);
          varD += (s.hipAnkleDisp - meanD) * (s.hipAnkleDisp - meanD);
        }
        varK /= _legWindow.length;
        varD /= _legWindow.length;

        if (varK > 12.0 || varD > 0.0002) {
          isLegMoving = true;
          _hadLegMotionDuringRep = true;
        }
      }
    }

    // 2. Primary Signal Whitelist: landmarks 11-16 ONLY
    final armLandmarks = landmarks.where((l) => config.primaryCountingLandmarks.contains(l.index)).toList();
    final leftShoulder = _findLandmark(armLandmarks, PoseLandmark.leftShoulder);
    final leftElbow = _findLandmark(armLandmarks, PoseLandmark.leftElbow);
    final leftWrist = _findLandmark(armLandmarks, PoseLandmark.leftWrist);

    final rightShoulder = _findLandmark(armLandmarks, PoseLandmark.rightShoulder);
    final rightElbow = _findLandmark(armLandmarks, PoseLandmark.rightElbow);
    final rightWrist = _findLandmark(armLandmarks, PoseLandmark.rightWrist);

    final bool leftArmVisible = leftShoulder != null &&
        leftElbow != null &&
        leftWrist != null &&
        leftElbow.likelihood >= 0.5 &&
        leftWrist.likelihood >= 0.5;
    final bool rightArmVisible = rightShoulder != null &&
        rightElbow != null &&
        rightWrist != null &&
        rightElbow.likelihood >= 0.5 &&
        rightWrist.likelihood >= 0.5;

    if (!leftArmVisible && !rightArmVisible) {
      return RepCounterResult(
        correctReps: _correctReps,
        rejectedReps: _rejectedReps,
        currentPhase: _phase,
        currentAngle: _smoothedCurlElbowAngle ?? 180.0,
        formScore: _formScore,
        feedbackMessage: isLegMoving ? 'Keep lower body still' : 'Step fully into frame',
        isPersonDetected: true,
      );
    }

    final PoseLandmark shoulder;
    final PoseLandmark elbow;
    final PoseLandmark wrist;
    final double rawAngle;

    if (leftArmVisible && rightArmVisible) {
      final double aL = PoseLandmark.calculateAngle(leftShoulder, leftElbow, leftWrist);
      final double aR = PoseLandmark.calculateAngle(rightShoulder, rightElbow, rightWrist);
      rawAngle = (aL + aR) / 2.0;
      if ((leftElbow.likelihood + leftWrist.likelihood) >= (rightElbow.likelihood + rightWrist.likelihood)) {
        shoulder = leftShoulder;
        elbow = leftElbow;
        wrist = leftWrist;
      } else {
        shoulder = rightShoulder;
        elbow = rightElbow;
        wrist = rightWrist;
      }
    } else if (leftArmVisible) {
      rawAngle = PoseLandmark.calculateAngle(leftShoulder, leftElbow, leftWrist);
      shoulder = leftShoulder;
      elbow = leftElbow;
      wrist = leftWrist;
    } else {
      shoulder = rightShoulder!;
      elbow = rightElbow!;
      wrist = rightWrist!;
      rawAngle = PoseLandmark.calculateAngle(shoulder, elbow, wrist);
    }

    const double alpha = 0.35;
    _smoothedCurlElbowAngle = _smoothedCurlElbowAngle == null
        ? rawAngle
        : (alpha * rawAngle + (1.0 - alpha) * _smoothedCurlElbowAngle!);
    _currentAngle = _smoothedCurlElbowAngle!;

    // 3. Elbow stability calculation
    final activeHip = (leftHip?.likelihood ?? 0) >= (rightHip?.likelihood ?? 0) ? leftHip : rightHip;
    final Point<double>? currentElbowRelHip = (activeHip != null && activeHip.likelihood >= 0.4)
        ? Point(elbow.x - activeHip.x, elbow.y - activeHip.y)
        : null;
    final Point<double> currentElbowRelShoulder = Point(elbow.x - shoulder.x, elbow.y - shoulder.y);

    if (_startElbowRelHip != null && currentElbowRelHip != null) {
      final double drift = sqrt(
        pow(currentElbowRelHip.x - _startElbowRelHip!.x, 2) +
        pow(currentElbowRelHip.y - _startElbowRelHip!.y, 2),
      );
      if (drift > 0.16) {
        _hadElbowInstability = true;
      }
    }
    if (_startElbowRelShoulder != null) {
      final double shoulderDrift = sqrt(
        pow(currentElbowRelShoulder.x - _startElbowRelShoulder!.x, 2) +
        pow(currentElbowRelShoulder.y - _startElbowRelShoulder!.y, 2),
      );
      if (shoulderDrift > 0.16) {
        _hadElbowInstability = true;
      }
    }

    // 4. Wrist Arc Check: wrist travels in arc toward shoulder
    if (wrist.y < elbow.y) {
      _wristArcedProperly = true;
    }

    // 5. State Machine with Hysteresis
    // EXTENDED: elbow >= 150° | FLEXED: elbow <= 50°
    // Rep duration: 0.6-5.0s
    switch (_phase) {
      case MovementPhase.idle:
      case MovementPhase.completed:
      case MovementPhase.starting:
        if (_smoothedCurlElbowAngle! >= 150.0) {
          _phase = MovementPhase.starting;
          _resetCurlRepForm(currentElbowRelHip, currentElbowRelShoulder);
          _feedbackMessage = isLegMoving ? 'Keep lower body still' : 'Arms extended. Begin curl.';
        } else if (_smoothedCurlElbowAngle! < 140.0) {
          _phase = MovementPhase.ascending;
          _curlRepStartTime = now;
          _minCurlAngleObserved = _smoothedCurlElbowAngle!;
          _feedbackMessage = isLegMoving ? 'Keep lower body still' : 'Curling up... Keep elbows pinned.';
        }
        break;

      case MovementPhase.ascending:
        if (_smoothedCurlElbowAngle! < _minCurlAngleObserved) {
          _minCurlAngleObserved = _smoothedCurlElbowAngle!;
        }
        if (_smoothedCurlElbowAngle! <= 50.0) {
          _phase = MovementPhase.inflection; // Peak flexion reached!
          _feedbackMessage = isLegMoving ? 'Keep lower body still' : 'Peak contraction! Lower with control.';
        } else if (_smoothedCurlElbowAngle! > _minCurlAngleObserved + 15.0) {
          _phase = MovementPhase.descending;
          _hadIncompleteFlexion = true;
          _feedbackMessage = isLegMoving ? 'Keep lower body still' : 'Incomplete curl. Squeeze all the way up!';
        }
        break;

      case MovementPhase.inflection:
        if (_smoothedCurlElbowAngle! < _minCurlAngleObserved) {
          _minCurlAngleObserved = _smoothedCurlElbowAngle!;
        }
        if (_smoothedCurlElbowAngle! > 60.0) {
          _phase = MovementPhase.descending;
          _feedbackMessage = isLegMoving ? 'Keep lower body still' : 'Lowering down smoothly.';
        }
        break;

      case MovementPhase.descending:
        if (_smoothedCurlElbowAngle! >= 150.0) {
          final double durationSec = _curlRepStartTime != null
              ? now.difference(_curlRepStartTime!).inMilliseconds / 1000.0
              : 1.5;

          // Leg stillness gate check: if leg motion energy exceeded threshold, SUPPRESS rep!
          if (_hadLegMotionDuringRep || isLegMoving) {
            _rejectedReps++;
            _formScore = 50.0;
            _rejectionReason = 'Keep lower body still';
            _feedbackMessage = 'Not counted: Keep lower body still';
          } else {
            double score = 100.0;
            String? primaryWarning;

            if (_minCurlAngleObserved > 50.0 || _hadIncompleteFlexion) {
              score -= 35.0;
              primaryWarning ??= 'Curl all the way up';
            }
            if (_hadElbowInstability) {
              score -= 35.0;
              primaryWarning ??= 'Keep elbows steady';
            }
            if (!_wristArcedProperly) {
              score -= 35.0;
              primaryWarning ??= 'Curl toward shoulders';
            }
            if (durationSec < 0.6 || durationSec > 5.0) {
              score -= 15.0;
              primaryWarning ??= 'Controlled pace';
            }

            if (score >= 70.0) {
              _correctReps++;
              _formScore = score;
              _rejectionReason = null;
              _feedbackMessage = primaryWarning ?? 'Rep Counted! Clean curl.';
            } else {
              _rejectedReps++;
              _formScore = score;
              _rejectionReason = primaryWarning ?? 'Form score below 70';
              _feedbackMessage = 'Not counted: $_rejectionReason';
            }
          }

          _phase = MovementPhase.completed;
          _minCurlAngleObserved = 180.0;
          _resetCurlRepForm(currentElbowRelHip, currentElbowRelShoulder);
        }
        break;
    }

    if (isLegMoving && _phase != MovementPhase.completed) {
      _feedbackMessage = 'Keep lower body still';
    }

    return RepCounterResult(
      correctReps: _correctReps,
      rejectedReps: _rejectedReps,
      currentPhase: _phase,
      currentAngle: _currentAngle,
      formScore: _formScore,
      feedbackMessage: _feedbackMessage,
      isPersonDetected: true,
      rejectionReason: _rejectionReason,
    );
  }

  PoseLandmark? _findLandmark(List<PoseLandmark> landmarks, int index) {
    for (final l in landmarks) {
      if (l.index == index) return l;
    }
    return null;
  }
}
