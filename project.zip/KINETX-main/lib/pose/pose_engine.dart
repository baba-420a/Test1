import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart' as mlkit;
import 'pose_landmark.dart';

abstract class PoseEngine {
  Future<void> initialize();
  Future<List<PoseLandmark>> processCameraImage(
    CameraImage image,
    CameraDescription camera,
    DeviceOrientation orientation,
  );
  void dispose();
}

/// Offline Bundled MediaPipe Pose Detection Engine powered by ML Kit Base Model
class MlKitPoseEngine implements PoseEngine {
  mlkit.PoseDetector? _detector;
  bool _isInitialized = false;

  @override
  Future<void> initialize() async {
    if (_isInitialized) return;
    // PoseDetectionModel.base is bundled locally inside the APK for 100% offline usage
    final options = mlkit.PoseDetectorOptions(
      mode: mlkit.PoseDetectionMode.stream,
      model: mlkit.PoseDetectionModel.base,
    );
    _detector = mlkit.PoseDetector(options: options);
    _isInitialized = true;
    debugPrint('MlKitPoseEngine: MediaPipe base model initialized offline.');
  }

  @override
  Future<List<PoseLandmark>> processCameraImage(
    CameraImage image,
    CameraDescription camera,
    DeviceOrientation orientation,
  ) async {
    if (!_isInitialized || _detector == null) {
      await initialize();
    }

    try {
      final inputImage = _buildInputImage(image, camera, orientation);
      if (inputImage == null) return [];

      final List<mlkit.Pose> poses = await _detector!.processImage(inputImage);
      if (poses.isEmpty) return [];

      final firstPose = poses.first;
      final List<PoseLandmark> mappedLandmarks = [];

      firstPose.landmarks.forEach((type, landmark) {
        mappedLandmarks.add(
          PoseLandmark(
            index: type.index,
            x: landmark.x,
            y: landmark.y,
            z: landmark.z,
            likelihood: landmark.likelihood,
          ),
        );
      });

      return mappedLandmarks;
    } catch (e) {
      debugPrint('Error processing camera frame in MlKitPoseEngine: $e');
      return [];
    }
  }

  mlkit.InputImage? _buildInputImage(
    CameraImage image,
    CameraDescription camera,
    DeviceOrientation orientation,
  ) {
    final sensorOrientation = camera.sensorOrientation;
    mlkit.InputImageRotation? rotation;

    if (defaultTargetPlatform == TargetPlatform.android) {
      var rotationCompensation = _orientations[orientation];
      if (rotationCompensation == null) return null;

      if (camera.lensDirection == CameraLensDirection.front) {
        rotationCompensation = (sensorOrientation + rotationCompensation) % 360;
      } else {
        rotationCompensation = (sensorOrientation - rotationCompensation + 360) % 360;
      }
      rotation = mlkit.InputImageRotationValue.fromRawValue(rotationCompensation);
    } else {
      rotation = mlkit.InputImageRotationValue.fromRawValue(camera.sensorOrientation);
    }

    if (rotation == null) return null;

    // ML Kit Android requires NV21 format for raw byte buffers
    final mlkit.InputImageFormat format = defaultTargetPlatform == TargetPlatform.android
        ? mlkit.InputImageFormat.nv21
        : (mlkit.InputImageFormatValue.fromRawValue(image.format.raw) ?? mlkit.InputImageFormat.bgra8888);

    if (image.planes.isEmpty) return null;

    final Uint8List bytes;
    if (image.planes.length == 1) {
      bytes = image.planes[0].bytes;
    } else {
      final WriteBuffer allBytes = WriteBuffer();
      for (final Plane plane in image.planes) {
        allBytes.putUint8List(plane.bytes);
      }
      bytes = allBytes.done().buffer.asUint8List();
    }

    return mlkit.InputImage.fromBytes(
      bytes: bytes,
      metadata: mlkit.InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: rotation,
        format: format,
        bytesPerRow: image.planes[0].bytesPerRow,
      ),
    );
  }

  static const Map<DeviceOrientation, int> _orientations = {
    DeviceOrientation.portraitUp: 0,
    DeviceOrientation.landscapeLeft: 90,
    DeviceOrientation.portraitDown: 180,
    DeviceOrientation.landscapeRight: 270,
  };

  @override
  void dispose() {
    _detector?.close();
    _detector = null;
    _isInitialized = false;
  }
}

/// Fallback or mock engine for testing
class MockPoseEngine implements PoseEngine {
  @override
  Future<void> initialize() async {}

  @override
  Future<List<PoseLandmark>> processCameraImage(
    CameraImage image,
    CameraDescription camera,
    DeviceOrientation orientation,
  ) async {
    return [];
  }

  @override
  void dispose() {}
}
