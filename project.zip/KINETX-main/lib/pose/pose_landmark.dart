import 'dart:math';

/// Represents a single body landmark point in normalized coordinates (0.0 to 1.0).
class PoseLandmark {
  final int index;
  final double x;
  final double y;
  final double z;
  final double likelihood;

  const PoseLandmark({
    required this.index,
    required this.x,
    required this.y,
    this.z = 0.0,
    required this.likelihood,
  });

  /// Standard MediaPipe landmark indices
  static const int nose = 0;
  static const int leftShoulder = 11;
  static const int rightShoulder = 12;
  static const int leftElbow = 13;
  static const int rightElbow = 14;
  static const int leftWrist = 15;
  static const int rightWrist = 16;
  static const int leftHip = 23;
  static const int rightHip = 24;
  static const int leftKnee = 25;
  static const int rightKnee = 26;
  static const int leftAnkle = 27;
  static const int rightAnkle = 28;

  /// Calculates angle in degrees at joint [b] formed by points [a] -> [b] -> [c].
  static double calculateAngle(
    PoseLandmark a,
    PoseLandmark b,
    PoseLandmark c,
  ) {
    final double radians = atan2(c.y - b.y, c.x - b.x) - atan2(a.y - b.y, a.x - b.x);
    double angle = (radians * 180.0 / pi).abs();
    if (angle > 180.0) {
      angle = 360.0 - angle;
    }
    return angle;
  }
}
