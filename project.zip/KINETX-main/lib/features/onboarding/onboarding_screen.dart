import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/constants/app_constants.dart';
import '../../core/design_system/components/app_card.dart';
import '../../core/design_system/components/app_chip.dart';
import '../../core/design_system/components/day_tile.dart';
import '../../core/design_system/components/exercise_photo_tile.dart';
import '../../core/design_system/components/floating_stat_chip.dart';
import '../../core/design_system/components/primary_button.dart';
import '../../core/design_system/components/scan_banner_card.dart';
import '../../core/design_system/components/segmented_ring_badge.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../core/permissions/permission_service.dart';
import '../../data/models/user_profile.dart';
import '../../data/repositories/user_profile_repository.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  // Profile Inputs
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  String _selectedGender = 'Male';
  String _selectedLevel = 'Beginner';
  final String _selectedGoal = 'Build Strength & Form';

  bool _cameraGranted = false;
  bool _notificationGranted = false;

  @override
  void initState() {
    super.initState();
    _checkPermissions();
  }

  Future<void> _checkPermissions() async {
    final camera = await PermissionService.isCameraGranted();
    final notif = await PermissionService.isNotificationGranted();
    if (mounted) {
      setState(() {
        _cameraGranted = camera;
        _notificationGranted = notif;
      });
    }
  }

  Future<void> _requestCamera() async {
    final granted = await PermissionService.requestCamera();
    if (mounted) {
      setState(() {
        _cameraGranted = granted;
      });
    }
  }

  Future<void> _requestNotification() async {
    final granted = await PermissionService.requestNotification();
    if (mounted) {
      setState(() {
        _notificationGranted = granted;
      });
    }
  }

  Future<void> _finishOnboarding() async {
    final name = _nameController.text.trim().isEmpty ? 'Athlete' : _nameController.text.trim();
    final height = double.tryParse(_heightController.text.trim()) ?? 175.0;
    final weight = double.tryParse(_weightController.text.trim()) ?? 72.0;
    final age = int.tryParse(_ageController.text.trim()) ?? 26;

    final profile = UserProfile(
      id: 'user_local_primary',
      name: name,
      weightKg: weight,
      heightCm: height,
      age: age,
      gender: _selectedGender,
      fitnessLevel: _selectedLevel,
      goal: _selectedGoal,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    await UserProfileRepository.saveUserProfile(profile);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.keyOnboardingCompleted, true);

    if (mounted) {
      context.go('/home');
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    _nameController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isMarketingPage = _currentPage < 3;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: isMarketingPage
          ? SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent)
          : SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
      child: Scaffold(
        backgroundColor: isMarketingPage ? AppColors.deepNavy : AppColors.pageBackground,
        body: Container(
          decoration: BoxDecoration(
            gradient: isMarketingPage ? AppColors.gradientBlue : null,
            color: isMarketingPage ? null : AppColors.pageBackground,
          ),
          child: SafeArea(
            child: Column(
              children: [
                // Top Progress Dots
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Step ${_currentPage + 1} of 5',
                        style: GoogleFonts.montserrat(
                          color: isMarketingPage ? Colors.white70 : AppColors.inkSecondary,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                      Row(
                        children: List.generate(5, (index) {
                          final isActive = index == _currentPage;
                          return AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            margin: const EdgeInsets.symmetric(horizontal: 3),
                            width: isActive ? 24 : 8,
                            height: 6,
                            decoration: BoxDecoration(
                              color: isActive
                                  ? AppColors.lime
                                  : (isMarketingPage
                                      ? Colors.white.withValues(alpha: 0.25)
                                      : AppColors.chipGray),
                              borderRadius: BorderRadius.circular(3),
                            ),
                          );
                        }),
                      ),
                    ],
                  ),
                ),

                // Main Page View
                Expanded(
                  child: PageView(
                    controller: _pageController,
                    physics: const ClampingScrollPhysics(),
                    onPageChanged: (index) {
                      setState(() {
                        _currentPage = index;
                      });
                    },
                    children: [
                      _buildMarketingSlide1(),
                      _buildMarketingSlide2(),
                      _buildMarketingSlide3(),
                      _buildUserDetailsPage(),
                      _buildPermissionsPage(),
                    ],
                  ),
                ),

                // Bottom Navigation Actions
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
                  child: Row(
                    children: [
                      if (_currentPage > 0) ...[
                        Expanded(
                          flex: 1,
                          child: SizedBox(
                            height: 52,
                            child: ElevatedButton(
                              onPressed: () {
                                _pageController.previousPage(
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.easeInOut,
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: isMarketingPage
                                    ? Colors.white.withValues(alpha: 0.15)
                                    : AppColors.chipGray,
                                foregroundColor: isMarketingPage ? Colors.white : AppColors.ink,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              child: const Text(
                                'Back',
                                style: TextStyle(fontWeight: FontWeight.w700),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                      ],
                      Expanded(
                        flex: 2,
                        child: PrimaryButton(
                          label: _currentPage == 4 ? 'Get Started' : 'Continue',
                          icon: _currentPage == 4 ? LucideIcons.check : LucideIcons.arrowRight,
                          height: 52,
                          onPressed: () {
                            if (_currentPage < 4) {
                              _pageController.nextPage(
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeInOut,
                              );
                            } else {
                              _finishOnboarding();
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Marketing Slide 1: Real-time AI Form Check (Reference 1 style with scan-banner)
  Widget _buildMarketingSlide1() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Column(
        children: [
          const SizedBox(height: 12),
          // Floating Segmented Ring Badge (Component #1)
          const Center(
            child: SegmentedRingBadge(
              icon: LucideIcons.scanLine,
              size: 80,
            ),
          ),
          const SizedBox(height: 20),

          // Huge 2-line Montserrat 800 White Headline
          Text(
            'Real-Time AI\nForm Calibration',
            textAlign: TextAlign.center,
            style: GoogleFonts.montserrat(
              fontSize: 32,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              letterSpacing: -0.5,
              height: 1.15,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Computer vision tracking analyzes your joint angles\nand rep velocity on-device in real time.',
            textAlign: TextAlign.center,
            style: AppTypography.body.copyWith(
              color: Colors.white.withValues(alpha: 0.8),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 32),

          // Lime Rounded-24 Scan-Banner Card (Component #1)
          ScanBannerCard(
            title: 'Snap your workout for\ninstant insights',
            subtitle: 'Offline MediaPipe joint validation',
            icon: LucideIcons.scan,
            onTap: () {},
          ),
          const SizedBox(height: 18),

          // Dark Glass Feature Card
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.hairline, width: 1),
              boxShadow: AppColors.cardShadow,
            ),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: AppColors.primaryBlueSoft,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  alignment: Alignment.center,
                  child: const Icon(LucideIcons.shieldCheck, color: AppColors.primaryBlue, size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '100% On-Device Privacy',
                        style: GoogleFonts.montserrat(
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          color: AppColors.ink,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Zero camera frames are ever uploaded or stored externally.',
                        style: AppTypography.caption.copyWith(color: AppColors.inkSecondary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Marketing Slide 2: 10-30 min daily workouts (Reference 3 style with day tiles)
  Widget _buildMarketingSlide2() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Column(
        children: [
          const SizedBox(height: 12),
          // Floating Segmented Ring Badge
          const Center(
            child: SegmentedRingBadge(
              icon: LucideIcons.heartPulse,
              size: 80,
            ),
          ),
          const SizedBox(height: 20),

          // Headline straight from Reference 3
          Text(
            '10–30 min\ndaily workouts',
            textAlign: TextAlign.center,
            style: GoogleFonts.montserrat(
              fontSize: 32,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              letterSpacing: -0.5,
              height: 1.15,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Keep your streak alive with calibrated session targets\nand automated daily progress checks.',
            textAlign: TextAlign.center,
            style: AppTypography.body.copyWith(
              color: Colors.white.withValues(alpha: 0.8),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 32),

          // Day-Tile Grid Preview Card (Component #2)
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: AppColors.hairline, width: 1),
              boxShadow: AppColors.cardShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'DAILY PROGRESSION',
                      style: AppTypography.overline.copyWith(color: AppColors.inkSecondary),
                    ),
                    const AppChip(
                      label: 'CURRENT CYCLE',
                      variant: ChipVariant.lime,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    DayTile(
                      dayNumber: '1',
                      dayLabel: 'MO',
                      state: DayTileState.completed,
                      reps: 25,
                    ),
                    DayTile(
                      dayNumber: '2',
                      dayLabel: 'TU',
                      state: DayTileState.completed,
                      reps: 30,
                    ),
                    DayTile(
                      dayNumber: '3',
                      dayLabel: 'WE',
                      state: DayTileState.today,
                    ),
                    DayTile(
                      dayNumber: '4',
                      dayLabel: 'TH',
                      state: DayTileState.empty,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Floating Stat Chip preview
                Center(
                  child: FloatingStatChip(
                    value: '132',
                    unit: 'bpm',
                    label: 'Active Heart Rate • 24 Cal',
                    icon: LucideIcons.heart,
                    intensityLevel: 4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Marketing Slide 3: Plans made for you (Reference 4 style with training plan card)
  Widget _buildMarketingSlide3() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Column(
        children: [
          const SizedBox(height: 12),
          // Floating Segmented Ring Badge
          const Center(
            child: SegmentedRingBadge(
              icon: LucideIcons.dumbbell,
              size: 80,
            ),
          ),
          const SizedBox(height: 20),

          // Headline straight from Reference 4
          Text(
            'Plans made\nfor you',
            textAlign: TextAlign.center,
            style: GoogleFonts.montserrat(
              fontSize: 32,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              letterSpacing: -0.5,
              height: 1.15,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'All plans are personalized for your fitness level,\nanatomy, and specific strength targets.',
            textAlign: TextAlign.center,
            style: AppTypography.body.copyWith(
              color: Colors.white.withValues(alpha: 0.8),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 32),

          // Plan Preview Card (Component #6 style)
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: AppColors.hairline, width: 1),
              boxShadow: AppColors.cardShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: const [
                              AppChip(
                                label: 'Your Personal Plan',
                                variant: ChipVariant.lime,
                              ),
                              SizedBox(width: 6),
                              AppChip(
                                label: '12 Weeks',
                                variant: ChipVariant.neutral,
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Muscle & Strength\nStarter',
                            style: GoogleFonts.montserrat(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: AppColors.ink,
                              height: 1.25,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 14),
                    const ExercisePhotoTile(
                      exerciseId: 'squats',
                      width: 64,
                      height: 64,
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Row(
                      children: [
                        Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.lime, shape: BoxShape.circle)),
                        const SizedBox(width: 6),
                        Text('Strength', style: AppTypography.caption.copyWith(fontWeight: FontWeight.w700, color: AppColors.ink)),
                      ],
                    ),
                    const SizedBox(width: 16),
                    Row(
                      children: [
                        Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.primaryBlue, shape: BoxShape.circle)),
                        const SizedBox(width: 6),
                        Text('Cardio', style: AppTypography.caption.copyWith(fontWeight: FontWeight.w700, color: AppColors.ink)),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// User Details & Biometrics Page (Restyled with clean white cards)
  Widget _buildUserDetailsPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Personal Details',
            style: GoogleFonts.montserrat(
              fontSize: 24,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'We use your measurements to calculate calories burned and biomechanical metrics accurately.',
            style: AppTypography.body.copyWith(color: AppColors.inkSecondary),
          ),
          const SizedBox(height: 20),

          AppCard(
            borderRadius: BorderRadius.circular(20),
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildInputLabel('FULL NAME'),
                _buildTextField(
                  controller: _nameController,
                  hint: 'e.g. Alex Mercer',
                  icon: LucideIcons.user,
                ),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildInputLabel('HEIGHT (CM)'),
                          _buildTextField(
                            controller: _heightController,
                            hint: '175',
                            icon: LucideIcons.ruler,
                            keyboardType: TextInputType.number,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildInputLabel('WEIGHT (KG)'),
                          _buildTextField(
                            controller: _weightController,
                            hint: '72',
                            icon: LucideIcons.scale,
                            keyboardType: TextInputType.number,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildInputLabel('AGE'),
                          _buildTextField(
                            controller: _ageController,
                            hint: '26',
                            icon: LucideIcons.calendar,
                            keyboardType: TextInputType.number,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildInputLabel('GENDER'),
                          Container(
                            height: 50,
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceSoft,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                value: _selectedGender,
                                dropdownColor: AppColors.surface,
                                style: AppTypography.body.copyWith(
                                  color: AppColors.ink,
                                  fontWeight: FontWeight.w700,
                                ),
                                icon: const Icon(LucideIcons.chevronDown, color: AppColors.inkSecondary, size: 18),
                                isExpanded: true,
                                items: ['Male', 'Female', 'Other']
                                    .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                                    .toList(),
                                onChanged: (val) {
                                  if (val != null) setState(() => _selectedGender = val);
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Level Selection
          AppCard(
            borderRadius: BorderRadius.circular(20),
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildInputLabel('EXPERIENCE LEVEL'),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 10,
                  children: ['Beginner', 'Intermediate', 'Advanced'].map((level) {
                    final isSel = _selectedLevel == level;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedLevel = level),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: isSel ? AppColors.lime : AppColors.chipGray,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          level,
                          style: GoogleFonts.montserrat(
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                            color: isSel ? AppColors.onLime : AppColors.ink,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// System Permissions Page (Restyled with white cards and lime CTA)
  Widget _buildPermissionsPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'System Permissions',
            style: GoogleFonts.montserrat(
              fontSize: 24,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'To track repetitions in real time and notify you for daily workouts, please grant:',
            style: AppTypography.body.copyWith(color: AppColors.inkSecondary),
          ),
          const SizedBox(height: 24),

          _buildPermissionCard(
            icon: LucideIcons.video,
            title: 'Camera Access',
            subtitle: 'Required for real-time offline joint angle tracking. No video or images are stored.',
            isGranted: _cameraGranted,
            onAction: _requestCamera,
          ),
          const SizedBox(height: 16),

          _buildPermissionCard(
            icon: LucideIcons.bell,
            title: 'Workout Reminders',
            subtitle: 'Daily notifications so you never break your workout streak.',
            isGranted: _notificationGranted,
            onAction: _requestNotification,
          ),
          const SizedBox(height: 24),

          AppCard(
            borderRadius: BorderRadius.circular(20),
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                const Icon(LucideIcons.shieldCheck, color: AppColors.primaryBlue, size: 24),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    '100% On-Device Pose Processing. Complete privacy guaranteed.',
                    style: AppTypography.caption.copyWith(
                      color: AppColors.inkSecondary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPermissionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool isGranted,
    required VoidCallback onAction,
  }) {
    return AppCard(
      borderRadius: BorderRadius.circular(20),
      padding: const EdgeInsets.all(18),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: isGranted ? AppColors.lime.withValues(alpha: 0.3) : AppColors.primaryBlueSoft,
              borderRadius: BorderRadius.circular(14),
            ),
            alignment: Alignment.center,
            child: Icon(
              icon,
              color: isGranted ? AppColors.ink : AppColors.primaryBlue,
              size: 22,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.montserrat(
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                    color: AppColors.ink,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: AppTypography.caption.copyWith(
                    color: AppColors.inkSecondary,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: isGranted ? null : onAction,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isGranted ? AppColors.chipGray : AppColors.primaryBlue,
                    foregroundColor: isGranted ? AppColors.inkSecondary : Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(
                    isGranted ? 'Permission Granted' : 'Allow Access',
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: AppTypography.overline.copyWith(color: AppColors.inkSecondary),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(14),
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        style: AppTypography.body.copyWith(color: AppColors.ink, fontWeight: FontWeight.w600),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, size: 18, color: AppColors.inkSecondary),
          hintText: hint,
          hintStyle: AppTypography.body.copyWith(
            color: AppColors.inkSecondary.withValues(alpha: 0.6),
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }
}
