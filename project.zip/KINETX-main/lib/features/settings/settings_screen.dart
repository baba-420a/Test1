import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../core/constants/app_constants.dart';
import '../../core/design_system/components/animated_background_fx.dart';
import '../../core/design_system/components/app_card.dart';
import '../../core/design_system/components/app_chip.dart';
import '../../core/design_system/components/primary_button.dart';
import '../../core/design_system/components/section_header.dart';
import '../../core/design_system/components/stat_tile.dart';
import '../../core/design_system/components/toggle_row.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../core/permissions/permission_service.dart';
import '../../core/tts/voice_coach_service.dart';
import '../../data/models/user_profile.dart';
import '../../data/repositories/user_profile_repository.dart';
import '../../data/repositories/workout_repository.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  UserProfile? _profile;
  TotalWorkoutStats? _stats;
  bool _isLoading = true;

  bool _cameraMirror = true;
  bool _audioFeedback = true;
  bool _vibrationFeedback = true;
  bool _reduceMotion = false;
  double _speechRate = 1.0;

  @override
  void initState() {
    super.initState();
    _loadProfileAndStats();
  }

  Future<void> _loadProfileAndStats() async {
    setState(() => _isLoading = true);
    final profile = await UserProfileRepository.getUserProfile();
    final stats = await WorkoutRepository.getTotalStats();
    if (mounted) {
      setState(() {
        _profile = profile;
        _stats = stats;
        _cameraMirror = profile.cameraMirrorEnabled;
        _audioFeedback = profile.audioFeedbackEnabled;
        _reduceMotion = profile.reduceMotionEnabled;
        _speechRate = profile.speechRate;
        _isLoading = false;
      });
      VoiceCoachService.instance.setEnabled(profile.audioFeedbackEnabled);
      VoiceCoachService.instance.setSpeechRate(profile.speechRate);
    }
  }

  Color _getBmiCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'underweight':
        return AppColors.warning;
      case 'normal':
        return AppColors.success;
      case 'overweight':
        return AppColors.warning;
      case 'obese':
        return AppColors.danger;
      default:
        return AppColors.success;
    }
  }

  void _showEditProfileBottomSheet() {
    if (_profile == null) return;

    final nameCtrl = TextEditingController(text: _profile!.name);
    final heightCtrl = TextEditingController(
      text: _profile!.heightCm > 0 ? _profile!.heightCm.toInt().toString() : '',
    );
    final weightCtrl = TextEditingController(
      text: _profile!.weightKg > 0 ? _profile!.weightKg.toStringAsFixed(1) : '',
    );
    final ageCtrl = TextEditingController(
      text: _profile!.age > 0 ? _profile!.age.toString() : '',
    );
    String selectedGender = _profile!.gender;
    String selectedLevel = _profile!.fitnessLevel;
    String selectedGoal = _profile!.goal;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final h = double.tryParse(heightCtrl.text.trim()) ?? 0;
            final w = double.tryParse(weightCtrl.text.trim()) ?? 0;
            final double liveBmi = (h > 0 && w > 0) ? w / ((h / 100) * (h / 100)) : 0.0;

            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Sheet Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Edit Profile & Biometrics',
                          style: GoogleFonts.montserrat(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: AppColors.ink,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(LucideIcons.x, color: AppColors.inkSecondary, size: 20),
                          onPressed: () => Navigator.pop(ctx),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Full Name
                    _buildInputLabel('FULL NAME'),
                    _buildTextInput(nameCtrl, 'Your name'),
                    const SizedBox(height: 14),

                    // Height & Weight
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildInputLabel('HEIGHT (CM)'),
                              _buildTextInput(
                                heightCtrl,
                                '175',
                                isNumber: true,
                                onChanged: (_) => setModalState(() {}),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildInputLabel('WEIGHT (KG)'),
                              _buildTextInput(
                                weightCtrl,
                                '70.0',
                                isNumber: true,
                                onChanged: (_) => setModalState(() {}),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),

                    // Live BMI Preview Card
                    if (liveBmi > 0) ...[
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceSoft,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Calculated BMI',
                              style: AppTypography.caption.copyWith(color: AppColors.inkSecondary),
                            ),
                            Text(
                              liveBmi.toStringAsFixed(1),
                              style: GoogleFonts.montserrat(
                                fontWeight: FontWeight.w800,
                                color: AppColors.primaryBlue,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                    ],

                    // Age & Gender
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildInputLabel('AGE'),
                              _buildTextInput(ageCtrl, '25', isNumber: true),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildInputLabel('GENDER'),
                              Container(
                                height: 48,
                                padding: const EdgeInsets.symmetric(horizontal: 12),
                                decoration: BoxDecoration(
                                  color: AppColors.surfaceSoft,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                alignment: Alignment.center,
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    value: selectedGender,
                                    isExpanded: true,
                                    dropdownColor: AppColors.surface,
                                    style: AppTypography.body.copyWith(
                                      color: AppColors.ink,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    items: ['Male', 'Female', 'Other']
                                        .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                                        .toList(),
                                    onChanged: (val) {
                                      if (val != null) setModalState(() => selectedGender = val);
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),

                    // Primary Goal
                    _buildInputLabel('PRIMARY FITNESS GOAL'),
                    Container(
                      height: 48,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: AppColors.surfaceSoft,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      alignment: Alignment.center,
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedGoal,
                          isExpanded: true,
                          dropdownColor: AppColors.surface,
                          style: AppTypography.body.copyWith(
                            color: AppColors.ink,
                            fontWeight: FontWeight.w600,
                          ),
                          items: [
                            'Build Strength & Form',
                            'Calorie Burn & Conditioning',
                            'Postural Symmetry',
                            'Joint Mobility & Health',
                          ]
                              .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                              .toList(),
                          onChanged: (val) {
                            if (val != null) setModalState(() => selectedGoal = val);
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),

                    // Fitness Level
                    _buildInputLabel('FITNESS LEVEL'),
                    Container(
                      height: 48,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: AppColors.surfaceSoft,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      alignment: Alignment.center,
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedLevel,
                          isExpanded: true,
                          dropdownColor: AppColors.surface,
                          style: AppTypography.body.copyWith(
                            color: AppColors.ink,
                            fontWeight: FontWeight.w600,
                          ),
                          items: ['Beginner', 'Intermediate', 'Advanced']
                              .map((l) => DropdownMenuItem(value: l, child: Text(l)))
                              .toList(),
                          onChanged: (val) {
                            if (val != null) setModalState(() => selectedLevel = val);
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Save Button (Lime CTA)
                    PrimaryButton(
                      label: 'Save Changes',
                      onPressed: () async {
                        final updated = await UserProfileRepository.updateBiometrics(
                          name: nameCtrl.text.trim().isEmpty ? 'Athlete' : nameCtrl.text.trim(),
                          heightCm: double.tryParse(heightCtrl.text.trim()) ?? 175.0,
                          weightKg: double.tryParse(weightCtrl.text.trim()) ?? 70.0,
                          age: int.tryParse(ageCtrl.text.trim()) ?? 25,
                          gender: selectedGender,
                          fitnessLevel: selectedLevel,
                          goal: selectedGoal,
                        );
                        if (mounted) {
                          setState(() => _profile = updated);
                        }
                        if (ctx.mounted) {
                          Navigator.pop(ctx);
                        }
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildInputLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: AppTypography.overline.copyWith(
          color: AppColors.inkSecondary,
        ),
      ),
    );
  }

  Widget _buildTextInput(
    TextEditingController ctrl,
    String hint, {
    bool isNumber = false,
    ValueChanged<String>? onChanged,
  }) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: ctrl,
        onChanged: onChanged,
        keyboardType: isNumber
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.text,
        style: AppTypography.body.copyWith(
          color: AppColors.ink,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: AppTypography.body.copyWith(
            color: AppColors.inkSecondary.withValues(alpha: 0.6),
            fontSize: 14,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          scrolledUnderElevation: 0,
          title: Text(
            'Profile & Settings',
            style: GoogleFonts.montserrat(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
              letterSpacing: -0.5,
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(LucideIcons.pencil, color: AppColors.inkSecondary, size: 20),
              onPressed: _showEditProfileBottomSheet,
            ),
          ],
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primaryBlue))
            : ListView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 96),
                children: [
                  // 1. Athlete Header Card
                  _buildProfileHeader(),
                  const SizedBox(height: 20),

                  // 2. Physical Biometrics Grid
                  const SectionHeader(title: 'Biometrics'),
                  const SizedBox(height: 12),
                  _buildBiometricsGrid(),
                  const SizedBox(height: 24),

                  // 3. Training Stats Highlights (strictly hidden if 0 workouts)
                  if (_stats != null && _stats!.totalWorkouts > 0) ...[
                    const SectionHeader(title: 'Training Overview'),
                    const SizedBox(height: 12),
                    _buildTrainingStatsCard(),
                    const SizedBox(height: 24),
                  ],

                  // 4. Workout & Camera Preferences
                  const SectionHeader(title: 'Preferences & Engine'),
                  const SizedBox(height: 12),
                  AppCard(
                    borderRadius: BorderRadius.circular(20),
                    padding: EdgeInsets.zero,
                    child: Column(
                      children: [
                        ToggleRow(
                          title: 'Mirror Front Camera',
                          subtitle: 'Flips preview horizontally for natural mirror feel',
                          value: _cameraMirror,
                          onChanged: (val) {
                            setState(() => _cameraMirror = val);
                            if (_profile != null) {
                              UserProfileRepository.saveUserProfile(
                                _profile!.copyWith(cameraMirrorEnabled: val),
                              );
                            }
                          },
                        ),
                        ToggleRow(
                          title: 'Audio Form Cues',
                          subtitle: 'Voice cues for repetition count and movement depth',
                          value: _audioFeedback,
                          onChanged: (val) async {
                            if (val) {
                              final hasEngine = await VoiceCoachService.instance.hasTtsEngine();
                              if (!hasEngine) {
                                if (context.mounted) {
                                  VoiceCoachService.showMissingEngineDialog(context);
                                }
                              }
                            }
                            VoiceCoachService.instance.setEnabled(val);
                            if (mounted) {
                              setState(() => _audioFeedback = val);
                            }
                            if (_profile != null) {
                              UserProfileRepository.saveUserProfile(
                                _profile!.copyWith(audioFeedbackEnabled: val),
                              );
                            }
                          },
                        ),
                        if (_audioFeedback) ...[
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Voice Coach Speed',
                                      style: GoogleFonts.montserrat(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.ink,
                                      ),
                                    ),
                                    Text(
                                      '${_speechRate.toStringAsFixed(1)}x',
                                      style: GoogleFonts.montserrat(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w700,
                                        color: AppColors.primaryBlue,
                                      ),
                                    ),
                                  ],
                                ),
                                SliderTheme(
                                  data: SliderTheme.of(context).copyWith(
                                    activeTrackColor: AppColors.primaryBlue,
                                    inactiveTrackColor: AppColors.chipGray,
                                    thumbColor: AppColors.primaryBlue,
                                    overlayColor: AppColors.primaryBlueSoft,
                                    trackHeight: 4.0,
                                  ),
                                  child: Slider(
                                    value: _speechRate,
                                    min: 0.5,
                                    max: 1.5,
                                    divisions: 10,
                                    onChanged: (val) {
                                      setState(() => _speechRate = val);
                                      VoiceCoachService.instance.setSpeechRate(val);
                                      if (_profile != null) {
                                        UserProfileRepository.saveUserProfile(
                                          _profile!.copyWith(speechRate: val),
                                        );
                                      }
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Divider(height: 1, color: AppColors.chipGray),
                        ],
                        ToggleRow(
                          title: 'Haptic Feedback',
                          subtitle: 'Vibrate phone on each successful repetition lockout',
                          value: _vibrationFeedback,
                          onChanged: (val) => setState(() => _vibrationFeedback = val),
                        ),
                        ToggleRow(
                          title: 'Reduce Motion',
                          subtitle: 'Disables animated backgrounds and motion transitions for lower-end devices',
                          value: _reduceMotion,
                          showDivider: false,
                          onChanged: (val) {
                            setState(() => _reduceMotion = val);
                            AnimatedBackgroundFX.reduceMotionNotifier.value = val;
                            if (_profile != null) {
                              UserProfileRepository.saveUserProfile(
                                _profile!.copyWith(reduceMotionEnabled: val),
                              );
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // 5. System Permissions & Privacy
                  const SectionHeader(title: 'Privacy & Permissions'),
                  const SizedBox(height: 12),
                  AppCard(
                    borderRadius: BorderRadius.circular(20),
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      children: [
                        ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBlueSoft,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            alignment: Alignment.center,
                            child: const Icon(
                              LucideIcons.sliders,
                              color: AppColors.primaryBlue,
                              size: 18,
                            ),
                          ),
                          title: Text(
                            'OS Permissions',
                            style: GoogleFonts.montserrat(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: AppColors.ink,
                            ),
                          ),
                          subtitle: Text(
                            'Manage camera and system permissions',
                            style: AppTypography.caption.copyWith(
                              color: AppColors.inkSecondary,
                            ),
                          ),
                          trailing: const Icon(
                            LucideIcons.chevronRight,
                            color: AppColors.inkSecondary,
                            size: 18,
                          ),
                          onTap: () => PermissionService.openSettings(),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          height: 1,
                          color: AppColors.hairline,
                        ),
                        const SizedBox(height: 14),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(
                              LucideIcons.shieldCheck,
                              color: AppColors.primaryBlue,
                              size: 18,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                '100% On-Device Pose Processing. Zero camera images, videos, or biometrics are ever uploaded to any external cloud or server.',
                                style: AppTypography.caption.copyWith(
                                  color: AppColors.inkSecondary,
                                  height: 1.45,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),

                  // App Version Footer
                  Center(
                    child: Text(
                      '${AppConstants.appName} • Build 1.0.0 (Offline AI Engine)',
                      style: AppTypography.caption.copyWith(
                        color: AppColors.inkSecondary.withValues(alpha: 0.7),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  /// Athlete Header Card: circle with primaryBlue ring on white card,
  /// name Montserrat 800, level = lime pill, goal text wrapped to 2 lines without truncation
  Widget _buildProfileHeader() {
    final profile = _profile;
    final displayName = profile?.name.isNotEmpty == true ? profile!.name : 'Athlete';
    final initials = displayName
        .trim()
        .split(' ')
        .map((e) => e.isNotEmpty ? e[0] : '')
        .take(2)
        .join()
        .toUpperCase();

    return AppCard(
      borderRadius: BorderRadius.circular(24),
      padding: const EdgeInsets.all(20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Initials Avatar with primaryBlue ring
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.primaryBlueSoft,
              border: Border.all(color: AppColors.primaryBlue, width: 2.5),
            ),
            alignment: Alignment.center,
            child: Text(
              initials.isEmpty ? 'AT' : initials,
              style: GoogleFonts.montserrat(
                color: AppColors.primaryBlue,
                fontWeight: FontWeight.w800,
                fontSize: 20,
              ),
            ),
          ),
          const SizedBox(width: 16),

          // Name, Lime Level Pill, and Goal text (wrapped to 2 lines without truncation)
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  displayName,
                  style: GoogleFonts.montserrat(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: AppColors.ink,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    AppChip(
                      label: profile?.fitnessLevel.toUpperCase() ?? 'BEGINNER',
                      variant: ChipVariant.lime,
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  profile?.goal ?? 'Build Strength & Form',
                  maxLines: 2,
                  style: AppTypography.caption.copyWith(
                    color: AppColors.inkSecondary,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Physical Biometrics: white cards, BMI category colored (success/warning/danger),
  /// "18 yrs • Male" never clipped
  Widget _buildBiometricsGrid() {
    final profile = _profile;
    final weight = (profile != null && profile.weightKg > 0)
        ? '${profile.weightKg.toStringAsFixed(1)} kg'
        : '–';
    final height = (profile != null && profile.heightCm > 0)
        ? '${profile.heightCm.toInt()} cm'
        : '–';
    final bmi = (profile != null && profile.bmi > 0)
        ? profile.bmi.toStringAsFixed(1)
        : '–';
    final bmiCat = (profile != null && profile.bmi > 0) ? profile.bmiCategory : 'Normal';
    final ageStr = (profile != null && profile.age > 0)
        ? '${profile.age} yrs • ${profile.gender}'
        : '–';

    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: StatTile(
                label: 'Weight',
                value: weight,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StatTile(
                label: 'Height',
                value: height,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: StatTile(
                label: 'BMI',
                value: bmi,
                subtitle: bmiCat,
                subtitleColor: _getBmiCategoryColor(bmiCat),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StatTile(
                label: 'Profile',
                value: ageStr,
              ),
            ),
          ],
        ),
      ],
    );
  }

  /// Training overview: single white card with vertical hairline dividers
  Widget _buildTrainingStatsCard() {
    final stats = _stats;
    final totalWorkouts = stats?.totalWorkouts ?? 0;
    final totalReps = stats?.totalReps ?? 0;
    final avgScore = stats?.averageFormScore.toInt() ?? 0;
    final totalCalories = stats?.totalCalories.toInt() ?? 0;

    return AppCard(
      borderRadius: BorderRadius.circular(20),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      child: Row(
        children: [
          Expanded(
            child: _buildInlineStat('Workouts', '$totalWorkouts'),
          ),
          Container(width: 1, height: 36, color: AppColors.hairline),
          Expanded(
            child: _buildInlineStat('Total Reps', '$totalReps'),
          ),
          Container(width: 1, height: 36, color: AppColors.hairline),
          Expanded(
            child: _buildInlineStat('Avg Form', '$avgScore%'),
          ),
          Container(width: 1, height: 36, color: AppColors.hairline),
          Expanded(
            child: _buildInlineStat('Calories', '$totalCalories'),
          ),
        ],
      ),
    );
  }

  Widget _buildInlineStat(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: GoogleFonts.montserrat(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: AppColors.ink,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: AppTypography.overline.copyWith(
            color: AppColors.inkSecondary,
            fontSize: 9,
          ),
        ),
      ],
    );
  }
}
