import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../core/design_system/components/app_card.dart';
import '../../core/design_system/components/app_chip.dart';
import '../../core/design_system/components/exercise_photo_tile.dart';
import '../../core/design_system/components/micro_interactions.dart';
import '../../core/design_system/components/primary_button.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../data/models/exercise.dart';

class ExerciseLibraryScreen extends StatelessWidget {
  const ExerciseLibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          scrolledUnderElevation: 0,
          title: Text(
            'Training Plan',
            style: GoogleFonts.montserrat(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
              letterSpacing: -0.5,
            ),
          ),
        ),
        body: ListView.separated(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 96),
          itemCount: Exercise.defaultExercises.length,
          separatorBuilder: (_, _) => const SizedBox(height: 18),
          itemBuilder: (context, index) {
            final exercise = Exercise.defaultExercises[index];
            return StaggeredEntrance(
              index: index,
              child: _ExerciseCard(exercise: exercise, index: index + 1),
            );
          },
        ),
      ),
    );
  }
}

class _ExerciseCard extends StatefulWidget {
  final Exercise exercise;
  final int index;

  const _ExerciseCard({required this.exercise, required this.index});

  @override
  State<_ExerciseCard> createState() => _ExerciseCardState();
}

class _ExerciseCardState extends State<_ExerciseCard> {
  bool _isExpanded = false;

  ChipVariant _getDifficultyVariant(String difficulty) {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return ChipVariant.lime;
      case 'intermediate':
        return ChipVariant.blue;
      case 'advanced':
        return ChipVariant.navy;
      default:
        return ChipVariant.neutral;
    }
  }

  @override
  Widget build(BuildContext context) {
    final exercise = widget.exercise;
    final indexString = widget.index.toString().padLeft(2, '0');
    final muscles = exercise.targetMuscles.split(',').map((m) => m.trim()).toList();

    return AppCard(
      borderRadius: BorderRadius.circular(24),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: Index number in chipGray rounded-12 tile, Title Montserrat 800, Difficulty pill, Photo Tile right
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppColors.chipGray,
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center,
                child: Text(
                  indexString,
                  style: GoogleFonts.montserrat(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      exercise.name,
                      style: GoogleFonts.montserrat(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppColors.ink,
                        letterSpacing: -0.4,
                      ),
                    ),
                    const SizedBox(height: 4),
                    AppChip(
                      label: exercise.difficulty,
                      variant: _getDifficultyVariant(exercise.difficulty),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              ExercisePhotoTile(
                exerciseId: exercise.id,
                width: 52,
                height: 52,
                borderRadius: BorderRadius.circular(14),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Description clamped 3 lines with proper "More" text-button (primaryBlue, chevron)
          GestureDetector(
            onTap: () => setState(() => _isExpanded = !_isExpanded),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  exercise.description,
                  maxLines: _isExpanded ? null : 3,
                  overflow: _isExpanded ? TextOverflow.visible : TextOverflow.ellipsis,
                  style: AppTypography.body.copyWith(
                    color: AppColors.inkSecondary,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _isExpanded ? 'Show less' : 'More',
                      style: AppTypography.caption.copyWith(
                        color: AppColors.primaryBlue,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Icon(
                      _isExpanded ? LucideIcons.chevronUp : LucideIcons.chevronDown,
                      size: 14,
                      color: AppColors.primaryBlue,
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Muscle Chips = chipGray pills
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: muscles.map((muscle) {
              return AppChip(
                label: muscle,
                variant: ChipVariant.neutral,
              );
            }).toList(),
          ),
          const SizedBox(height: 14),

          // Camera Row = surfaceSoft rounded-12 row with blue video icon
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.surfaceSoft,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(
                  LucideIcons.video,
                  size: 16,
                  color: AppColors.primaryBlue,
                ),
                const SizedBox(width: 10),
                Text(
                  'Camera: ',
                  style: AppTypography.caption.copyWith(
                    color: AppColors.inkSecondary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Expanded(
                  child: Text(
                    exercise.cameraPlacement,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.caption.copyWith(
                      color: AppColors.ink,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),

          // CTA = Lime banner button
          PrimaryButton(
            label: 'View Form Cues & Start',
            icon: LucideIcons.play,
            height: 52,
            onPressed: () => context.push('/exercise-detail/${exercise.id}'),
          ),
        ],
      ),
    );
  }
}
