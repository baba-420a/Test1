import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../core/design_system/components/app_card.dart';
import '../../core/design_system/components/app_chip.dart';
import '../../core/design_system/components/exercise_photo_tile.dart';
import '../../core/design_system/components/primary_button.dart';
import '../../core/design_system/components/section_header.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../data/models/exercise.dart';

class ExerciseDetailScreen extends StatelessWidget {
  final String exerciseId;

  const ExerciseDetailScreen({super.key, required this.exerciseId});

  ChipVariant _getDifficultyVariant(String difficulty) {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return ChipVariant.lime;
      case 'intermediate':
        return ChipVariant.blue;
      case 'advanced':
        return ChipVariant.navy;
      default:
        return ChipVariant.neutral;
    }
  }

  @override
  Widget build(BuildContext context) {
    final exercise = Exercise.defaultExercises.firstWhere(
      (e) => e.id == exerciseId,
      orElse: () => Exercise.defaultExercises.first,
    );

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: AppColors.pageBackground,
        appBar: AppBar(
          backgroundColor: AppColors.pageBackground,
          elevation: 0,
          scrolledUnderElevation: 0,
          leading: IconButton(
            icon: const Icon(LucideIcons.arrowLeft, color: AppColors.ink, size: 22),
            onPressed: () => context.pop(),
          ),
          actions: [
            IconButton(
              icon: const Icon(LucideIcons.info, color: AppColors.inkSecondary, size: 20),
              onPressed: () {},
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Hero Card with Photo / Soft Gradient Tile + Title + Difficulty
                      AppCard(
                        borderRadius: BorderRadius.circular(24),
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          const AppChip(
                                            label: 'AI Tracked',
                                            variant: ChipVariant.neutral,
                                            icon: LucideIcons.activity,
                                          ),
                                          const SizedBox(width: 8),
                                          AppChip(
                                            label: exercise.difficulty,
                                            variant: _getDifficultyVariant(exercise.difficulty),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 14),
                                      Text(
                                        exercise.name,
                                        style: GoogleFonts.montserrat(
                                          fontSize: 26,
                                          fontWeight: FontWeight.w800,
                                          color: AppColors.ink,
                                          letterSpacing: -0.5,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 16),
                                ExercisePhotoTile(
                                  exerciseId: exercise.id,
                                  width: 84,
                                  height: 84,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ],
                            ),
                            const SizedBox(height: 14),
                            Text(
                              exercise.description,
                              style: AppTypography.body.copyWith(
                                color: AppColors.inkSecondary,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // AI Tracking & Camera Setup Preview Card
                      AppCard(
                        borderRadius: BorderRadius.circular(24),
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 8,
                                      height: 8,
                                      decoration: const BoxDecoration(
                                        color: AppColors.success,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      'Offline Pose Engine Ready',
                                      style: AppTypography.caption.copyWith(
                                        color: AppColors.inkSecondary,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                                const Icon(
                                  LucideIcons.cpu,
                                  size: 16,
                                  color: AppColors.primaryBlue,
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Container(
                              height: 130,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: AppColors.surfaceSoft,
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 44,
                                    height: 44,
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryBlueSoft,
                                      shape: BoxShape.circle,
                                    ),
                                    alignment: Alignment.center,
                                    child: const Icon(
                                      LucideIcons.video,
                                      size: 22,
                                      color: AppColors.primaryBlue,
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Text(
                                    'Optimal Camera Angle',
                                    style: AppTypography.caption.copyWith(
                                      color: AppColors.ink,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 16),
                                    child: Text(
                                      exercise.cameraPlacement,
                                      textAlign: TextAlign.center,
                                      style: AppTypography.caption.copyWith(
                                        color: AppColors.inkSecondary,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Essential Execution Cues
                      const SectionHeader(title: 'Essential Execution Cues'),
                      const SizedBox(height: 12),
                      _buildExecutionCueCard(
                        stepNumber: '01',
                        title: 'Spine Neutrality',
                        description: 'Maintain slight posterior pelvic tilt; avoid lumbar sagging or hyper-extending the lower back.',
                      ),
                      const SizedBox(height: 10),
                      _buildExecutionCueCard(
                        stepNumber: '02',
                        title: 'Full Depth & Range',
                        description: 'Descend smoothly until thighs break parallel with floor, keeping core engaged and knees aligned.',
                      ),
                      const SizedBox(height: 10),
                      _buildExecutionCueCard(
                        stepNumber: '03',
                        title: 'Breathing & Tempo',
                        description: 'Inhale during controlled descent (3s); deliver an explosive exhale while pushing up through heels (1s).',
                      ),
                      const SizedBox(height: 24),

                      // Biomechanical Musculature Tile
                      const SectionHeader(title: 'Target Musculature'),
                      const SizedBox(height: 12),
                      AppCard(
                        borderRadius: BorderRadius.circular(20),
                        child: Row(
                          children: [
                            Expanded(
                              child: _buildBiomechanicalTile(
                                muscle: 'Target Area',
                                value: exercise.targetMuscles,
                              ),
                            ),
                            Container(width: 1, height: 36, color: AppColors.hairline),
                            Expanded(
                              child: _buildBiomechanicalTile(
                                muscle: 'Calories / Rep',
                                value: '${exercise.caloriesPerRep} kcal',
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),

              // Bottom CTA Bar
              Container(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
                decoration: const BoxDecoration(
                  color: AppColors.surface,
                  border: Border(
                    top: BorderSide(color: AppColors.hairline, width: 1),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x4D000000),
                      blurRadius: 20,
                      offset: Offset(0, -6),
                    ),
                  ],
                ),
                child: PrimaryButton(
                  label: 'Launch Camera Tracker',
                  icon: LucideIcons.play,
                  height: 52,
                  onPressed: () => context.push('/live-workout/${exercise.id}'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExecutionCueCard({
    required String stepNumber,
    required String title,
    required String description,
  }) {
    return AppCard(
      borderRadius: BorderRadius.circular(16),
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: AppColors.chipGray,
              borderRadius: BorderRadius.circular(10),
            ),
            alignment: Alignment.center,
            child: Text(
              stepNumber,
              style: GoogleFonts.montserrat(
                color: AppColors.ink,
                fontWeight: FontWeight.w800,
                fontSize: 13,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.montserrat(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: AppTypography.caption.copyWith(
                    color: AppColors.inkSecondary,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBiomechanicalTile({
    required String muscle,
    required String value,
  }) {
    return Column(
      children: [
        Text(
          value,
          textAlign: TextAlign.center,
          style: GoogleFonts.montserrat(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: AppColors.ink,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          muscle,
          style: AppTypography.overline.copyWith(
            color: AppColors.inkSecondary,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}
