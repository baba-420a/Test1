import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../core/design_system/components/app_card.dart';
import '../../core/design_system/components/day_tile.dart';
import '../../core/design_system/components/empty_state.dart';
import '../../core/design_system/components/micro_interactions.dart';
import '../../core/design_system/components/section_header.dart';
import '../../core/design_system/components/session_row.dart';
import '../../core/design_system/components/stat_tile.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../data/models/workout_session.dart';
import '../../data/repositories/workout_repository.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<WorkoutSession> _sessions = [];
  List<DayActivity> _weeklyActivity = [];
  TotalWorkoutStats? _stats;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistoryData();
  }

  Future<void> _loadHistoryData() async {
    setState(() => _isLoading = true);
    final sessions = await WorkoutRepository.getSessions();
    final stats = await WorkoutRepository.getTotalStats();
    final weeklyActivity = await WorkoutRepository.getLast7DaysActivity();
    if (mounted) {
      setState(() {
        _sessions = sessions;
        _stats = stats;
        _weeklyActivity = weeklyActivity;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: AppColors.pageBackground,
        body: Center(
          child: CircularProgressIndicator(color: AppColors.primaryBlue),
        ),
      );
    }

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          scrolledUnderElevation: 0,
          title: Text(
            'Workout Stats & History',
            style: GoogleFonts.montserrat(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
              letterSpacing: -0.5,
            ),
          ),
        ),
        body: _sessions.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: EmptyState(
                    icon: LucideIcons.barChart2,
                    title: 'No workouts yet',
                    description:
                        'Sessions you complete with the AI camera will appear here with form analysis and duration tracking.',
                    buttonLabel: 'Start your first workout',
                    onButtonPressed: () => context.go('/exercises'),
                  ),
                ),
              )
            : RefreshIndicator(
                color: AppColors.primaryBlue,
                backgroundColor: AppColors.surface,
                onRefresh: _loadHistoryData,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 96),
                  children: [
                    // Weekly Activity: Day-Tile Grid for the last 7 days (Component #2)
                    StaggeredEntrance(
                      index: 0,
                      child: _buildWeeklyDayTileCard(),
                    ),
                    const SizedBox(height: 24),

                    // All-Time Totals: 2x2 white cards
                    if (_stats != null) ...[
                      StaggeredEntrance(
                        index: 1,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SectionHeader(title: 'All-Time Totals'),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: StatTile(
                                    label: 'Total Sessions',
                                    value: '${_stats!.totalWorkouts}',
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: StatTile(
                                    label: 'Total Reps',
                                    value: '${_stats!.totalReps}',
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: StatTile(
                                    label: 'Avg Form Score',
                                    value: '${_stats!.averageFormScore.toInt()}%',
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: StatTile(
                                    label: 'Est. Calories',
                                    value: '${_stats!.totalCalories.toInt()} kcal',
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 28),
                    ],

                    // Recent Sessions List with Recipe-style Cards
                    StaggeredEntrance(
                      index: 2,
                      child: SectionHeader(
                        title: 'Recent Sessions',
                        actionLabel: '${_sessions.length} total',
                      ),
                    ),
                    const SizedBox(height: 12),
                    ...List.generate(_sessions.length, (index) {
                      final session = _sessions[index];
                      return StaggeredEntrance(
                        index: 3 + index,
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: SessionRow(
                            session: session,
                            onTap: () => context.push('/history/${session.id}'),
                          ),
                        ),
                      );
                    }),
                  ],
                ),
              ),
      ),
    );
  }

  /// Day-Tile grid component for last 7 days directly matching Reference 3:
  /// - Days with reps = completed style showing rep count under check
  /// - Today with 0 reps = white tile with blue outline
  /// - Zero days = frosted tile
  /// - Card header with total reps in Montserrat 800
  Widget _buildWeeklyDayTileCard() {
    final totalWeekReps = _weeklyActivity.fold<int>(0, (sum, d) => sum + d.totalReps);

    return AppCard(
      borderRadius: BorderRadius.circular(24),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: Overline + Montserrat-800 Reps Logged Number
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'WEEKLY ACTIVITY',
                    style: AppTypography.overline.copyWith(
                      color: AppColors.inkSecondary,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      CountUpText(
                        value: totalWeekReps,
                        style: GoogleFonts.montserrat(
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                          color: AppColors.ink,
                          letterSpacing: -0.5,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'reps logged',
                        style: AppTypography.caption.copyWith(
                          color: AppColors.inkSecondary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.primaryBlueSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Last 7 Days',
                  style: AppTypography.caption.copyWith(
                    color: AppColors.primaryBlue,
                    fontWeight: FontWeight.w700,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // 7 Day Tiles Row (scrollable or evenly spaced)
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(_weeklyActivity.length, (i) {
                final activity = _weeklyActivity[i];
                final dayLabel = DateFormat('E').format(activity.date).substring(0, 2).toUpperCase();
                final dayNumber = activity.date.day.toString();

                DayTileState tileState;
                if (activity.totalReps > 0) {
                  tileState = DayTileState.completed;
                } else if (activity.isToday) {
                  tileState = DayTileState.today;
                } else {
                  tileState = DayTileState.empty;
                }

                return StaggeredEntrance(
                  index: i,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4.0),
                    child: DayTile(
                      dayNumber: dayNumber,
                      dayLabel: dayLabel,
                      state: tileState,
                      reps: activity.totalReps,
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}
