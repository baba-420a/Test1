import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/design_system/components/animated_background_fx.dart';
import '../../core/design_system/components/app_card.dart';
import '../../core/design_system/components/empty_state.dart';
import '../../core/design_system/components/section_header.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../core/notifications/notification_service.dart';
import '../../data/models/reminder.dart';

class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key});

  @override
  State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  static const String _prefsKey = 'saved_user_reminders';
  List<Reminder> _reminders = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadReminders();
  }

  Future<void> _loadReminders() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = prefs.getStringList(_prefsKey);

    if (jsonList != null && jsonList.isNotEmpty) {
      final loaded = jsonList.map((str) {
        return Reminder.fromMap(json.decode(str) as Map<String, dynamic>);
      }).toList();
      setState(() {
        _reminders = loaded;
        _isLoading = false;
      });
    } else {
      _reminders = [
        const Reminder(
          id: 'rem_1',
          title: 'Morning Workout Routine',
          hour: 7,
          minute: 30,
          repeatDays: [1, 2, 3, 4, 5],
          isEnabled: true,
        ),
        const Reminder(
          id: 'rem_2',
          title: 'Evening Daily Session',
          hour: 18,
          minute: 30,
          repeatDays: [1, 2, 3, 4, 5, 6, 7],
          isEnabled: true,
        ),
      ];
      await _saveReminders();
      for (final r in _reminders) {
        if (r.isEnabled) {
          await NotificationService.scheduleDailyReminder(
            id: r.id.hashCode,
            title: r.title,
            body: 'Time for your workout! Keep your streak alive.',
            hour: r.hour,
            minute: r.minute,
          );
        }
      }
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _saveReminders() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = _reminders.map((r) => json.encode(r.toMap())).toList();
    await prefs.setStringList(_prefsKey, jsonList);
  }

  Future<void> _toggleReminder(int index, bool value) async {
    final reminder = _reminders[index].copyWith(isEnabled: value);
    setState(() {
      _reminders[index] = reminder;
    });
    await _saveReminders();

    if (value) {
      await NotificationService.scheduleDailyReminder(
        id: reminder.id.hashCode,
        title: reminder.title,
        body: 'Time for your scheduled workout! Open app to track form.',
        hour: reminder.hour,
        minute: reminder.minute,
      );
    } else {
      await NotificationService.cancelReminder(reminder.id.hashCode);
    }
  }

  Future<void> _deleteReminder(int index) async {
    final reminder = _reminders[index];
    await NotificationService.cancelReminder(reminder.id.hashCode);
    setState(() {
      _reminders.removeAt(index);
    });
    await _saveReminders();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: AppColors.surface,
          content: Text('Reminder deleted', style: TextStyle(color: AppColors.ink)),
        ),
      );
    }
  }

  Future<void> _addNewReminder() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 18, minute: 0),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primaryBlue,
              surface: AppColors.surface,
              onSurface: AppColors.ink,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      final newReminder = Reminder(
        id: 'rem_${DateTime.now().millisecondsSinceEpoch}',
        title: 'Daily Fitness Alert',
        hour: picked.hour,
        minute: picked.minute,
        repeatDays: [1, 2, 3, 4, 5, 6, 7],
        isEnabled: true,
      );

      setState(() {
        _reminders.add(newReminder);
      });
      await _saveReminders();

      await NotificationService.scheduleDailyReminder(
        id: newReminder.id.hashCode,
        title: newReminder.title,
        body: 'Time for your daily workout session! Let\'s hit your goals.',
        hour: newReminder.hour,
        minute: newReminder.minute,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: AppColors.surface,
            content: Text(
              'Scheduled reminder for ${newReminder.timeFormatted}',
              style: const TextStyle(color: AppColors.ink),
            ),
          ),
        );
      }
    }
  }

  Future<void> _testImmediateNotification() async {
    await NotificationService.showTestNotification(
      title: 'Fitness Reminder Alert',
      body: 'Notifications are verified and working on your device!',
    );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: AppColors.surface,
          content: Text(
            'Test notification sent! Check your notification drawer.',
            style: TextStyle(color: AppColors.ink),
          ),
          duration: Duration(seconds: 3),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          scrolledUnderElevation: 0,
          leading: IconButton(
            icon: const Icon(LucideIcons.arrowLeft, color: AppColors.ink, size: 22),
            onPressed: () => context.pop(),
          ),
          title: Text(
            'Workout Reminders',
            style: GoogleFonts.montserrat(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _addNewReminder,
          backgroundColor: AppColors.lime,
          foregroundColor: AppColors.onLime,
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          icon: const Icon(LucideIcons.plus, color: AppColors.onLime, size: 18),
          label: Text(
            'Add Reminder',
            style: GoogleFonts.montserrat(
              fontWeight: FontWeight.w800,
              color: AppColors.onLime,
              fontSize: 14,
            ),
          ),
        ),
        body: AnimatedBackgroundFX(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator(color: AppColors.primaryBlue))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 96),
                  children: [
                    // Info Card & Test Notification
                    AppCard(
                      borderRadius: BorderRadius.circular(20),
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        children: [
                          Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: AppColors.primaryBlueSoft,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              alignment: Alignment.center,
                              child: const Icon(
                                LucideIcons.bell,
                                color: AppColors.primaryBlue,
                                size: 20,
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Daily Consistency Coach',
                                    style: GoogleFonts.montserrat(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.ink,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Exact alarm reminders keep your training habit locked in. Alarms fire locally without sending data online.',
                                    style: AppTypography.caption.copyWith(
                                      color: AppColors.inkSecondary,
                                      height: 1.4,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: _testImmediateNotification,
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppColors.primaryBlue,
                              side: const BorderSide(color: AppColors.primaryBlueSoft),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            icon: const Icon(LucideIcons.send, size: 14),
                            label: const Text('Send Test Alert Now'),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Scheduled Reminders Header
                  SectionHeader(
                    title: 'Scheduled Alerts',
                    actionLabel: '${_reminders.length} active',
                  ),
                  const SizedBox(height: 12),

                  if (_reminders.isEmpty)
                    const EmptyState(
                      icon: LucideIcons.bellOff,
                      title: 'No reminders set',
                      description: 'Tap Add Reminder to configure scheduled daily training alerts.',
                    )
                  else
                    ..._reminders.asMap().entries.map((entry) {
                      final index = entry.key;
                      final reminder = entry.value;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: AppCard(
                          borderRadius: BorderRadius.circular(20),
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                          child: Row(
                            children: [
                              Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  color: reminder.isEnabled
                                      ? AppColors.primaryBlueSoft
                                      : AppColors.chipGray,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                alignment: Alignment.center,
                                child: Icon(
                                  LucideIcons.clock,
                                  color: reminder.isEnabled
                                      ? AppColors.primaryBlue
                                      : AppColors.inkSecondary,
                                  size: 20,
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      reminder.timeFormatted,
                                      style: GoogleFonts.montserrat(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w800,
                                        color: reminder.isEnabled
                                            ? AppColors.ink
                                            : AppColors.inkSecondary,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      reminder.title,
                                      style: AppTypography.caption.copyWith(
                                        color: AppColors.inkSecondary,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Switch.adaptive(
                                value: reminder.isEnabled,
                                onChanged: (val) => _toggleReminder(index, val),
                                activeThumbColor: Colors.white,
                                activeTrackColor: AppColors.primaryBlue,
                                inactiveThumbColor: const Color(0xFFBAC7D5),
                                inactiveTrackColor: AppColors.chipGray,
                              ),
                              IconButton(
                                icon: const Icon(
                                  LucideIcons.trash2,
                                  size: 18,
                                  color: AppColors.danger,
                                ),
                                onPressed: () => _deleteReminder(index),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                ],
              ),
        ),
      ),
    );
  }
}
