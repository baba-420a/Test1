import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../core/design_system/components/app_card.dart';
import '../../core/design_system/components/app_chip.dart';
import '../../core/design_system/components/exercise_photo_tile.dart';
import '../../core/design_system/components/micro_interactions.dart';
import '../../core/design_system/components/primary_button.dart';
import '../../core/design_system/components/section_header.dart';
import '../../core/design_system/components/stat_tile.dart';
import '../../core/design_system/tokens/app_colors.dart';
import '../../core/design_system/tokens/typography.dart';
import '../../core/music/music_library_sheet.dart';
import '../../data/models/exercise.dart';
import '../../data/models/user_profile.dart';
import '../../data/repositories/user_profile_repository.dart';
import '../../data/repositories/workout_repository.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  UserProfile? _profile;
  TotalWorkoutStats? _stats;
  int _currentStreak = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() => _isLoading = true);
    final profile = await UserProfileRepository.getUserProfile();
    final stats = await WorkoutRepository.getTotalStats();
    final sessions = await WorkoutRepository.getSessions();
    final streak = WorkoutRepository.computeCurrentStreak(sessions);

    if (mounted) {
      setState(() {
        _profile = profile;
        _stats = stats;
        _currentStreak = streak;
        _isLoading = false;
      });
    }
  }

  String _getTimeBasedGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  ChipVariant _getDifficultyVariant(String difficulty) {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return ChipVariant.lime;
      case 'intermediate':
        return ChipVariant.blue;
      case 'advanced':
        return ChipVariant.navy;
      default:
        return ChipVariant.neutral;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: AppColors.pageBackground,
        body: Center(
          child: CircularProgressIndicator(color: AppColors.primaryBlue),
        ),
      );
    }

    final now = DateTime.now();
    final dateString = DateFormat('EEEE, MMM d').format(now);
    final greeting = _getTimeBasedGreeting();
    final firstName = _profile?.name.trim().split(' ').first ?? 'Athlete';
    final hasWorkouts = _stats != null && _stats!.totalWorkouts > 0;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          bottom: false,
          child: RefreshIndicator(
            color: AppColors.primaryBlue,
            backgroundColor: AppColors.surface,
            onRefresh: _loadDashboardData,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 96),
              children: [
                // Top Bar: Small blue rounded-square brand mark + KINETX in Montserrat 800 dark; bell icon inkSecondary
                StaggeredEntrance(
                  index: 0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBlue,
                              borderRadius: BorderRadius.circular(8),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primaryBlue.withValues(alpha: 0.3),
                                  blurRadius: 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            alignment: Alignment.center,
                            child: const Text(
                              'K',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 18,
                                letterSpacing: -0.5,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            'KINETX',
                            style: GoogleFonts.montserrat(
                              fontSize: 18,
                              letterSpacing: 2.0,
                              fontWeight: FontWeight.w800,
                              color: AppColors.ink,
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                        icon: const Icon(
                          LucideIcons.bell,
                          size: 22,
                          color: AppColors.inkSecondary,
                        ),
                        onPressed: () => context.push('/reminders'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Greeting Header: Date overline above, greeting max 2 lines tight leading,
                // streak chip = lime pill with dark text + flame icon aligned to greeting's last line
                StaggeredEntrance(
                  index: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            dateString.toUpperCase(),
                            style: AppTypography.overline.copyWith(
                              color: AppColors.inkSecondary,
                            ),
                          ),
                          PressableScale(
                            onPressed: () => MusicLibrarySheet.show(context),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: AppColors.surface,
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(color: AppColors.hairline, width: 1),
                                boxShadow: AppColors.softShadow,
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(LucideIcons.music4, size: 12, color: AppColors.primaryBlue),
                                  const SizedBox(width: 4),
                                  Text(
                                    'MUSIC',
                                    style: GoogleFonts.montserrat(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      color: AppColors.primaryBlue,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        greeting,
                        style: AppTypography.display.copyWith(
                          fontSize: 28,
                          height: 1.1,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Text(
                              firstName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: AppTypography.display.copyWith(
                                fontSize: 28,
                                height: 1.1,
                              ),
                            ),
                          ),
                          if (_currentStreak > 0) ...[
                            const SizedBox(width: 12),
                            AppChip(
                              label: '$_currentStreak DAY STREAK',
                              icon: LucideIcons.flame,
                              variant: ChipVariant.lime,
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Today's Session Card: white rounded-24, photo cutout top-right,
                // lime pill "AI TRACKED", bold dark title, inkSecondary description,
                // CTA = lime rounded-16 full-width banner, dark bold text + play icon
                StaggeredEntrance(
                  index: 2,
                  child: _buildTodaySessionCard(),
                ),
                const SizedBox(height: 24),

                // Overview Stat Cards: white rounded-20, tight height (no dead space)
                if (hasWorkouts) ...[
                  StaggeredEntrance(
                    index: 3,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SectionHeader(title: 'Overview'),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: StatTile(
                                label: 'Workouts',
                                value: '${_stats!.totalWorkouts}',
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: StatTile(
                                label: 'Total Reps',
                                value: '${_stats!.totalReps}',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: StatTile(
                                label: 'Avg Form',
                                value: '${_stats!.averageFormScore.toInt()}%',
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: StatTile(
                                label: 'Calories',
                                value: '${_stats!.totalCalories.toInt()} kcal',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                ],

                // Exercise Library Section
                StaggeredEntrance(
                  index: 4,
                  child: SectionHeader(
                    title: 'Exercise Library',
                    actionLabel: 'See All',
                    onActionTap: () => context.go('/exercises'),
                  ),
                ),
                const SizedBox(height: 12),
                _buildExerciseList(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTodaySessionCard() {
    return AppCard(
      borderRadius: BorderRadius.circular(24),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const AppChip(
                      label: 'AI TRACKED',
                      variant: ChipVariant.lime,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Bodyweight Squats',
                      style: AppTypography.headline.copyWith(
                        color: AppColors.ink,
                        fontSize: 22,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Full range of motion squat calibration with real-time MediaPipe joint angle tracking and depth validation.',
                      style: AppTypography.body.copyWith(
                        color: AppColors.inkSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              const ExercisePhotoTile(
                exerciseId: 'squats',
                width: 80,
                height: 80,
                borderRadius: BorderRadius.all(Radius.circular(16)),
              ),
            ],
          ),
          const SizedBox(height: 20),
          PrimaryButton(
            label: 'Start Session',
            icon: LucideIcons.play,
            height: 52,
            onPressed: () => context.push('/live-workout/squats'),
          ),
        ],
      ),
    );
  }

  Widget _buildExerciseList() {
    final exercises = Exercise.defaultExercises.take(3).toList();

    return Column(
      children: List.generate(exercises.length, (i) {
        final exercise = exercises[i];
        return StaggeredEntrance(
          index: 5 + i,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: AppCard(
              borderRadius: BorderRadius.circular(16),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              onTap: () => context.push('/exercise-detail/${exercise.id}'),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          AppChip(
                            label: exercise.difficulty,
                            variant: _getDifficultyVariant(exercise.difficulty),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        exercise.name,
                        style: AppTypography.title.copyWith(
                          fontSize: 16,
                          color: AppColors.ink,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        exercise.targetMuscles,
                        style: AppTypography.caption.copyWith(
                          color: AppColors.inkSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                ExercisePhotoTile(
                  exerciseId: exercise.id,
                  width: 56,
                  height: 56,
                  borderRadius: BorderRadius.circular(14),
                ),
              ],
            ),
          ),
        ),
      );
    }),
    );
  }
}
