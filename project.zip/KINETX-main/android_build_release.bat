@echo off
set "GRADLE_USER_HOME=E:\.gradle"
set "PUB_CACHE=E:\pub-cache"
set "ANDROID_HOME=E:\Android\sdk"
set "ANDROID_SDK_ROOT=E:\Android\sdk"
if exist "E:\.gradle\caches\journal-1\journal-1.lock" (
    del /f /q "E:\.gradle\caches\journal-1\journal-1.lock" 2>nul
)

call E:\flutter\bin\flutter.bat build apk --release --target-platform android-arm64 --android-skip-build-dependency-validation
