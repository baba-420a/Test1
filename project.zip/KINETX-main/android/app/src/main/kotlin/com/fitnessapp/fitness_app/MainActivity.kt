package com.fitnessapp.fitness_app

import android.content.Intent
import android.provider.Settings
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : AudioServiceActivity() {
    private val SETTINGS_CHANNEL = "com.fitnessapp.fitness_app/settings"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SETTINGS_CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "openTtsSettings") {
                try {
                    val intent = Intent("com.android.settings.TTS_SETTINGS")
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                    result.success(true)
                } catch (e: Exception) {
                    try {
                        val fallback = Intent(Settings.ACTION_SETTINGS)
                        fallback.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(fallback)
                        result.success(true)
                    } catch (e2: Exception) {
                        result.error("UNAVAILABLE", "Cannot open settings", null)
                    }
                }
            } else {
                result.notImplemented()
            }
        }
    }
}
