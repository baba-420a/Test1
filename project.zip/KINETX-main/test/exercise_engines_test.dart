import 'dart:math';
import 'package:flutter_test/flutter_test.dart';
import 'package:fitness_app/pose/pose_landmark.dart';
import 'package:fitness_app/pose/rep_counter.dart';

void main() {
  group('Change 2 & 3: Push-up v2 & Bicep Curl Engine with Leg Gate', () {
    PoseLandmark computeJointThirdPoint({
      required PoseLandmark a,
      required PoseLandmark b,
      required double angleDeg,
      required int pointIndex,
      double length = 0.15,
      double likelihood = 0.95,
    }) {
      final double baseAngle = atan2(a.y - b.y, a.x - b.x);
      final double targetAngle = baseAngle + (angleDeg * pi / 180.0);
      final double cx = b.x + length * cos(targetAngle);
      final double cy = b.y + length * sin(targetAngle);
      return PoseLandmark(
        index: pointIndex,
        x: cx,
        y: cy,
        likelihood: likelihood,
      );
    }

    List<PoseLandmark> createCurlLandmarks({
      required double elbowAngleDeg,
      required double kneeAngleDeg,
      double hipY = 0.55,
      double ankleY = 0.95,
      double elbowXDrift = 0.0,
    }) {
      // Standing upright in frame
      const lShoulder = PoseLandmark(index: PoseLandmark.leftShoulder, x: 0.50, y: 0.20, likelihood: 0.95);
      const rShoulder = PoseLandmark(index: PoseLandmark.rightShoulder, x: 0.55, y: 0.20, likelihood: 0.95);

      final lElbow = PoseLandmark(index: PoseLandmark.leftElbow, x: 0.50 + elbowXDrift, y: 0.35, likelihood: 0.95);
      final rElbow = PoseLandmark(index: PoseLandmark.rightElbow, x: 0.55 + elbowXDrift, y: 0.35, likelihood: 0.95);

      final lWrist = computeJointThirdPoint(a: lShoulder, b: lElbow, angleDeg: elbowAngleDeg, pointIndex: PoseLandmark.leftWrist);
      final rWrist = computeJointThirdPoint(a: rShoulder, b: rElbow, angleDeg: elbowAngleDeg, pointIndex: PoseLandmark.rightWrist);

      // Leg geometry
      final lHip = PoseLandmark(index: PoseLandmark.leftHip, x: 0.50, y: hipY, likelihood: 0.95);
      final rHip = PoseLandmark(index: PoseLandmark.rightHip, x: 0.52, y: hipY, likelihood: 0.95);

      final lAnkle = PoseLandmark(index: PoseLandmark.leftAnkle, x: 0.50, y: ankleY, likelihood: 0.95);
      final rAnkle = PoseLandmark(index: PoseLandmark.rightAnkle, x: 0.52, y: ankleY, likelihood: 0.95);

      final lKnee = PoseLandmark(index: PoseLandmark.leftKnee, x: 0.50, y: (hipY + ankleY) / 2.0, likelihood: 0.95);
      final rKnee = PoseLandmark(index: PoseLandmark.rightKnee, x: 0.52, y: (hipY + ankleY) / 2.0, likelihood: 0.95);

      return [
        lShoulder, rShoulder,
        lElbow, rElbow,
        lWrist, rWrist,
        lHip, rHip,
        lKnee, rKnee,
        lAnkle, rAnkle,
      ];
    }

    List<PoseLandmark> createPushupLandmarks({
      required double elbowAngleDeg,
      bool hipSag = false,
      bool pike = false,
      bool handsUnderShoulders = true,
      bool verticalCameraAngle = false,
    }) {
      // Horizontal plank in side view
      // Shoulder at (0.25, 0.50)
      const lShoulder = PoseLandmark(index: PoseLandmark.leftShoulder, x: 0.25, y: 0.50, likelihood: 0.95);
      const rShoulder = PoseLandmark(index: PoseLandmark.rightShoulder, x: 0.27, y: 0.50, likelihood: 0.95);

      // Trunk line
      final double hipX = verticalCameraAngle ? 0.25 : 0.55;
      double hipY = verticalCameraAngle ? 0.80 : 0.50;
      if (hipSag) hipY += 0.12;
      if (pike) hipY -= 0.12;

      final double ankleX = verticalCameraAngle ? 0.25 : 0.85;
      const double ankleY = 0.50;

      final lHip = PoseLandmark(index: PoseLandmark.leftHip, x: hipX, y: hipY, likelihood: 0.95);
      final rHip = PoseLandmark(index: PoseLandmark.rightHip, x: hipX + 0.02, y: hipY, likelihood: 0.95);

      final lAnkle = PoseLandmark(index: PoseLandmark.leftAnkle, x: ankleX, y: ankleY, likelihood: 0.95);
      final rAnkle = PoseLandmark(index: PoseLandmark.rightAnkle, x: ankleX + 0.02, y: ankleY, likelihood: 0.95);

      final lKnee = PoseLandmark(index: PoseLandmark.leftKnee, x: (hipX + ankleX) / 2.0, y: 0.50, likelihood: 0.95);
      final rKnee = PoseLandmark(index: PoseLandmark.rightKnee, x: (hipX + ankleX) / 2.0 + 0.02, y: 0.50, likelihood: 0.95);

      // Pushup arm: elbow and wrist
      // When elbow angle is elbowAngleDeg, place elbow such that angle(shoulder, elbow, wrist) == elbowAngleDeg
      final double rad = elbowAngleDeg * pi / 180.0;
      // In pushup, elbow flares backward toward hip:
      final double elbowX = 0.25 - 0.075 * sin(pi - rad);
      const double elbowY = 0.575;

      final lElbow = PoseLandmark(index: PoseLandmark.leftElbow, x: elbowX, y: elbowY, likelihood: 0.95);
      final rElbow = PoseLandmark(index: PoseLandmark.rightElbow, x: elbowX + 0.02, y: elbowY, likelihood: 0.95);

      final double wristOffset = handsUnderShoulders ? 0.0 : 0.20;
      final rawLWrist = computeJointThirdPoint(a: lShoulder, b: lElbow, angleDeg: elbowAngleDeg, length: 0.075, pointIndex: PoseLandmark.leftWrist);
      final rawRWrist = computeJointThirdPoint(a: rShoulder, b: rElbow, angleDeg: elbowAngleDeg, length: 0.075, pointIndex: PoseLandmark.rightWrist);

      final lWrist = PoseLandmark(index: PoseLandmark.leftWrist, x: rawLWrist.x + wristOffset, y: rawLWrist.y, likelihood: 0.95);
      final rWrist = PoseLandmark(index: PoseLandmark.rightWrist, x: rawRWrist.x + wristOffset, y: rawRWrist.y, likelihood: 0.95);

      return [
        lShoulder, rShoulder,
        lElbow, rElbow,
        lWrist, rWrist,
        lHip, rHip,
        lKnee, rKnee,
        lAnkle, rAnkle,
      ];
    }

    test('ExerciseSignalConfig enforces correct landmark configuration table', () {
      final curlConfig = ExerciseSignalConfig.forExercise('bicep_curls');
      expect(curlConfig.primaryCountingLandmarks, equals({11, 12, 13, 14, 15, 16}));
      expect(curlConfig.gatingLandmarks, equals({23, 24, 25, 26, 27, 28}));

      final pushupConfig = ExerciseSignalConfig.forExercise('pushups');
      expect(pushupConfig.primaryCountingLandmarks, equals({11, 12, 13, 14, 15, 16}));
      expect(pushupConfig.gatingLandmarks, equals({23, 24, 27, 28}));

      final squatConfig = ExerciseSignalConfig.forExercise('squats');
      expect(squatConfig.primaryCountingLandmarks, equals({23, 24, 25, 26, 27, 28}));
    });

    test('Bicep Curls: Leg-only movement (squats/marching) produces ZERO curl reps', () {
      final counter = AutomaticRepCounter(exerciseId: 'bicep_curls');
      final baseTime = DateTime(2026, 9, 6, 10, 0, 0);

      // Simulate 30 frames over 1.5 seconds:
      // Arms stay stationary at side (extended 165°), while legs squat/march between 170° and 85°
      for (int i = 0; i < 30; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: i * 50));
        final double progress = i / 30.0;
        final double kneeAngle = 170.0 - 85.0 * sin(progress * pi);
        final double hipY = 0.55 + 0.12 * sin(progress * pi);

        final frame = createCurlLandmarks(
          elbowAngleDeg: 165.0, // stationary arms
          kneeAngleDeg: kneeAngle,
          hipY: hipY,
        );

        counter.processLandmarks(frame, frameTime);
      }

      expect(counter.correctReps, 0, reason: 'Stationary arms with moving legs must produce 0 curl reps');
      expect(counter.rejectedReps, 0);
    });

    test('Bicep Curls: Leg motion during curl suppresses and rejects rep with lower body warning', () {
      final counter = AutomaticRepCounter(exerciseId: 'bicep_curls');
      final baseTime = DateTime(2026, 9, 6, 10, 0, 0);

      for (int i = 0; i < 5; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: i * 50));
        final frame = createCurlLandmarks(elbowAngleDeg: 165.0, kneeAngleDeg: 175.0);
        counter.processLandmarks(frame, frameTime);
      }

      // Curl movement 165 -> 40 -> 165 while legs move
      for (int i = 0; i < 40; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: (5 + i) * 50));
        final double progress = i / 40.0;
        final double elbowAngle = 165.0 - 125.0 * sin(progress * pi);
        final double kneeAngle = 170.0 - 60.0 * sin(progress * pi); // active leg motion
        final double hipY = 0.55 + 0.10 * sin(progress * pi);

        final frame = createCurlLandmarks(
          elbowAngleDeg: elbowAngle,
          kneeAngleDeg: kneeAngle,
          hipY: hipY,
        );

        counter.processLandmarks(frame, frameTime);
      }

      for (int i = 0; i < 5; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: (45 + i) * 50));
        final frame = createCurlLandmarks(elbowAngleDeg: 165.0, kneeAngleDeg: 175.0);
        counter.processLandmarks(frame, frameTime);
      }

      expect(counter.correctReps, 0, reason: 'Curl attempted while moving legs must NOT be counted as valid');
      expect(counter.rejectedReps, greaterThanOrEqualTo(1));
    });

    test('Bicep Curls: Clean curl sequence counts correctly with high form score', () {
      final counter = AutomaticRepCounter(exerciseId: 'bicep_curls');
      final baseTime = DateTime(2026, 9, 6, 10, 0, 0);

      // Initial frames at full extension (165°)
      for (int i = 0; i < 5; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: i * 50));
        final frame = createCurlLandmarks(
          elbowAngleDeg: 165.0,
          kneeAngleDeg: 175.0,
        );
        counter.processLandmarks(frame, frameTime);
      }

      // Clean curl: lower body still, arm curls smoothly 165° -> 40° -> 165°
      RepCounterResult? repResult;
      for (int i = 0; i < 40; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: (5 + i) * 50));
        final double progress = i / 40.0;
        final double elbowAngle = 165.0 - 125.0 * sin(progress * pi); // reaches 40° at mid

        final frame = createCurlLandmarks(
          elbowAngleDeg: elbowAngle,
          kneeAngleDeg: 175.0,
          hipY: 0.55,
        );

        final r = counter.processLandmarks(frame, frameTime);
        if (counter.correctReps > 0 && repResult == null) {
          repResult = r;
        }
      }

      // Trailing frames at lockout/extension
      for (int i = 0; i < 8; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: (45 + i) * 50));
        final frame = createCurlLandmarks(
          elbowAngleDeg: 165.0,
          kneeAngleDeg: 175.0,
        );
        final r = counter.processLandmarks(frame, frameTime);
        if (counter.correctReps > 0 && repResult == null) {
          repResult = r;
        }
      }

      expect(counter.correctReps, 1, reason: 'Clean curl with still lower body must count 1 rep');
      expect(counter.rejectedReps, 0);
      expect(repResult?.formScore ?? counter.processLandmarks([]).formScore, greaterThanOrEqualTo(85.0));
    });

    test('Push-up v2: Clean push-up counts 1 rep; shallow push-up is rejected', () {
      final counter = AutomaticRepCounter(exerciseId: 'pushups');
      final baseTime = DateTime(2026, 9, 6, 10, 0, 0);

      // Initial setup frames in plank
      for (int i = 0; i < 5; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: i * 50));
        final frame = createPushupLandmarks(elbowAngleDeg: 165.0);
        counter.processLandmarks(frame, frameTime);
      }

      // 1. Clean push-up: 165° -> 90° (held for 200ms) -> 165°
      for (int i = 0; i < 40; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: (5 + i) * 50));
        double angle;
        if (i < 15) {
          angle = 165.0 - (75.0 * (i / 15.0)); // desc to 90°
        } else if (i < 20) {
          angle = 90.0; // dwell 250ms
        } else {
          angle = 90.0 + (75.0 * ((i - 20) / 20.0)); // asc to 165°
        }

        final frame = createPushupLandmarks(elbowAngleDeg: angle);
        counter.processLandmarks(frame, frameTime);
      }

      // Trailing lockout frames
      for (int i = 0; i < 8; i++) {
        final frameTime = baseTime.add(Duration(milliseconds: (45 + i) * 50));
        final frame = createPushupLandmarks(elbowAngleDeg: 165.0);
        counter.processLandmarks(frame, frameTime);
      }

      expect(counter.correctReps, 1, reason: 'Full depth push-up with lockout must count');

      // 2. Shallow push-up: 165° -> 125° -> 165° (does not reach <= 100°)
      final shallowBaseTime = baseTime.add(const Duration(seconds: 10));
      for (int i = 0; i < 5; i++) {
        final frameTime = shallowBaseTime.add(Duration(milliseconds: i * 50));
        final frame = createPushupLandmarks(elbowAngleDeg: 165.0);
        counter.processLandmarks(frame, frameTime);
      }

      for (int i = 0; i < 30; i++) {
        final frameTime = shallowBaseTime.add(Duration(milliseconds: (5 + i) * 50));
        final double progress = i / 30.0;
        final double angle = 165.0 - 40.0 * sin(progress * pi); // only reaches 125°

        final frame = createPushupLandmarks(elbowAngleDeg: angle);
        counter.processLandmarks(frame, frameTime);
      }

      for (int i = 0; i < 8; i++) {
        final frameTime = shallowBaseTime.add(Duration(milliseconds: (35 + i) * 50));
        final frame = createPushupLandmarks(elbowAngleDeg: 165.0);
        counter.processLandmarks(frame, frameTime);
      }

      expect(counter.correctReps, 1);
      expect(counter.rejectedReps, 1, reason: 'Shallow push-up must be rejected');
    });
  });
}
