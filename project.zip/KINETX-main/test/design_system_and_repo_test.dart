import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fitness_app/core/design_system/design_system.dart';
import 'package:fitness_app/data/models/workout_session.dart';
import 'package:fitness_app/data/repositories/workout_repository.dart';

void main() {
  group('WorkoutRepository Quality Bar & Zero-Mock Verification', () {
    setUp(() {
      SharedPreferences.setMockInitialValues({});
    });

    test('Fresh storage starts completely empty with zero fabricated sessions', () async {
      final sessions = await WorkoutRepository.getSessions();
      expect(sessions, isEmpty);

      final stats = await WorkoutRepository.getTotalStats();
      expect(stats.totalWorkouts, 0);
      expect(stats.totalReps, 0);
      expect(stats.totalCalories, 0.0);
      expect(stats.averageFormScore, 0.0);
      expect(stats.totalMinutes, 0);

      final streak = WorkoutRepository.computeCurrentStreak(sessions);
      expect(streak, 0);
    });

    test('Completed workout persists and aggregates accurately without mock inflation', () async {
      final now = DateTime.now();
      final session = WorkoutSession(
        id: 'session_test_1',
        exerciseId: 'squats',
        exerciseName: 'Bodyweight Squats',
        startTime: now.subtract(const Duration(seconds: 120)),
        endTime: now,
        durationSeconds: 120,
        totalAttempts: 15,
        correctReps: 14,
        rejectedReps: 1,
        averageFormScore: 93.3,
        estimatedCalories: 4.6,
      );

      await WorkoutRepository.saveSession(session);

      final sessions = await WorkoutRepository.getSessions();
      expect(sessions.length, 1);
      expect(sessions.first.id, 'session_test_1');
      expect(sessions.first.correctReps, 14);

      final stats = await WorkoutRepository.getTotalStats();
      expect(stats.totalWorkouts, 1);
      expect(stats.totalReps, 14);
      expect(stats.averageFormScore, closeTo(93.3, 0.1));
      expect(stats.totalCalories, closeTo(4.6, 0.1));

      final streak = WorkoutRepository.computeCurrentStreak(sessions);
      expect(streak, 1);
    });
  });

  group('Design System Components & Text Scale Resilience (+20%)', () {
    testWidgets('AppCard, StatTile, FormBadge, and EmptyState render without overflow at 1.2x scale',
        (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          theme: ThemeData.dark(),
          builder: (context, child) {
            // Test +20% text scaling
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(
                textScaler: const TextScaler.linear(1.2),
              ),
              child: child!,
            );
          },
          home: Scaffold(
            body: SingleChildScrollView(
              child: Column(
                children: [
                  const AppCard(
                    child: Text('Card Content'),
                  ),
                  const StatTile(
                    label: 'Active Reps',
                    value: '42',
                    subtitle: 'Tabular Space Grotesk',
                  ),
                  const FormBadge(score: 92.5),
                  const FormBadge(score: 75.0),
                  const FormBadge(score: 55.0),
                  const AppChip(
                    label: 'Beginner',
                    variant: ChipVariant.success,
                  ),
                  EmptyState(
                    title: 'No workouts yet',
                    description: 'Your sessions will appear here.',
                    buttonLabel: 'Start Workout',
                    onButtonPressed: () {},
                  ),
                ],
              ),
            ),
          ),
        ),
      );

      await tester.pumpAndSettle();

      expect(find.text('Card Content'), findsOneWidget);
      expect(find.text('42'), findsOneWidget);
      expect(find.text('92% Form'), findsOneWidget);
      expect(find.text('75% Form'), findsOneWidget);
      expect(find.text('55% Form'), findsOneWidget);
      expect(find.text('Beginner'), findsOneWidget);
      expect(find.text('No workouts yet'), findsOneWidget);
    });
  });
}
