1. Definition of Done
The MVP is complete when:
The app can be installed on a real Android phone.
The app behaves like a normal mobile app.
The user can set a daily reminder.
The user receives a local notification.
The dashboard shows daily stats.
The user can start Live Camera Mode.
The camera opens with permission handling.
MediaPipe detects pose locally.
The app shows pose overlay.
The app counts correct reps for at least one exercise.
The app rejects invalid reps.
The app gives basic feedback.
The workout session is saved locally.
History shows saved sessions.
The app works offline.
No camera data is uploaded.
The app can be tested without emulator.
The app does not require Android Studio to run.
The app does not require login.
The app is stable enough for daily personal use.
2. MVP Scope
Must have
Flutter Android app.
Home dashboard.
Daily tracking.
Workout history.
Reminders.
Live camera mode.
Local pose detection.
Rep counting.
Form checking.
Session saving.
Physical device testing.
Should have
Skeleton overlay.
Form score.
Audio feedback.
Vibration feedback.
Weekly chart.
Streak tracking.
Multiple exercises.
Nice to have, later
More exercises.
Custom workout plans.
Cloud backup.
User account.
Social features.
Wearable integration.
Advanced analytics.
iOS support.
Apple Health/Google Fit integration.
Video recording option with explicit consent.
Export workout data.
3. Risks and Mitigations
Risk 1: OpenCV integration is difficult
Mitigation:
Use MediaPipe-only pipeline for MVP.
Add OpenCV later only if stable.
Risk 2: MediaPipe Flutter plugin is unstable
Mitigation:
Use platform channels.
Or use ML Kit Pose Detection as fallback.
Risk 3: Camera performance is slow on low-end phone
Mitigation:
Use lightweight pose model.
Lower processing resolution.
Reduce frame processing rate.
Avoid OpenCV heavy operations.
Test in profile/release mode.
Risk 4: Rep counting is inaccurate
Mitigation:
Use smoothing.
Use hysteresis thresholds.
Use state machine.
Use confidence checks.
Test with real exercise videos.
Make thresholds configurable.
Risk 5: Android notifications are unreliable
Mitigation:
Request permissions properly.
Use exact alarm permission where needed.
Guide user to disable battery restrictions.
Later implement native alarm service.
Risk 6: User is not fully visible
Mitigation:
Show camera guidance.
Pause rep counting.
Show “Person not detected”.
Require full body visibility for squats.
Risk 7: PC is too slow for builds
Mitigation:
Use physical device.
Avoid emulator.
Use debug builds during iteration.
Use cloud CI for release builds.
4. Success Metrics
For MVP success, track manually:
App opens reliably.
Live camera mode works on real phone.
Pose detection works locally.
Correct reps are counted.
Wrong reps are rejected.
Session data is saved.
Reminder works.
User can use app daily.
No crashes during workout.
Camera does not overheat quickly.
5. Future Improvements
After MVP:
Add more exercises:
Lunges.
Shoulder press.
Plank.
Jumping jacks.
Deadlift, with safety limitations.
Add workout plans.
Add rest timer.
Add voice coaching.
Add progress charts.
Add body weight tracking.
Add achievements.
Add cloud backup.
Add iOS support.
Add Google Fit/Apple Health integration.
Add advanced form scoring.
Add personalized thresholds.
Add multi-set and multi-round workouts.
Add export data as CSV/JSON.
Add tablet layout.
6. Recommended Development Order
Step 1
Create Flutter project.
Step 2
Add core packages.
Step 3
Build app navigation.
Step 4
Build local database.
Step 5
Build dashboard UI.
Step 6
Build reminders.
Step 7
Build history.
Step 8
Build camera preview.
Step 9
Integrate pose detection.
Step 10
Build angle and rep engine.
Step 11
Build form validation.
Step 12
Save sessions.
Step 13
Test on physical Android phone.
Step 14
Optimize performance.
Step 15
Prepare release APK.
7. Final Product Expectation
The final MVP should allow a user to:
Open the app.
See today’s fitness dashboard.
Set a daily workout reminder.
Select an exercise.
Open the camera.
Perform the exercise.
See their body pose overlay.
Get live feedback.
Have correct reps counted.
Have wrong reps rejected.
Finish the session.
See saved workout history.
Track daily streak.
Use the app like a normal Android fitness app.