# Rule: Zero Mock Data in Production Code

1. No `const` demo lists or hardcoded sample objects of workout sessions, rep counts, volume values, streaks, or daily stats anywhere outside test fixtures.
2. Every numerical value, streak, and activity metric on every screen must be computed dynamically from the local database / repository.
3. Every date and time displayed in the UI must originate from real timestamps and be formatted with `intl`.
4. When the database is empty, screens must show designed empty states with purposeful CTAs, never fake demo numbers.
