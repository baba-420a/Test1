# PRD: Fitness App

App Name: Fitness App  
Project Name: fitness_app  
Version: 1.0  
Status: Draft  
Primary Builder: Antigravity AI  
Primary Editor: VS Code  
Target Platform: Android first, iOS later  
Testing Device: Physical Android phone only  
Emulator/Simulator: Not required and should be avoided  
Processing Mode: Local on-device processing only for camera pose detection  

---

## 1. Product Overview

Fitness App is a mobile fitness application built using Flutter. It should behave like a normal native mobile app and support:

1. Daily fitness tracking.
2. Workout reminders and alarms.
3. Exercise history and streak tracking.
4. Live camera-based exercise detection.
5. Local pose estimation using MediaPipe.
6. Optional OpenCV-based frame preprocessing.
7. Rep counting only when exercise form is correct.
8. Rejection or flagging of incorrect reps.
9. Offline-first usage.
10. Privacy-first camera processing with no video upload by default.

The app should allow the user to place their phone camera in front of them, perform exercises, and receive real-time feedback about form and repetitions.

---

## 2. Product Goal

The goal is to create a practical AI fitness coach app that can:

- Track daily workouts.
- Remind users to exercise.
- Count repetitions automatically.
- Detect incorrect exercise form.
- Work locally without sending camera video to a server.
- Run on a real Android phone.
- Be developed using Flutter and VS Code.
- Be generated/assisted by Antigravity AI.

---

## 3. Target Users

### Primary User

A fitness user who wants to:

- Exercise at home.
- Track daily workouts.
- Get reminders.
- Use phone camera as a form checker.
- Avoid paying for cloud AI services.
- Keep workout data private.

### Secondary User

A beginner who needs feedback about whether they are performing exercises correctly.

---

## 4. Core Value Proposition

The app should feel like a personal fitness companion that:

- Reminds the user to work out.
- Tracks progress.
- Uses the camera to count reps.
- Corrects exercise form.
- Works offline.
- Does not require a wearable device.

---

## 5. Platform Strategy

### MVP Platform

Android first.

### Later Platform

iOS support can be added later.

### Why Android first?

- User has a physical Android phone for testing.
- Android allows easier direct APK installation during development.
- Camera and notification behavior can be tested directly on device.
- PC is not powerful, so emulator must be avoided.

---

## 6. High-Level App Modes

### 6.1 Normal App Mode

The app should behave like a regular fitness app:

- Onboarding.
- Dashboard.
- Workout history.
- Reminders.
- Settings.
- Daily tracking.
- Streaks.
- Statistics.

### 6.2 Live Camera Mode

A camera-based workout mode where:

- The camera opens.
- The user performs an exercise.
- The app detects body movement.
- The app checks exercise form.
- The app counts only correct reps.
- The app rejects or warns about wrong reps.
- All processing happens locally on the phone.

---

## 7. Main Features

## 7.1 Onboarding

The app should include a simple onboarding flow.

### Required onboarding screens

1. Welcome screen.
2. Permission explanation screen.
3. Notification permission screen.
4. Camera permission explanation screen.
5. Basic profile setup.

### Profile fields

- Name, optional.
- Fitness level:
  - Beginner
  - Intermediate
  - Advanced
- Daily reminder time.
- Units:
  - kg/lb, optional for MVP.

### Onboarding requirements

- Must explain why camera permission is needed.
- Must explain why notifications are needed.
- Must not force account creation.
- MVP should work without login.

---

## 7.2 Home Dashboard

The home dashboard should show:

1. Today’s workout summary.
2. Current streak.
3. Total reps today.
4. Total workouts completed today.
5. Estimated calories burned.
6. Quick start button for Live Camera Mode.
7. Reminder status.
8. Weekly activity chart.

### Dashboard cards

- Today card.
- Streak card.
- Weekly progress card.
- Start workout card.
- Reminder card.

### Dashboard actions

- Start live workout.
- View history.
- Edit reminders.
- View settings.

---

## 7.3 Daily Tracking

The app should track daily fitness activity locally.

### Daily tracking fields

- Date.
- Workouts completed.
- Total reps.
- Correct reps.
- Rejected reps.
- Estimated calories.
- Active time.
- Exercises performed.
- Average form score.

### Daily tracking rules

- Data must be stored locally.
- Data must update immediately after a workout session.
- A day is considered completed if at least one workout session is saved.
- Streak increases when user completes at least one valid workout in a day.
- Streak resets if a full day is missed.

---

## 7.4 Workout History

The app should show previous workout sessions.

### History screen should show

- Date.
- Exercise name.
- Duration.
- Total reps.
- Correct reps.
- Rejected reps.
- Average form score.
- Notes/warnings, if any.

### History details screen

When user taps a session, show:

- Exercise.
- Start time.
- End time.
- Rep breakdown.
- Form warnings.
- Session summary.

---

## 7.5 Alarms and Reminders

The app must support fitness reminders.

### Reminder types

1. Daily workout reminder.
2. Custom time reminder.
3. Rest timer during workout.
4. Inactivity reminder, optional for later.

### Reminder features

- User can enable/disable reminders.
- User can select one or more daily times.
- User can select repeat days.
- Reminder should open the app or start workout screen.
- Reminder should work as local notification.
- On Android, request notification permission where required.
- On Android 12+, handle exact alarm permission if exact alarms are used.

### MVP reminder implementation

Use local notifications first.

Recommended Flutter packages:

- `flutter_local_notifications`
- `timezone`
- `permission_handler`

### Later improvement

For stronger alarm behavior, use:

- Android AlarmManager through platform channel.
- Native Kotlin alarm service.
- Foreground service if needed.

### Important constraint

Do not rely on background execution that Android may kill.  
For MVP, reminders can be notification-based.  
For reliable alarms, implement native Android exact alarms later.

---

## 7.6 Exercise Library

The app should include a small exercise library.

### MVP exercises

1. Squats.
2. Push-ups.
3. Bicep curls.

### Each exercise should include

- Exercise name.
- Description.
- Camera placement guide.
- Body visibility guide.
- Correct form rules.
- Common mistakes.
- Rep counting rules.
- Difficulty level.
- Estimated calories per rep, configurable.

---

## 7.7 Live Camera Mode

This is the core AI feature.

### Purpose

The Live Camera Mode should:

- Capture live camera frames.
- Detect the user’s body pose locally.
- Analyze exercise movement.
- Check if the exercise form is correct.
- Count correct repetitions.
- Reject wrong repetitions.
- Give real-time feedback.

### Live camera screen requirements

The screen should show:

1. Live camera preview.
2. Pose skeleton overlay.
3. Current exercise name.
4. Rep counter.
5. Correct rep count.
6. Rejected rep count.
7. Form score.
8. Live feedback message.
9. Start button.
10. Pause button.
11. Stop button.
12. Camera switch button.
13. Timer.
14. FPS indicator, debug-only optional.

### Camera behavior

- Must request camera permission before opening.
- Must support portrait mode first.
- Must support front camera and back camera.
- Front camera preview should be mirrored for user comfort.
- Must handle permission denial gracefully.
- Must show guidance if user is out of frame.
- Must pause processing when app goes to background.
- Must stop camera when screen is disposed.

### Camera guidance

Show on-screen guidance such as:

- “Place your full body inside the frame.”
- “Improve lighting.”
- “Move back.”
- “Keep your knees visible.”
- “Keep your elbows visible.”
- “Stay stable.”

---

## 8. Pose Detection and Movement Analysis

## 8.1 Technology Requirements

The app must use local on-device pose detection.

### Primary engine

MediaPipe Pose Landmarker.

### Optional helper

OpenCV may be used for:

- Frame preprocessing.
- Drawing helpers.
- Image conversion.
- Optional background filtering.
- Optional motion stabilization.

### Important technical note

If direct OpenCV integration becomes unstable or too heavy, the MVP should continue with MediaPipe only. OpenCV should be treated as optional enhancement, not a blocking dependency.

### No cloud processing

The MVP must not send camera frames or video to any external server.

All pose inference must run locally on the device.

---

## 8.2 Pose Detection Requirements

The pose engine should:

- Detect human pose landmarks in real time.
- Provide landmark coordinates.
- Provide landmark confidence scores.
- Work locally.
- Prefer a lightweight model for low-end and mid-range devices.
- Allow fallback from GPU to CPU if needed.

### Recommended MediaPipe model

Use a lightweight pose model for MVP:

- `pose_landmarker_lite`

Later options:

- `pose_landmarker_full`
- `pose_landmarker_heavy`

### Confidence rules

- Ignore landmarks with very low confidence.
- If key landmarks are missing, pause rep counting.
- Show “Person not detected” if confidence is too low.
- Do not count reps when visibility is poor.

---

## 8.3 Form Checking Engine

The app must include a rule-based form engine.

### Inputs

- Pose landmarks.
- Timestamps.
- Exercise type.
- Camera orientation.
- User profile, optional.

### Outputs

- Current phase:
  - Idle
  - Start
  - Down
  - Bottom
  - Up
  - Complete
- Rep validity:
  - Valid
  - Invalid
- Form score.
- Feedback message.

### Form score

Each rep should have a form score from 0 to 100.

A rep is counted as correct if:

```text
form_score >= minimum_correct_score

# PRD: Fitness App

App Name: Fitness App  
Project Name: fitness_app  
Version: 1.0  
Status: Draft  
Primary Builder: Antigravity AI  
Primary Editor: VS Code  
Target Platform: Android first, iOS later  
Testing Device: Physical Android phone only  
Emulator/Simulator: Not required and should be avoided  
Processing Mode: Local on-device processing only for camera pose detection  

---

## 1. Product Overview

Fitness App is a mobile fitness application built using Flutter. It should behave like a normal native mobile app and support:

1. Daily fitness tracking.
2. Workout reminders and alarms.
3. Exercise history and streak tracking.
4. Live camera-based exercise detection.
5. Local pose estimation using MediaPipe.
6. Optional OpenCV-based frame preprocessing.
7. Rep counting only when exercise form is correct.
8. Rejection or flagging of incorrect reps.
9. Offline-first usage.
10. Privacy-first camera processing with no video upload by default.

The app should allow the user to place their phone camera in front of them, perform exercises, and receive real-time feedback about form and repetitions.

---

## 2. Product Goal

The goal is to create a practical AI fitness coach app that can:

- Track daily workouts.
- Remind users to exercise.
- Count repetitions automatically.
- Detect incorrect exercise form.
- Work locally without sending camera video to a server.
- Run on a real Android phone.
- Be developed using Flutter and VS Code.
- Be generated/assisted by Antigravity AI.

---

## 3. Target Users

### Primary User

A fitness user who wants to:

- Exercise at home.
- Track daily workouts.
- Get reminders.
- Use phone camera as a form checker.
- Avoid paying for cloud AI services.
- Keep workout data private.

### Secondary User

A beginner who needs feedback about whether they are performing exercises correctly.

---

## 4. Core Value Proposition

The app should feel like a personal fitness companion that:

- Reminds the user to work out.
- Tracks progress.
- Uses the camera to count reps.
- Corrects exercise form.
- Works offline.
- Does not require a wearable device.

---

## 5. Platform Strategy

### MVP Platform

Android first.

### Later Platform

iOS support can be added later.

### Why Android first?

- User has a physical Android phone for testing.
- Android allows easier direct APK installation during development.
- Camera and notification behavior can be tested directly on device.
- PC is not powerful, so emulator must be avoided.

---

## 6. High-Level App Modes

### 6.1 Normal App Mode

The app should behave like a regular fitness app:

- Onboarding.
- Dashboard.
- Workout history.
- Reminders.
- Settings.
- Daily tracking.
- Streaks.
- Statistics.

### 6.2 Live Camera Mode

A camera-based workout mode where:

- The camera opens.
- The user performs an exercise.
- The app detects body movement.
- The app checks exercise form.
- The app counts only correct reps.
- The app rejects or warns about wrong reps.
- All processing happens locally on the phone.

---

## 7. Main Features

## 7.1 Onboarding

The app should include a simple onboarding flow.

### Required onboarding screens

1. Welcome screen.
2. Permission explanation screen.
3. Notification permission screen.
4. Camera permission explanation screen.
5. Basic profile setup.

### Profile fields

- Name, optional.
- Fitness level:
  - Beginner
  - Intermediate
  - Advanced
- Daily reminder time.
- Units:
  - kg/lb, optional for MVP.

### Onboarding requirements

- Must explain why camera permission is needed.
- Must explain why notifications are needed.
- Must not force account creation.
- MVP should work without login.

---

## 7.2 Home Dashboard

The home dashboard should show:

1. Today’s workout summary.
2. Current streak.
3. Total reps today.
4. Total workouts completed today.
5. Estimated calories burned.
6. Quick start button for Live Camera Mode.
7. Reminder status.
8. Weekly activity chart.

### Dashboard cards

- Today card.
- Streak card.
- Weekly progress card.
- Start workout card.
- Reminder card.

### Dashboard actions

- Start live workout.
- View history.
- Edit reminders.
- View settings.

---

## 7.3 Daily Tracking

The app should track daily fitness activity locally.

### Daily tracking fields

- Date.
- Workouts completed.
- Total reps.
- Correct reps.
- Rejected reps.
- Estimated calories.
- Active time.
- Exercises performed.
- Average form score.

### Daily tracking rules

- Data must be stored locally.
- Data must update immediately after a workout session.
- A day is considered completed if at least one workout session is saved.
- Streak increases when user completes at least one valid workout in a day.
- Streak resets if a full day is missed.

---

## 7.4 Workout History

The app should show previous workout sessions.

### History screen should show

- Date.
- Exercise name.
- Duration.
- Total reps.
- Correct reps.
- Rejected reps.
- Average form score.
- Notes/warnings, if any.

### History details screen

When user taps a session, show:

- Exercise.
- Start time.
- End time.
- Rep breakdown.
- Form warnings.
- Session summary.

---

## 7.5 Alarms and Reminders

The app must support fitness reminders.

### Reminder types

1. Daily workout reminder.
2. Custom time reminder.
3. Rest timer during workout.
4. Inactivity reminder, optional for later.

### Reminder features

- User can enable/disable reminders.
- User can select one or more daily times.
- User can select repeat days.
- Reminder should open the app or start workout screen.
- Reminder should work as local notification.
- On Android, request notification permission where required.
- On Android 12+, handle exact alarm permission if exact alarms are used.

### MVP reminder implementation

Use local notifications first.

Recommended Flutter packages:

- `flutter_local_notifications`
- `timezone`
- `permission_handler`

### Later improvement

For stronger alarm behavior, use:

- Android AlarmManager through platform channel.
- Native Kotlin alarm service.
- Foreground service if needed.

### Important constraint

Do not rely on background execution that Android may kill.  
For MVP, reminders can be notification-based.  
For reliable alarms, implement native Android exact alarms later.

---

## 7.6 Exercise Library

The app should include a small exercise library.

### MVP exercises

1. Squats.
2. Push-ups.
3. Bicep curls.

### Each exercise should include

- Exercise name.
- Description.
- Camera placement guide.
- Body visibility guide.
- Correct form rules.
- Common mistakes.
- Rep counting rules.
- Difficulty level.
- Estimated calories per rep, configurable.

---

## 7.7 Live Camera Mode

This is the core AI feature.

### Purpose

The Live Camera Mode should:

- Capture live camera frames.
- Detect the user’s body pose locally.
- Analyze exercise movement.
- Check if the exercise form is correct.
- Count correct repetitions.
- Reject wrong repetitions.
- Give real-time feedback.

### Live camera screen requirements

The screen should show:

1. Live camera preview.
2. Pose skeleton overlay.
3. Current exercise name.
4. Rep counter.
5. Correct rep count.
6. Rejected rep count.
7. Form score.
8. Live feedback message.
9. Start button.
10. Pause button.
11. Stop button.
12. Camera switch button.
13. Timer.
14. FPS indicator, debug-only optional.

### Camera behavior

- Must request camera permission before opening.
- Must support portrait mode first.
- Must support front camera and back camera.
- Front camera preview should be mirrored for user comfort.
- Must handle permission denial gracefully.
- Must show guidance if user is out of frame.
- Must pause processing when app goes to background.
- Must stop camera when screen is disposed.

### Camera guidance

Show on-screen guidance such as:

- “Place your full body inside the frame.”
- “Improve lighting.”
- “Move back.”
- “Keep your knees visible.”
- “Keep your elbows visible.”
- “Stay stable.”

---

## 8. Pose Detection and Movement Analysis

## 8.1 Technology Requirements

The app must use local on-device pose detection.

### Primary engine

MediaPipe Pose Landmarker.

### Optional helper

OpenCV may be used for:

- Frame preprocessing.
- Drawing helpers.
- Image conversion.
- Optional background filtering.
- Optional motion stabilization.

### Important technical note

If direct OpenCV integration becomes unstable or too heavy, the MVP should continue with MediaPipe only. OpenCV should be treated as optional enhancement, not a blocking dependency.

### No cloud processing

The MVP must not send camera frames or video to any external server.

All pose inference must run locally on the device.

---

## 8.2 Pose Detection Requirements

The pose engine should:

- Detect human pose landmarks in real time.
- Provide landmark coordinates.
- Provide landmark confidence scores.
- Work locally.
- Prefer a lightweight model for low-end and mid-range devices.
- Allow fallback from GPU to CPU if needed.

### Recommended MediaPipe model

Use a lightweight pose model for MVP:

- `pose_landmarker_lite`

Later options:

- `pose_landmarker_full`
- `pose_landmarker_heavy`

### Confidence rules

- Ignore landmarks with very low confidence.
- If key landmarks are missing, pause rep counting.
- Show “Person not detected” if confidence is too low.
- Do not count reps when visibility is poor.

---

## 8.3 Form Checking Engine

The app must include a rule-based form engine.

### Inputs

- Pose landmarks.
- Timestamps.
- Exercise type.
- Camera orientation.
- User profile, optional.

### Outputs

- Current phase:
  - Idle
  - Start
  - Down
  - Bottom
  - Up
  - Complete
- Rep validity:
  - Valid
  - Invalid
- Form score.
- Feedback message.

### Form score

Each rep should have a form score from 0 to 100.

A rep is counted as correct if:

```text
form_score >= minimum_correct_score (This value should be configurable.)

8.4 Rep Counting Engine
The rep counter must use a state machine.
State machine example
For squats:Standing -> Descending -> Bottom Position -> Ascending -> Standing

A rep is counted only if:
User starts from a valid standing position.
User descends deep enough.
User maintains acceptable form.
User returns to standing position.
Key landmarks remain visible.
Confidence is above threshold.
Movement speed is within reasonable range.
Rep rejection rules
A rep should be rejected if:
User does not go deep enough.
User leans too far forward.
User moves too fast.
User pauses too long in an invalid position.
Body leaves the frame.
Key joints are not visible.
Landmark confidence is too low.
Movement pattern does not match the selected exercise.
Form score is below threshold.
Wrong form feedback examples
“Go deeper.”
“Keep your back straight.”
“Slow down.”
“Keep your knees visible.”
“Rep not counted.”
“Adjust camera angle.”
“Make sure your full body is visible.”
9. Exercise-Specific Rules
9.1 Squats
Camera placement
Side view or slightly angled side view.
Required visible landmarks
Shoulder.
Hip.
Knee.
Ankle.
Key angles
Knee angle.
Hip angle.
Torso lean angle.
Standing threshold
Knee angle greater than approximately:160 degrees
Bottom threshold
Knee angle less than approximately:100 degrees(this should be configurable)
Correct squat rules
A squat is correct if:
User starts standing.
Knee angle decreases below bottom threshold.
Torso lean stays within allowed limit.
Knee and ankle remain reasonably aligned.
User returns to standing.
Confidence remains high.
Incorrect squat examples
Not going low enough.
Excessive forward lean.
Knees caving inward, if detectable.
Heels lifting, if detectable.
Too much upper-body movement.
Poor visibility.
9.2 Push-ups
Camera placement
Side view recommended.
Required visible landmarks
Shoulder.
Elbow.
Wrist.
Hip.
Key angles
Elbow angle.
Shoulder-elbow-wrist alignment.
Hip/trunk alignment.
Top position threshold
Elbow angle greater than approximately:160 degrees
Bottom position threshold
Elbow angle less than approximately:160 degrees
Correct push-up rules
A push-up is correct if:
User starts in top plank position.
Elbow bends below threshold.
Body remains relatively straight.
Hips do not sag too much.
Hips do not pike too much.
User returns to top position.
Incorrect push-up examples
Incomplete descent.
Incomplete extension.
Hip sagging.
Hip piking.
Excessive elbow flare, if detectable.
Camera angle too poor to estimate body line.
9.3 Bicep Curls
Camera placement
Front or side view.
Required visible landmarks
Shoulder.
Elbow.
Wrist.
Key angles
Elbow angle.
Extension threshold
Elbow angle greater than approximately:160 degrees
Elbow angle less than approximately:50 degrees

Correct curl rules
A curl is correct if:
Arm starts extended.
Elbow bends below curl threshold.
Elbow remains relatively stable.
Arm returns to extended position.
Movement speed is reasonable.
Incorrect curl examples
Incomplete curl.
Incomplete extension.
Elbow moving too much.
Body swinging too much.
Poor wrist/elbow visibility.
10. Live Workout Session Flow
Step 1: Select exercise
User selects:
Squats.
Push-ups.
Bicep curls.
Step 2: Camera setup
App shows:
Camera permission request.
Placement instructions.
Lighting instructions.
Body visibility instructions.
Step 3: Calibration
The app should detect:
Is a person visible?
Are required joints visible?
Is lighting acceptable?
Is confidence enough?
If not ready, show guidance.
Step 4: Start workout
User presses Start.
App begins:
Pose detection.
Movement tracking.
Rep counting.
Form checking.
Step 5: Live feedback
The app displays:
Rep count.
Form score.
Feedback message.
Warning message.
Optional:
Audio feedback.
Vibration feedback.
Step 6: Pause
User can pause session.
When paused:
Camera may remain open or stop, depending on implementation.
Rep counting stops.
Timer stops.
Step 7: Stop
User presses Stop.
App shows session summary.
Step 8: Save session
The app saves:
Exercise.
Start time.
End time.
Correct reps.
Rejected reps.
Form score.
Warnings.
Duration.
Estimated calories.
11. Session Summary Screen
After workout, show summary.
Summary fields
Exercise name.
Duration.
Correct reps.
Rejected reps.
Total detected attempts.
Average form score.
Estimated calories.
Feedback summary.
Date and time.
Actions
Save and finish.
Discard session.
Retry workout.
Default behavior:
Save automatically unless user discards.

12. Data Model
12.1 UserProfile
id
name
fitness_level
created_at
updated_at
preferred_reminder_time
notifications_enabled
camera_mirror_enabled
audio_feedback_enabled

12.2 Exercise
id
name
description
camera_placement
difficulty
calories_per_rep
is_enabled
created_at

12.3 WorkoutSession
id
exercise_id
start_time
end_time
duration_seconds
total_attempts
correct_reps
rejected_reps
average_form_score
estimated_calories
notes
created_at

12.4 RepEvent
id
workout_session_id
exercise_id
timestamp
rep_number
is_valid
form_score
rejection_reason
feedback_message

12.5 DailyStats
id
date
workout_count
total_reps
correct_reps
rejected_reps
estimated_calories
streak_updated
created_at
updated_at

12.6 Reminder
id
title
time
repeat_days
is_enabled
created_at
updated_at

13. Local Storage Requirements
The app should be offline-first.
Recommended storage options
Primary recommendation:
Drift
Alternative:
Isar
Hive
sqflite
MVP recommendation
Use Drift because it provides structured relational storage for:
Sessions.
Reps.
Daily stats.
Reminders.
Exercise metadata.
Storage rules
No cloud backend for MVP.
No account required.
No video storage by default.
No camera frames stored by default.
Optional developer debug mode may store landmarks only, disabled by default.
14. State Management
Use a clean and scalable state management approach.
Recommended
Riverpod.
Alternative
Bloc.
MVP recommendation
Use Riverpod.
State layers
UI state.
Workout session state.
Pose engine state.
Reminder state.
Database state.
15. App Architecture
Use a feature-first architecture.
Recommended structure:
lib/
  main.dart
  app/
    router.dart
    theme.dart
    app.dart
  core/
    utils/
    constants/
    extensions/
    permissions/
    notifications/
    storage/
  features/
    onboarding/
    home/
    dashboard/
    reminders/
    history/
    settings/
    live_workout/
    exercise_library/
  pose/
    pose_engine.dart
    pose_landmark.dart
    pose_processor.dart
    form_checker.dart
    rep_counter.dart
    exercise_rules/
      squat_rules.dart
      pushup_rules.dart
      curl_rules.dart
  data/
    models/
    repositories/
    local_db/

16. Required Permissions
Android:CAMERA
POST_NOTIFICATIONS
SCHEDULE_EXACT_ALARM
USE_EXACT_ALARM, if needed
RECEIVE_BOOT_COMPLETED, if rescheduling reminders after reboot
WAKE_LOCK, if needed for alarms/timers
VIBRATE, optional

ios:NSCameraUsageDescription
NSUserNotificationsUsageDescription or notification permission

Important
The app must not request unnecessary permissions.
For MVP, avoid:
Location.
Contacts.
Microphone, unless audio feedback requires it.
Storage, unless saving export files.
17. Privacy Requirements
Camera privacy
Camera frames must be processed locally.
Camera frames must not be uploaded.
Video must not be recorded by default.
Images must not be saved by default.
User must be informed that processing happens on-device.
Data privacy
Workout data should stay on device.
No third-party analytics for MVP.
No ads for MVP.
No tracking SDKs for MVP.
18. Performance Requirements
Because the user may have a mid-range or low-end phone, performance is important.
Target performance
For Live Camera Mode:
Minimum target: 10 FPS pose processing on low-end device.
Recommended target: 15-25 FPS on mid-range device.
UI must remain responsive.
Camera preview should not freeze.
Rep counting latency should feel near real-time.
Optimization rules
Use lightweight MediaPipe model for MVP.
Avoid storing frames.
Avoid heavy image processing unless necessary.
Use GPU delegate if available.
Fall back to CPU if GPU fails.
Reduce processing resolution if needed.
Use smoothing filters to reduce jitter.
19. UX Requirements
General UX
Simple.
Large buttons.
Clear labels.
High contrast.
Fitness-friendly colors.
Easy to start workout in under 3 taps.
Live camera UX
Rep counter should be large.
Feedback should be easy to read.
Warning messages should not block the whole screen.
Skeleton overlay should be semi-transparent.
Start/stop buttons should be reachable with one hand.
Accessibility
Support normal font scaling where possible.
Avoid tiny text.
Use clear icons.
Provide vibration feedback optional.
Provide audio feedback optional.
20. Screens List
MVP screens
Splash screen.
Onboarding screen.
Permission explanation screen.
Home dashboard.
Exercise selection screen.
Live camera screen.
Session summary screen.
History list screen.
History detail screen.
Reminders screen.
Settings screen.
Optional later screens
Progress chart screen.
Body weight tracking screen.
Achievement screen.
Exercise tutorial screen.
Profile screen.
Export data screen.
21. Navigation Requirements
Use simple navigation.
Recommended
GoRouter or Navigator 2.0.
MVP recommendation
Use go_router
Main routes:
/
/onboarding
/home
/exercises
/live-workout
/session-summary
/history
/history/:id
/reminders
/settings


22. Notifications Requirements
Notification types
Daily workout reminder.
Rest timer notification.
Session completed notification, optional.
Notification behavior
Tapping a workout reminder should open the app.
Ideally, it should open exercise selection or home dashboard.
Notification should not crash if permission is denied.
If notification permission is denied, show in-app reminder banner.
Android-specific
Android 13+ requires runtime notification permission.
Exact alarms may require special permission.
Battery optimization may affect reminders.
App should guide user to allow notifications and battery exceptions if needed.
23. Antigravity AI Build Instructions
Antigravity AI should generate a Flutter project that follows this PRD.
Primary technical constraints
Use Flutter.
Use Dart.
Use VS Code-compatible project structure.
Do not require Android Studio for testing.
Do not require emulator.
Must support physical Android device testing.
Must use local inference only.
Must not upload camera frames.
Must not require backend for MVP.
Must not require login for MVP.
Must keep code modular.
Must avoid unnecessary dependencies.
Must generate code step-by-step.
Antigravity AI should prioritize
Working app structure.
Local database.
Reminder system.
Dashboard.
Live camera preview.
MediaPipe pose detection.
Rep counting state machine.
Form validation.
Session saving.
Polish.
Antigravity AI should not
Generate fake rep counting.
Hardcode workout results.
Require cloud API.
Require user authentication for MVP.
Store camera video by default.
Build overly complex backend.
Depend on emulator-only features.
Add unnecessary third-party SDKs.

24. Recommended Flutter Packages
Use stable and maintained packages where possible.
Core:flutter_riverpod
go_router
intl
uuid
path_provider
shared_preferences
permission_handler

local database:drift
sqlite3_flutter_libs

notifications:flutter_local_notifications
timezone

camera:camera
charts:fl_chart

Pose detection
Use one of the following approaches:
Option A:MediaPipe Pose Landmarker through official or maintained Flutter plugin.
Option B:MediaPipe Pose Landmarker through Android/iOS platform channels.
Option C, fallback:Google ML Kit Pose Detection if MediaPipe integration becomes blocking.
Optional:opencv_dart or another maintained OpenCV Flutter plugin.
OpenCV should not block MVP if integration is unstable.
25. Camera and MediaPipe Implementation Plan
Phase 1: Camera preview
Implement:
Camera permission.
Camera initialization.
Live preview.
Camera switch.
Dispose camera properly.
Phase 2: Frame processing
Implement:
Camera image stream.
Frame conversion.
Pass frame to pose detector.
Receive landmarks.
Phase 3: Pose rendering
Implement:
Draw skeleton overlay.
Show confidence.
Show person detected/not detected.
Phase 4: Exercise rules
Implement:
Angle calculation.
Pose smoothing.
State machine.
Rep counting.
Form scoring.
Phase 5: Session saving
Implement:
Save session.
Save rep events.
Update daily stats.
Update dashboard.
26. Pose Processing Details
Landmark smoothing
Use smoothing to reduce jitter.
Recommended approaches:
Moving average.
One Euro filter.
Exponential smoothing.
Angle calculation
The app should calculate angles between three landmarks.
Example:Knee angle = angle(hip, knee, ankle)
Elbow angle = angle(shoulder, elbow, wrist)

Angle formula
Given three points:A = first joint
B = middle joint
C = end joint
Calculate angle at B.
The result should be in degrees.
Smoothing requirement
Do not count reps based on a single noisy frame.
Use:
Threshold hysteresis.
Minimum time in state.
Minimum confidence.
Consecutive valid frames.
27. Rep Counting Logic
Example squat state machine:IDLE
STANDING
DESCENDING
BOTTOM
ASCENDING
REP_COMPLETE

Rules
Enter DESCENDING when knee angle decreases from standing.
Enter BOTTOM when knee angle goes below bottom threshold.
Enter ASCENDING when knee angle starts increasing.
Count REP_COMPLETE when knee angle returns to standing threshold.
Reject rep if bottom threshold was never reached.
Reject rep if form score falls below threshold.
Reject rep if confidence drops.
Reject rep if user leaves frame.
Anti-cheating rules
The app should avoid counting:
Small bounces.
Partial reps.
Random movement.
Walking around.
Camera shake.
Non-exercise motion.
28. Form Feedback Rules
Feedback should be short and clear.
Feedback categories
Good form.
Correct rep.
Invalid rep.
Adjust position.
Poor visibility.
Example messages:Good rep
Go deeper
Keep your back straight
Move back
Improve lighting
Rep not counted
Slow down
Keep your knees visible
Person not detected

Feedback priority
Priority order:
Person not detected.
Poor visibility.
Dangerous/invalid form.
Rep rejected.
Rep counted.
Good form.
29. Error Handling
The app must handle:
Camera permission denied.
Notification permission denied.
Camera initialization failure.
Pose engine initialization failure.
Low storage.
Database failure.
App background during workout.
Phone rotation, if supported later.
Low FPS.
No person detected.
Multiple people detected, optional handling.
Error UX
Show simple message.
Offer retry.
Do not crash.
Do not lose saved sessions.
30. Testing Requirements
Testing must be done on a physical Android phone.
Device testing checklist
App installs on real device.
App opens without crash.
Camera permission works.
Notification permission works.
Reminder can be created.
Reminder notification appears.
Live camera opens.
Pose landmarks appear.
Rep counter works.
Wrong reps are rejected.
Session is saved.
Dashboard updates.
History shows session.
App works offline.
App does not overheat quickly.
Camera does not freeze.
App handles background/foreground properly.
Unit tests
Write unit tests for:
Angle calculation.
Rep state machine.
Form score calculation.
Daily streak calculation.
Session repository.
Reminder scheduling logic.
Widget tests
Write widget tests for:
Home dashboard.
Reminder screen.
History screen.
Session summary screen.
Manual camera tests
Test:
Good lighting.
Low light.
Front camera.
Back camera.
User too close.
User too far.
Partial body visible.
Wrong exercise movement.
Correct exercise movement.
Pausing and resuming.
App going background.
