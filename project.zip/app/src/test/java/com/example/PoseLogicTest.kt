package com.example

import com.example.pose.engine.RepStateMachine
import com.example.pose.math.PoseMath
import com.example.pose.model.ExerciseType
import com.example.pose.model.JointType
import com.example.pose.model.PoseLandmark
import com.example.pose.model.RepPhase
import com.example.pose.simulation.PoseSimulator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PoseLogicTest {

  @Test
  fun testAngleCalculation() {
    val a = PoseLandmark(JointType.RIGHT_SHOULDER, 0.5f, 0.2f)
    val b = PoseLandmark(JointType.RIGHT_ELBOW, 0.5f, 0.5f)
    val c = PoseLandmark(JointType.RIGHT_WRIST, 0.8f, 0.5f)

    val angle = PoseMath.calculateAngle(a, b, c)
    assertEquals(90.0, angle, 1.0)
  }

  @Test
  fun testSimulatorGeneratesValidPose() {
    val simulator = PoseSimulator(ExerciseType.SQUATS)
    val frame = simulator.nextFrame()

    assertTrue(frame.isPersonDetected)
    assertTrue(frame.landmarks.containsKey(JointType.RIGHT_HIP))
    assertTrue(frame.landmarks.containsKey(JointType.RIGHT_KNEE))
    assertTrue(frame.landmarks.containsKey(JointType.RIGHT_ANKLE))
  }

  @Test
  fun testRepStateMachineSquatCycle() {
    val machine = RepStateMachine(ExerciseType.SQUATS)
    val simulator = PoseSimulator(ExerciseType.SQUATS)

    // Simulate full squat cycle (down and up)
    for (i in 0..120) {
      val frame = simulator.nextFrame(0.02f)
      machine.processFrame(frame)
    }

    val state = machine.state.value
    // Should have recorded at least 1 rep
    assertTrue("Expected reps >= 1, got ${state.totalReps}", state.totalReps >= 1)
    assertTrue(state.correctReps >= 1)
    assertTrue(state.averageFormScore > 50)
  }
}
