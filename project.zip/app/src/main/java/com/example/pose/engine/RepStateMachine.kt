package com.example.pose.engine

import com.example.data.local.entity.RepEvent
import com.example.pose.math.AngleSmoother
import com.example.pose.model.ExerciseType
import com.example.pose.model.FormFeedback
import com.example.pose.model.PoseFrame
import com.example.pose.model.RepPhase
import com.example.pose.rules.BicepCurlRule
import com.example.pose.rules.EvaluationResult
import com.example.pose.rules.ExerciseRule
import com.example.pose.rules.PushupRule
import com.example.pose.rules.SquatRule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class WorkoutLiveState(
  val exerciseType: ExerciseType,
  val currentPhase: RepPhase = RepPhase.IDLE,
  val totalReps: Int = 0,
  val correctReps: Int = 0,
  val rejectedReps: Int = 0,
  val liveFormScore: Int = 100,
  val averageFormScore: Int = 100,
  val primaryAngle: Double = 0.0,
  val secondaryAngle: Double = 0.0,
  val feedback: FormFeedback = FormFeedback("Position yourself in front of camera", true, 100),
  val isCalibrated: Boolean = false,
  val repEvents: List<RepEvent> = emptyList()
)

class RepStateMachine(
  val exerciseType: ExerciseType,
  private val minFormScoreThreshold: Int = 70,
  private val onCueTriggered: ((isSuccess: Boolean, message: String) -> Unit)? = null
) {
  private val rule: ExerciseRule = when (exerciseType) {
    ExerciseType.SQUATS -> SquatRule()
    ExerciseType.PUSHUPS -> PushupRule()
    ExerciseType.BICEP_CURLS -> BicepCurlRule()
  }

  private val primaryAngleSmoother = AngleSmoother(0.4f)
  private val secondaryAngleSmoother = AngleSmoother(0.4f)

  private val _state = MutableStateFlow(WorkoutLiveState(exerciseType = exerciseType))
  val state: StateFlow<WorkoutLiveState> = _state.asStateFlow()

  private val formScores = mutableListOf<Int>()
  private val repEventsList = mutableListOf<RepEvent>()

  fun processFrame(frame: PoseFrame) {
    if (!frame.isPersonDetected || frame.landmarks.isEmpty()) {
      _state.value = _state.value.copy(
        isCalibrated = false,
        feedback = FormFeedback(
          message = "No person detected. Step into frame.",
          isPositive = false,
          currentScore = 40,
          hint = "Ensure good lighting and room"
        )
      )
      return
    }

    val current = _state.value
    val evalResult: EvaluationResult = rule.evaluate(frame, current.currentPhase, minFormScoreThreshold)

    val smoothedPrimary = primaryAngleSmoother.filter(evalResult.primaryAngle)
    val smoothedSecondary = secondaryAngleSmoother.filter(evalResult.secondaryAngle)

    var newCorrectReps = current.correctReps
    var newRejectedReps = current.rejectedReps
    var newTotalReps = current.totalReps

    if (evalResult.isRepCompleted) {
      newCorrectReps++
      newTotalReps++
      formScores.add(evalResult.formScore)
      val event = RepEvent(
        sessionId = 0,
        repNumber = newTotalReps,
        isValid = true,
        formScore = evalResult.formScore,
        feedbackMessage = evalResult.feedback.message,
        timestamp = System.currentTimeMillis()
      )
      repEventsList.add(event)
      onCueTriggered?.invoke(true, "Rep $newCorrectReps counted!")
    } else if (evalResult.isRepRejected) {
      newRejectedReps++
      newTotalReps++
      formScores.add(evalResult.formScore)
      val event = RepEvent(
        sessionId = 0,
        repNumber = newTotalReps,
        isValid = false,
        formScore = evalResult.formScore,
        feedbackMessage = evalResult.rejectionReason ?: "Form threshold violated",
        timestamp = System.currentTimeMillis()
      )
      repEventsList.add(event)
      onCueTriggered?.invoke(false, evalResult.rejectionReason ?: "Rep not counted")
    }

    val avgScore = if (formScores.isNotEmpty()) formScores.average().toInt() else 100

    _state.value = current.copy(
      currentPhase = evalResult.newPhase,
      totalReps = newTotalReps,
      correctReps = newCorrectReps,
      rejectedReps = newRejectedReps,
      liveFormScore = evalResult.formScore,
      averageFormScore = avgScore,
      primaryAngle = smoothedPrimary,
      secondaryAngle = smoothedSecondary,
      feedback = evalResult.feedback.copy(
        primaryAngle = smoothedPrimary,
        secondaryAngle = smoothedSecondary
      ),
      isCalibrated = true,
      repEvents = repEventsList.toList()
    )
  }

  fun reset() {
    primaryAngleSmoother.reset()
    secondaryAngleSmoother.reset()
    formScores.clear()
    repEventsList.clear()
    _state.value = WorkoutLiveState(exerciseType = exerciseType)
  }
}
