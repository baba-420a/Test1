package com.example.pose.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import com.example.pose.model.JointType
import com.example.pose.model.PoseFrame
import com.example.pose.model.PoseLandmark
import com.example.ui.theme.PoseBoneInvalid
import com.example.ui.theme.PoseBoneValid
import com.example.ui.theme.PoseJointInvalid
import com.example.ui.theme.PoseJointValid
import com.example.ui.theme.PoseJointWarning

@Composable
fun SkeletonOverlay(
  poseFrame: PoseFrame?,
  primaryAngle: Double,
  formScore: Int,
  isMirrored: Boolean = false,
  modifier: Modifier = Modifier
) {
  Canvas(modifier = modifier.fillMaxSize()) {
    if (poseFrame == null || !poseFrame.isPersonDetected || poseFrame.landmarks.isEmpty()) {
      return@Canvas
    }

    val width = size.width
    val height = size.height

    fun landmarkToOffset(lm: PoseLandmark): Offset {
      val xNorm = if (isMirrored) 1.0f - lm.x else lm.x
      return Offset(xNorm * width, lm.y * height)
    }

    val landmarks = poseFrame.landmarks

    // Determine current color scheme based on form score
    val (jointColor, boneColor) = when {
      formScore >= 75 -> Pair(PoseJointValid, PoseBoneValid)
      formScore >= 55 -> Pair(PoseJointWarning, Color(0xDDFFB300))
      else -> Pair(PoseJointInvalid, PoseBoneInvalid)
    }

    // Bone pairs
    val boneConnections = listOf(
      // Upper body
      Pair(JointType.LEFT_SHOULDER, JointType.RIGHT_SHOULDER),
      Pair(JointType.LEFT_SHOULDER, JointType.LEFT_ELBOW),
      Pair(JointType.LEFT_ELBOW, JointType.LEFT_WRIST),
      Pair(JointType.RIGHT_SHOULDER, JointType.RIGHT_ELBOW),
      Pair(JointType.RIGHT_ELBOW, JointType.RIGHT_WRIST),
      // Torso
      Pair(JointType.LEFT_SHOULDER, JointType.LEFT_HIP),
      Pair(JointType.RIGHT_SHOULDER, JointType.RIGHT_HIP),
      Pair(JointType.LEFT_HIP, JointType.RIGHT_HIP),
      // Lower body
      Pair(JointType.LEFT_HIP, JointType.LEFT_KNEE),
      Pair(JointType.LEFT_KNEE, JointType.LEFT_ANKLE),
      Pair(JointType.RIGHT_HIP, JointType.RIGHT_KNEE),
      Pair(JointType.RIGHT_KNEE, JointType.RIGHT_ANKLE)
    )

    // Draw bones
    for ((fromType, toType) in boneConnections) {
      val fromLm = landmarks[fromType]
      val toLm = landmarks[toType]
      if (fromLm != null && toLm != null) {
        val p1 = landmarkToOffset(fromLm)
        val p2 = landmarkToOffset(toLm)

        // Outer glow line
        drawLine(
          color = boneColor.copy(alpha = 0.25f),
          start = p1,
          end = p2,
          strokeWidth = 14f,
          cap = StrokeCap.Round
        )
        // Core bone line
        drawLine(
          color = boneColor,
          start = p1,
          end = p2,
          strokeWidth = 5f,
          cap = StrokeCap.Round
        )
      }
    }

    // Draw joints
    for ((_, lm) in landmarks) {
      val pos = landmarkToOffset(lm)

      // Outer glow circle
      drawCircle(
        color = jointColor.copy(alpha = 0.3f),
        radius = 16f,
        center = pos
      )
      // Inner sharp ring
      drawCircle(
        color = Color.White,
        radius = 8f,
        center = pos
      )
      // Solid center dot
      drawCircle(
        color = jointColor,
        radius = 5f,
        center = pos
      )
    }

    // Draw active angle readout near active joint
    if (primaryAngle > 0.0) {
      val activeJoint = landmarks[JointType.RIGHT_KNEE]
        ?: landmarks[JointType.RIGHT_ELBOW]
        ?: landmarks[JointType.LEFT_KNEE]
        ?: landmarks[JointType.LEFT_ELBOW]

      if (activeJoint != null) {
        val pos = landmarkToOffset(activeJoint)
        val textPaint = android.graphics.Paint().apply {
          color = android.graphics.Color.WHITE
          textSize = 38f
          isFakeBoldText = true
          setShadowLayer(8f, 0f, 0f, android.graphics.Color.BLACK)
        }
        val bgPaint = android.graphics.Paint().apply {
          color = android.graphics.Color.argb(180, 10, 15, 25)
          style = android.graphics.Paint.Style.FILL
        }
        val angleStr = "${primaryAngle.toInt()}°"
        val textWidth = textPaint.measureText(angleStr)

        drawContext.canvas.nativeCanvas.drawRoundRect(
          pos.x + 15f,
          pos.y - 45f,
          pos.x + 35f + textWidth,
          pos.y + 10f,
          12f,
          12f,
          bgPaint
        )
        drawContext.canvas.nativeCanvas.drawText(
          angleStr,
          pos.x + 25f,
          pos.y - 8f,
          textPaint
        )
      }
    }
  }
}
