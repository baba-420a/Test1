package com.example.pose.math

import com.example.pose.model.PoseLandmark
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object PoseMath {

  /**
   * Calculates the 2D angle (in degrees, 0..180) formed at middle point [b]
   * by ray b->a and ray b->c.
   */
  fun calculateAngle(
    a: PoseLandmark,
    b: PoseLandmark,
    c: PoseLandmark
  ): Double {
    val bax = a.x - b.x
    val bay = a.y - b.y
    val bcx = c.x - b.x
    val bcy = c.y - b.y

    val dotProduct = bax * bcx + bay * bcy
    val magBA = sqrt(bax * bax + bay * bay)
    val magBC = sqrt(bcx * bcx + bcy * bcy)

    if (magBA == 0f || magBC == 0f) return 0.0

    val cosTheta = (dotProduct / (magBA * magBC)).coerceIn(-1.0f, 1.0f)
    val radians = acos(cosTheta)
    return Math.toDegrees(radians.toDouble())
  }

  /**
   * Calculates inclination / lean angle from vertical (0° is straight up-down, 90° is horizontal)
   */
  fun calculateLeanAngle(
    top: PoseLandmark,
    bottom: PoseLandmark
  ): Double {
    val dx = (bottom.x - top.x).toDouble()
    val dy = (bottom.y - top.y).toDouble()
    val angleRadians = atan2(dx, dy)
    return Math.abs(Math.toDegrees(angleRadians))
  }

  /**
   * Calculates Euclidean distance between two landmarks.
   */
  fun calculateDistance(
    a: PoseLandmark,
    b: PoseLandmark
  ): Float {
    val dx = a.x - b.x
    val dy = a.y - b.y
    return sqrt(dx * dx + dy * dy)
  }
}

/**
 * Exponential moving average filter for smooth angle tracking.
 */
class AngleSmoother(private val alpha: Float = 0.35f) {
  private var currentVal: Double? = null

  fun filter(rawAngle: Double): Double {
    val prev = currentVal
    return if (prev == null) {
      currentVal = rawAngle
      rawAngle
    } else {
      val smoothed = alpha * rawAngle + (1f - alpha) * prev
      currentVal = smoothed
      smoothed
    }
  }

  fun reset() {
    currentVal = null
  }
}
