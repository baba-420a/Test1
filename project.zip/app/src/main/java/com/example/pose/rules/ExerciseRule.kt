package com.example.pose.rules

import com.example.pose.math.PoseMath
import com.example.pose.model.FormFeedback
import com.example.pose.model.JointType
import com.example.pose.model.PoseFrame
import com.example.pose.model.RepPhase

interface ExerciseRule {
  fun evaluate(
    frame: PoseFrame,
    currentPhase: RepPhase,
    targetMinFormScore: Int = 70
  ): EvaluationResult
}

data class EvaluationResult(
  val newPhase: RepPhase,
  val isRepCompleted: Boolean = false,
  val isRepRejected: Boolean = false,
  val rejectionReason: String? = null,
  val primaryAngle: Double = 0.0,
  val secondaryAngle: Double = 0.0,
  val formScore: Int = 100,
  val feedback: FormFeedback
)

class SquatRule : ExerciseRule {
  private var minKneeAngleInCurrentRep = 180.0
  private var maxLeanInCurrentRep = 0.0
  private var repStartTime = 0L

  override fun evaluate(
    frame: PoseFrame,
    currentPhase: RepPhase,
    targetMinFormScore: Int
  ): EvaluationResult {
    val landmarks = frame.landmarks

    // Prefer side with higher confidence or average left/right
    val hip = landmarks[JointType.RIGHT_HIP] ?: landmarks[JointType.LEFT_HIP]
    val knee = landmarks[JointType.RIGHT_KNEE] ?: landmarks[JointType.LEFT_KNEE]
    val ankle = landmarks[JointType.RIGHT_ANKLE] ?: landmarks[JointType.LEFT_ANKLE]
    val shoulder = landmarks[JointType.RIGHT_SHOULDER] ?: landmarks[JointType.LEFT_SHOULDER]

    if (hip == null || knee == null || ankle == null || shoulder == null) {
      return EvaluationResult(
        newPhase = currentPhase,
        feedback = FormFeedback("Ensure full body is visible", false, 50, 0.0, 0.0, "Step back from camera")
      )
    }

    val kneeAngle = PoseMath.calculateAngle(hip, knee, ankle)
    val torsoLean = PoseMath.calculateLeanAngle(shoulder, hip)

    var phase = currentPhase
    var repCompleted = false
    var repRejected = false
    var rejectionReason: String? = null
    var message = "Stand upright to begin"
    var isPositive = true
    var formScore = 100

    when (phase) {
      RepPhase.IDLE, RepPhase.START_POSITION -> {
        if (kneeAngle > 155.0) {
          phase = RepPhase.START_POSITION
          message = "Ready. Begin descending."
          minKneeAngleInCurrentRep = 180.0
          maxLeanInCurrentRep = 0.0
        } else if (kneeAngle in 110.0..155.0) {
          phase = RepPhase.ACTIVE_FLEXION
          repStartTime = System.currentTimeMillis()
          message = "Lower hips smoothly..."
        }
      }

      RepPhase.ACTIVE_FLEXION -> {
        if (kneeAngle < minKneeAngleInCurrentRep) minKneeAngleInCurrentRep = kneeAngle
        if (torsoLean > maxLeanInCurrentRep) maxLeanInCurrentRep = torsoLean

        if (torsoLean > 45.0) {
          message = "Keep your chest up!"
          isPositive = false
          formScore = 65
        } else {
          message = "Push hips back, sink deeper"
        }

        if (kneeAngle <= 105.0) {
          phase = RepPhase.PEAK_DEPTH
          message = "Great depth! Drive up."
        }
      }

      RepPhase.PEAK_DEPTH -> {
        if (kneeAngle < minKneeAngleInCurrentRep) minKneeAngleInCurrentRep = kneeAngle
        if (torsoLean > maxLeanInCurrentRep) maxLeanInCurrentRep = torsoLean

        if (kneeAngle > 115.0) {
          phase = RepPhase.ACTIVE_EXTENSION
          message = "Drive through heels!"
        }
      }

      RepPhase.ACTIVE_EXTENSION -> {
        if (torsoLean > maxLeanInCurrentRep) maxLeanInCurrentRep = torsoLean

        if (kneeAngle >= 155.0) {
          // Completed full cycle
          val durationMs = System.currentTimeMillis() - repStartTime
          val depthScore = when {
            minKneeAngleInCurrentRep <= 95.0 -> 100
            minKneeAngleInCurrentRep <= 105.0 -> 85
            minKneeAngleInCurrentRep <= 115.0 -> 60
            else -> 40
          }
          val leanPenalty = if (maxLeanInCurrentRep > 40.0) 25 else 0
          val calculatedScore = (depthScore - leanPenalty).coerceIn(0, 100)

          if (minKneeAngleInCurrentRep > 105.0) {
            repRejected = true
            rejectionReason = "Did not squat deep enough (${minKneeAngleInCurrentRep.toInt()}°)"
            message = "Shallow rep! Go below parallel."
            isPositive = false
            formScore = calculatedScore
            phase = RepPhase.REJECTED
          } else if (calculatedScore < targetMinFormScore) {
            repRejected = true
            rejectionReason = "Excessive torso lean (${maxLeanInCurrentRep.toInt()}°)"
            message = "Rep rejected: Keep torso upright"
            isPositive = false
            formScore = calculatedScore
            phase = RepPhase.REJECTED
          } else {
            repCompleted = true
            message = "Solid rep! Excellent depth."
            isPositive = true
            formScore = calculatedScore
            phase = RepPhase.COMPLETED
          }
        }
      }

      RepPhase.COMPLETED, RepPhase.REJECTED -> {
        if (kneeAngle > 155.0) {
          phase = RepPhase.START_POSITION
          message = "Reset. Ready for next rep."
          minKneeAngleInCurrentRep = 180.0
          maxLeanInCurrentRep = 0.0
        }
      }
    }

    return EvaluationResult(
      newPhase = phase,
      isRepCompleted = repCompleted,
      isRepRejected = repRejected,
      rejectionReason = rejectionReason,
      primaryAngle = kneeAngle,
      secondaryAngle = torsoLean,
      formScore = formScore,
      feedback = FormFeedback(
        message = message,
        isPositive = isPositive,
        currentScore = formScore,
        primaryAngle = kneeAngle,
        secondaryAngle = torsoLean,
        hint = "Target: Knee < 100°"
      )
    )
  }
}

class PushupRule : ExerciseRule {
  private var minElbowAngleInCurrentRep = 180.0
  private var minPlankAngleInCurrentRep = 180.0
  private var repStartTime = 0L

  override fun evaluate(
    frame: PoseFrame,
    currentPhase: RepPhase,
    targetMinFormScore: Int
  ): EvaluationResult {
    val landmarks = frame.landmarks

    val shoulder = landmarks[JointType.RIGHT_SHOULDER] ?: landmarks[JointType.LEFT_SHOULDER]
    val elbow = landmarks[JointType.RIGHT_ELBOW] ?: landmarks[JointType.LEFT_ELBOW]
    val wrist = landmarks[JointType.RIGHT_WRIST] ?: landmarks[JointType.LEFT_WRIST]
    val hip = landmarks[JointType.RIGHT_HIP] ?: landmarks[JointType.LEFT_HIP]
    val ankle = landmarks[JointType.RIGHT_ANKLE] ?: landmarks[JointType.LEFT_ANKLE]

    if (shoulder == null || elbow == null || wrist == null || hip == null) {
      return EvaluationResult(
        newPhase = currentPhase,
        feedback = FormFeedback("Align camera with full side view", false, 50, 0.0, 0.0, "Side view is ideal")
      )
    }

    val elbowAngle = PoseMath.calculateAngle(shoulder, elbow, wrist)
    val plankAngle = if (ankle != null) PoseMath.calculateAngle(shoulder, hip, ankle) else 170.0

    var phase = currentPhase
    var repCompleted = false
    var repRejected = false
    var rejectionReason: String? = null
    var message = "Establish top plank"
    var isPositive = true
    var formScore = 100

    when (phase) {
      RepPhase.IDLE, RepPhase.START_POSITION -> {
        if (elbowAngle > 155.0 && plankAngle > 145.0) {
          phase = RepPhase.START_POSITION
          message = "Plank locked. Lower chest."
          minElbowAngleInCurrentRep = 180.0
          minPlankAngleInCurrentRep = plankAngle
        } else if (elbowAngle in 100.0..155.0) {
          phase = RepPhase.ACTIVE_FLEXION
          repStartTime = System.currentTimeMillis()
          message = "Lowering chest with tight core..."
        }
      }

      RepPhase.ACTIVE_FLEXION -> {
        if (elbowAngle < minElbowAngleInCurrentRep) minElbowAngleInCurrentRep = elbowAngle
        if (plankAngle < minPlankAngleInCurrentRep) minPlankAngleInCurrentRep = plankAngle

        if (plankAngle < 140.0) {
          message = "Don't sag hips! Squeeze glutes."
          isPositive = false
          formScore = 65
        } else {
          message = "Lower chest toward floor"
        }

        if (elbowAngle <= 90.0) {
          phase = RepPhase.PEAK_DEPTH
          message = "Bottom depth reached! Press up."
        }
      }

      RepPhase.PEAK_DEPTH -> {
        if (elbowAngle < minElbowAngleInCurrentRep) minElbowAngleInCurrentRep = elbowAngle
        if (elbowAngle > 105.0) {
          phase = RepPhase.ACTIVE_EXTENSION
          message = "Drive the floor away!"
        }
      }

      RepPhase.ACTIVE_EXTENSION -> {
        if (plankAngle < minPlankAngleInCurrentRep) minPlankAngleInCurrentRep = plankAngle

        if (elbowAngle >= 155.0) {
          val depthScore = when {
            minElbowAngleInCurrentRep <= 85.0 -> 100
            minElbowAngleInCurrentRep <= 95.0 -> 85
            minElbowAngleInCurrentRep <= 110.0 -> 60
            else -> 40
          }
          val plankPenalty = if (minPlankAngleInCurrentRep < 140.0) 30 else 0
          val calculatedScore = (depthScore - plankPenalty).coerceIn(0, 100)

          if (minElbowAngleInCurrentRep > 95.0) {
            repRejected = true
            rejectionReason = "Incomplete chest depth (${minElbowAngleInCurrentRep.toInt()}°)"
            message = "Rep rejected: Lower chest further"
            isPositive = false
            formScore = calculatedScore
            phase = RepPhase.REJECTED
          } else if (minPlankAngleInCurrentRep < 135.0) {
            repRejected = true
            rejectionReason = "Hips sagged during movement"
            message = "Rep rejected: Keep spine straight"
            isPositive = false
            formScore = calculatedScore
            phase = RepPhase.REJECTED
          } else {
            repCompleted = true
            message = "Clean push-up! Full extension."
            isPositive = true
            formScore = calculatedScore
            phase = RepPhase.COMPLETED
          }
        }
      }

      RepPhase.COMPLETED, RepPhase.REJECTED -> {
        if (elbowAngle > 155.0) {
          phase = RepPhase.START_POSITION
          message = "In plank position. Go again."
          minElbowAngleInCurrentRep = 180.0
          minPlankAngleInCurrentRep = 180.0
        }
      }
    }

    return EvaluationResult(
      newPhase = phase,
      isRepCompleted = repCompleted,
      isRepRejected = repRejected,
      rejectionReason = rejectionReason,
      primaryAngle = elbowAngle,
      secondaryAngle = plankAngle,
      formScore = formScore,
      feedback = FormFeedback(
        message = message,
        isPositive = isPositive,
        currentScore = formScore,
        primaryAngle = elbowAngle,
        secondaryAngle = plankAngle,
        hint = "Target: Elbow < 90°"
      )
    )
  }
}

class BicepCurlRule : ExerciseRule {
  private var minElbowAngleInCurrentRep = 180.0
  private var repStartTime = 0L

  override fun evaluate(
    frame: PoseFrame,
    currentPhase: RepPhase,
    targetMinFormScore: Int
  ): EvaluationResult {
    val landmarks = frame.landmarks

    val shoulder = landmarks[JointType.RIGHT_SHOULDER] ?: landmarks[JointType.LEFT_SHOULDER]
    val elbow = landmarks[JointType.RIGHT_ELBOW] ?: landmarks[JointType.LEFT_ELBOW]
    val wrist = landmarks[JointType.RIGHT_WRIST] ?: landmarks[JointType.LEFT_WRIST]

    if (shoulder == null || elbow == null || wrist == null) {
      return EvaluationResult(
        newPhase = currentPhase,
        feedback = FormFeedback("Arm must be clearly in frame", false, 50, 0.0, 0.0, "Show shoulder, elbow, wrist")
      )
    }

    val elbowAngle = PoseMath.calculateAngle(shoulder, elbow, wrist)

    var phase = currentPhase
    var repCompleted = false
    var repRejected = false
    var rejectionReason: String? = null
    var message = "Extend arm fully downward"
    var isPositive = true
    var formScore = 100

    when (phase) {
      RepPhase.IDLE, RepPhase.START_POSITION -> {
        if (elbowAngle > 150.0) {
          phase = RepPhase.START_POSITION
          message = "Arm extended. Curl upward."
          minElbowAngleInCurrentRep = 180.0
        } else if (elbowAngle in 70.0..150.0) {
          phase = RepPhase.ACTIVE_FLEXION
          repStartTime = System.currentTimeMillis()
          message = "Curling up with controlled tempo..."
        }
      }

      RepPhase.ACTIVE_FLEXION -> {
        if (elbowAngle < minElbowAngleInCurrentRep) minElbowAngleInCurrentRep = elbowAngle

        if (elbowAngle <= 55.0) {
          phase = RepPhase.PEAK_DEPTH
          message = "Peak contraction! Squeeze bicep."
        }
      }

      RepPhase.PEAK_DEPTH -> {
        if (elbowAngle < minElbowAngleInCurrentRep) minElbowAngleInCurrentRep = elbowAngle
        if (elbowAngle > 70.0) {
          phase = RepPhase.ACTIVE_EXTENSION
          message = "Lower under eccentric control..."
        }
      }

      RepPhase.ACTIVE_EXTENSION -> {
        if (elbowAngle >= 150.0) {
          val curlScore = when {
            minElbowAngleInCurrentRep <= 50.0 -> 100
            minElbowAngleInCurrentRep <= 65.0 -> 80
            minElbowAngleInCurrentRep <= 80.0 -> 55
            else -> 35
          }

          if (minElbowAngleInCurrentRep > 65.0) {
            repRejected = true
            rejectionReason = "Incomplete curl height (${minElbowAngleInCurrentRep.toInt()}°)"
            message = "Rep rejected: Curl higher to chin"
            isPositive = false
            formScore = curlScore
            phase = RepPhase.REJECTED
          } else {
            repCompleted = true
            message = "Great curl! Full extension reached."
            isPositive = true
            formScore = curlScore
            phase = RepPhase.COMPLETED
          }
        }
      }

      RepPhase.COMPLETED, RepPhase.REJECTED -> {
        if (elbowAngle > 150.0) {
          phase = RepPhase.START_POSITION
          message = "Ready for next curl"
          minElbowAngleInCurrentRep = 180.0
        }
      }
    }

    return EvaluationResult(
      newPhase = phase,
      isRepCompleted = repCompleted,
      isRepRejected = repRejected,
      rejectionReason = rejectionReason,
      primaryAngle = elbowAngle,
      secondaryAngle = 0.0,
      formScore = formScore,
      feedback = FormFeedback(
        message = message,
        isPositive = isPositive,
        currentScore = formScore,
        primaryAngle = elbowAngle,
        secondaryAngle = 0.0,
        hint = "Target: Flex < 50°"
      )
    )
  }
}
