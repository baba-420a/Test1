package com.example.pose.model

enum class JointType {
  NOSE,
  LEFT_SHOULDER,
  RIGHT_SHOULDER,
  LEFT_ELBOW,
  RIGHT_ELBOW,
  LEFT_WRIST,
  RIGHT_WRIST,
  LEFT_HIP,
  RIGHT_HIP,
  LEFT_KNEE,
  RIGHT_KNEE,
  LEFT_ANKLE,
  RIGHT_ANKLE
}

data class PoseLandmark(
  val jointType: JointType,
  val x: Float, // Normalized 0.0 - 1.0 (relative to frame width)
  val y: Float, // Normalized 0.0 - 1.0 (relative to frame height)
  val z: Float = 0f,
  val confidence: Float = 1.0f
)

data class PoseFrame(
  val landmarks: Map<JointType, PoseLandmark>,
  val timestamp: Long = System.currentTimeMillis(),
  val isPersonDetected: Boolean = true,
  val overallConfidence: Float = 0.95f
)

enum class ExerciseType(
  val displayName: String,
  val targetMuscles: String,
  val caloriesPerRep: Double,
  val difficulty: String,
  val description: String,
  val cameraPlacementGuide: String,
  val correctFormGuide: String,
  val commonMistakes: String
) {
  SQUATS(
    displayName = "Squats",
    targetMuscles = "Quadriceps, Glutes, Hamstrings",
    caloriesPerRep = 0.32,
    difficulty = "Beginner",
    description = "Foundational lower-body compound movement building leg drive, hip mobility, and core balance.",
    cameraPlacementGuide = "Place phone at hip height, 6-8 feet away in landscape or portrait, angled slightly from the side.",
    correctFormGuide = "Hips initiate movement backward. Descend until thighs are parallel to ground (knee angle < 100°). Keep chest lifted and heels flat.",
    commonMistakes = "Shallow depth (knee angle > 110°), excessive forward torso lean, or knees caving inward."
  ),
  PUSHUPS(
    displayName = "Push-ups",
    targetMuscles = "Pectorals, Anterior Deltoids, Triceps",
    caloriesPerRep = 0.28,
    difficulty = "Intermediate",
    description = "Gold standard horizontal upper-body push reinforcing shoulder girdle stability and hollow-body core tension.",
    cameraPlacementGuide = "Position phone on the floor or a low riser 5-7 feet away with a side profile view of your entire body.",
    correctFormGuide = "Maintain rigid plank line from head to heels. Lower chest until elbows bend beyond 90°. Fully lock out at the top.",
    commonMistakes = "Sagging hips, piking hips upward, flared elbows beyond 75°, or incomplete extension at top."
  ),
  BICEP_CURLS(
    displayName = "Bicep Curls",
    targetMuscles = "Biceps Brachii, Brachialis, Forearms",
    caloriesPerRep = 0.18,
    difficulty = "Beginner",
    description = "Isolated arm flexion exercise emphasizing full bicep contraction, strict tempo, and eccentric control.",
    cameraPlacementGuide = "Prop phone on a desk or shelf at chest height, 4-6 feet away, front or slight 45° angle.",
    correctFormGuide = "Elbows pinned near torso. Curl upwards until elbow angle reaches under 50°. Lower fully back to 160°+ extension.",
    commonMistakes = "Swinging elbows forward or back, leaning backward with hips to cheat momentum, partial extension."
  )
}

enum class RepPhase(val label: String) {
  IDLE("Ready"),
  START_POSITION("In Position"),
  ACTIVE_FLEXION("Flexing / Descents"),
  PEAK_DEPTH("Peak Depth"),
  ACTIVE_EXTENSION("Ascending / Extending"),
  COMPLETED("Rep Counted"),
  REJECTED("Form Issue")
}

data class FormFeedback(
  val message: String,
  val isPositive: Boolean = true,
  val currentScore: Int = 100,
  val primaryAngle: Double = 0.0,
  val secondaryAngle: Double = 0.0,
  val hint: String = ""
)
