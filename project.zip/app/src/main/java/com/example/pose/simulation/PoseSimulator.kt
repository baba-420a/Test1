package com.example.pose.simulation

import com.example.pose.model.ExerciseType
import com.example.pose.model.JointType
import com.example.pose.model.PoseFrame
import com.example.pose.model.PoseLandmark
import kotlin.math.cos
import kotlin.math.sin

class PoseSimulator(private val exerciseType: ExerciseType) {
  private var progress = 0.0f // 0.0 to 1.0 cycle
  private var isGoingDown = true
  var formFlawMode: FormFlawMode = FormFlawMode.PERFECT

  enum class FormFlawMode(val label: String) {
    PERFECT("Perfect Form"),
    SHALLOW("Shallow Depth (Rejected)"),
    LEANING("Torso Lean / Sag (Rejected)")
  }

  fun nextFrame(deltaStep: Float = 0.025f): PoseFrame {
    if (isGoingDown) {
      progress += deltaStep
      if (progress >= 1.0f) {
        progress = 1.0f
        isGoingDown = false
      }
    } else {
      progress -= deltaStep
      if (progress <= 0.0f) {
        progress = 0.0f
        isGoingDown = true
      }
    }

    return when (exerciseType) {
      ExerciseType.SQUATS -> generateSquatFrame(progress, formFlawMode)
      ExerciseType.PUSHUPS -> generatePushupFrame(progress, formFlawMode)
      ExerciseType.BICEP_CURLS -> generateCurlFrame(progress, formFlawMode)
    }
  }

  private fun generateSquatFrame(p: Float, flaw: FormFlawMode): PoseFrame {
    // p = 0: standing upright
    // p = 1: bottom of squat
    val effectiveP = if (flaw == FormFlawMode.SHALLOW) p * 0.55f else p
    val leanFactor = if (flaw == FormFlawMode.LEANING) 0.12f * p else 0.03f * p

    val hipY = 0.50f + effectiveP * 0.22f
    val hipX = 0.50f - effectiveP * 0.06f
    val kneeY = 0.68f + effectiveP * 0.04f
    val kneeX = 0.53f + effectiveP * 0.02f
    val ankleY = 0.88f
    val ankleX = 0.52f

    val shoulderY = 0.28f + effectiveP * 0.17f
    val shoulderX = 0.49f - effectiveP * 0.04f + leanFactor * 1.8f
    val noseY = 0.18f + effectiveP * 0.16f
    val noseX = 0.49f - effectiveP * 0.03f + leanFactor * 2.2f

    val elbowY = 0.38f + effectiveP * 0.16f
    val elbowX = 0.54f
    val wristY = 0.35f + effectiveP * 0.16f
    val wristX = 0.58f

    val landmarks = mapOf(
      JointType.NOSE to PoseLandmark(JointType.NOSE, noseX, noseY),
      JointType.RIGHT_SHOULDER to PoseLandmark(JointType.RIGHT_SHOULDER, shoulderX, shoulderY),
      JointType.LEFT_SHOULDER to PoseLandmark(JointType.LEFT_SHOULDER, shoulderX - 0.04f, shoulderY),
      JointType.RIGHT_ELBOW to PoseLandmark(JointType.RIGHT_ELBOW, elbowX, elbowY),
      JointType.LEFT_ELBOW to PoseLandmark(JointType.LEFT_ELBOW, elbowX - 0.04f, elbowY),
      JointType.RIGHT_WRIST to PoseLandmark(JointType.RIGHT_WRIST, wristX, wristY),
      JointType.LEFT_WRIST to PoseLandmark(JointType.LEFT_WRIST, wristX - 0.04f, wristY),
      JointType.RIGHT_HIP to PoseLandmark(JointType.RIGHT_HIP, hipX, hipY),
      JointType.LEFT_HIP to PoseLandmark(JointType.LEFT_HIP, hipX - 0.03f, hipY),
      JointType.RIGHT_KNEE to PoseLandmark(JointType.RIGHT_KNEE, kneeX, kneeY),
      JointType.LEFT_KNEE to PoseLandmark(JointType.LEFT_KNEE, kneeX - 0.03f, kneeY),
      JointType.RIGHT_ANKLE to PoseLandmark(JointType.RIGHT_ANKLE, ankleX, ankleY),
      JointType.LEFT_ANKLE to PoseLandmark(JointType.LEFT_ANKLE, ankleX - 0.03f, ankleY)
    )

    return PoseFrame(landmarks = landmarks, isPersonDetected = true, overallConfidence = 0.98f)
  }

  private fun generatePushupFrame(p: Float, flaw: FormFlawMode): PoseFrame {
    val effectiveP = if (flaw == FormFlawMode.SHALLOW) p * 0.45f else p
    val sag = if (flaw == FormFlawMode.LEANING) 0.14f * p else 0.01f

    val ankleX = 0.22f
    val ankleY = 0.65f
    val hipX = 0.44f
    val hipY = 0.60f + effectiveP * 0.06f + sag
    val shoulderX = 0.70f
    val shoulderY = 0.52f + effectiveP * 0.15f
    val noseX = 0.78f
    val noseY = 0.48f + effectiveP * 0.15f
    val wristX = 0.68f
    val wristY = 0.78f
    val elbowX = 0.62f - effectiveP * 0.04f
    val elbowY = 0.64f + effectiveP * 0.08f

    val landmarks = mapOf(
      JointType.NOSE to PoseLandmark(JointType.NOSE, noseX, noseY),
      JointType.RIGHT_SHOULDER to PoseLandmark(JointType.RIGHT_SHOULDER, shoulderX, shoulderY),
      JointType.LEFT_SHOULDER to PoseLandmark(JointType.LEFT_SHOULDER, shoulderX, shoulderY - 0.03f),
      JointType.RIGHT_ELBOW to PoseLandmark(JointType.RIGHT_ELBOW, elbowX, elbowY),
      JointType.LEFT_ELBOW to PoseLandmark(JointType.LEFT_ELBOW, elbowX, elbowY - 0.03f),
      JointType.RIGHT_WRIST to PoseLandmark(JointType.RIGHT_WRIST, wristX, wristY),
      JointType.LEFT_WRIST to PoseLandmark(JointType.LEFT_WRIST, wristX, wristY - 0.03f),
      JointType.RIGHT_HIP to PoseLandmark(JointType.RIGHT_HIP, hipX, hipY),
      JointType.LEFT_HIP to PoseLandmark(JointType.LEFT_HIP, hipX, hipY - 0.03f),
      JointType.RIGHT_KNEE to PoseLandmark(JointType.RIGHT_KNEE, 0.33f, 0.63f + effectiveP * 0.03f),
      JointType.LEFT_KNEE to PoseLandmark(JointType.LEFT_KNEE, 0.33f, 0.60f + effectiveP * 0.03f),
      JointType.RIGHT_ANKLE to PoseLandmark(JointType.RIGHT_ANKLE, ankleX, ankleY),
      JointType.LEFT_ANKLE to PoseLandmark(JointType.LEFT_ANKLE, ankleX, ankleY - 0.03f)
    )

    return PoseFrame(landmarks = landmarks, isPersonDetected = true, overallConfidence = 0.98f)
  }

  private fun generateCurlFrame(p: Float, flaw: FormFlawMode): PoseFrame {
    val effectiveP = if (flaw == FormFlawMode.SHALLOW) p * 0.50f else p

    val shoulderX = 0.50f
    val shoulderY = 0.32f
    val elbowX = 0.51f
    val elbowY = 0.52f

    // Angle of forearm from straight down (p=0: 170° angle at elbow, p=1: 40° angle at elbow)
    val armAngleRad = (Math.PI / 2.0) - (effectiveP * 2.1)
    val forearmLength = 0.20f
    val wristX = (elbowX + cos(armAngleRad) * forearmLength).toFloat()
    val wristY = (elbowY + sin(armAngleRad) * forearmLength).toFloat()

    val landmarks = mapOf(
      JointType.NOSE to PoseLandmark(JointType.NOSE, 0.50f, 0.20f),
      JointType.RIGHT_SHOULDER to PoseLandmark(JointType.RIGHT_SHOULDER, shoulderX, shoulderY),
      JointType.LEFT_SHOULDER to PoseLandmark(JointType.LEFT_SHOULDER, shoulderX - 0.12f, shoulderY),
      JointType.RIGHT_ELBOW to PoseLandmark(JointType.RIGHT_ELBOW, elbowX, elbowY),
      JointType.LEFT_ELBOW to PoseLandmark(JointType.LEFT_ELBOW, elbowX - 0.12f, elbowY),
      JointType.RIGHT_WRIST to PoseLandmark(JointType.RIGHT_WRIST, wristX, wristY),
      JointType.LEFT_WRIST to PoseLandmark(JointType.LEFT_WRIST, wristX - 0.12f, wristY),
      JointType.RIGHT_HIP to PoseLandmark(JointType.RIGHT_HIP, 0.50f, 0.62f),
      JointType.LEFT_HIP to PoseLandmark(JointType.LEFT_HIP, 0.42f, 0.62f),
      JointType.RIGHT_KNEE to PoseLandmark(JointType.RIGHT_KNEE, 0.50f, 0.78f),
      JointType.LEFT_KNEE to PoseLandmark(JointType.LEFT_KNEE, 0.42f, 0.78f),
      JointType.RIGHT_ANKLE to PoseLandmark(JointType.RIGHT_ANKLE, 0.50f, 0.92f),
      JointType.LEFT_ANKLE to PoseLandmark(JointType.LEFT_ANKLE, 0.42f, 0.92f)
    )

    return PoseFrame(landmarks = landmarks, isPersonDetected = true, overallConfidence = 0.98f)
  }
}
