package com.example.ui.workout

import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.util.concurrent.Executor

@Composable
fun CameraPreviewView(
  lensFacing: Int,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current

  val previewView = remember {
    PreviewView(context).apply {
      scaleType = PreviewView.ScaleType.FILL_CENTER
      implementationMode = PreviewView.ImplementationMode.COMPATIBLE
    }
  }

  val mainExecutor: Executor = remember { ContextCompat.getMainExecutor(context) }

  DisposableEffect(lensFacing) {
    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

    cameraProviderFuture.addListener({
      try {
        val cameraProvider = cameraProviderFuture.get()
        val preview = Preview.Builder().build().also {
          it.surfaceProvider = previewView.surfaceProvider
        }

        val cameraSelector = CameraSelector.Builder()
          .requireLensFacing(lensFacing)
          .build()

        cameraProvider.unbindAll()
        if (cameraProvider.hasCamera(cameraSelector)) {
          cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview)
        }
      } catch (e: Exception) {
        // Handled gracefully in emulator or device without camera
      }
    }, mainExecutor)

    onDispose {
      try {
        val cameraProvider = cameraProviderFuture.get()
        cameraProvider.unbindAll()
      } catch (e: Exception) {
        // Ignored
      }
    }
  }

  Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
    AndroidView(
      factory = { previewView },
      modifier = Modifier.fillMaxSize()
    )
  }
}
