package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.NotificationHelper
import com.example.data.local.FitnessDatabase
import com.example.data.local.entity.DailyStats
import com.example.data.local.entity.Reminder
import com.example.data.local.entity.RepEvent
import com.example.data.local.entity.UserProfile
import com.example.data.local.entity.WorkoutSession
import com.example.data.repository.FitnessRepository
import com.example.ui.models.AchievementBadge
import com.example.ui.models.LoggedFood
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import java.util.Locale

class FitnessViewModel(application: Application) : AndroidViewModel(application) {

  private val database = FitnessDatabase.getDatabase(application, viewModelScope)
  val repository = FitnessRepository(database.fitnessDao())
  val notificationHelper = NotificationHelper(application)

  // --- Water Hydration & Food Tracker Persistence ---
  private val prefs = application.getSharedPreferences("pumpd_fitness_prefs", android.content.Context.MODE_PRIVATE)
  private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
  private val foodListAdapter = moshi.adapter<List<LoggedFood>>(
    Types.newParameterizedType(List::class.java, LoggedFood::class.java)
  )

  private fun getTodayDateString(): String {
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
    return sdf.format(java.util.Date())
  }

  private val _waterCups = MutableStateFlow(0)
  val waterCups: StateFlow<Int> = _waterCups.asStateFlow()

  private val _loggedFoods = MutableStateFlow<List<LoggedFood>>(emptyList())
  val loggedFoods: StateFlow<List<LoggedFood>> = _loggedFoods.asStateFlow()

  init {
    loadDailyTrackerData()
  }

  fun loadDailyTrackerData() {
    val today = getTodayDateString()
    val cups = prefs.getInt("water_$today", 0)
    _waterCups.value = cups

    val foodsJson = prefs.getString("foods_$today", null)
    if (foodsJson != null) {
      try {
        val list = foodListAdapter.fromJson(foodsJson) ?: emptyList()
        _loggedFoods.value = list
      } catch (e: Exception) {
        _loggedFoods.value = emptyList()
      }
    } else {
      _loggedFoods.value = emptyList()
    }
  }

  fun addWaterCup() {
    val today = getTodayDateString()
    val newCount = _waterCups.value + 1
    prefs.edit().putInt("water_$today", newCount).apply()
    _waterCups.value = newCount
  }

  fun removeWaterCup() {
    val today = getTodayDateString()
    val newCount = (_waterCups.value - 1).coerceAtLeast(0)
    prefs.edit().putInt("water_$today", newCount).apply()
    _waterCups.value = newCount
  }

  fun logFood(name: String, calories: Int, protein: Int, carbs: Int, fat: Int, imageUrl: String? = null) {
    val today = getTodayDateString()
    val currentList = _loggedFoods.value.toMutableList()
    val newFood = LoggedFood(
      id = java.util.UUID.randomUUID().toString(),
      name = name,
      calories = calories,
      protein = protein,
      carbs = carbs,
      fat = fat,
      timestamp = System.currentTimeMillis(),
      imageUrl = imageUrl
    )
    currentList.add(newFood)
    _loggedFoods.value = currentList
    
    try {
      val json = foodListAdapter.toJson(currentList)
      prefs.edit().putString("foods_$today", json).apply()
    } catch (e: Exception) {
      // Ignored
    }
  }

  fun deleteFood(id: String) {
    val today = getTodayDateString()
    val currentList = _loggedFoods.value.filter { it.id != id }
    _loggedFoods.value = currentList
    try {
      val json = foodListAdapter.toJson(currentList)
      prefs.edit().putString("foods_$today", json).apply()
    } catch (e: Exception) {
      // Ignored
    }
  }

  fun analyzeFoodImage(
    bitmap: android.graphics.Bitmap,
    onSuccess: (foodName: String, calories: Int, protein: Int, carbs: Int, fat: Int) -> Unit,
    onFailure: (String) -> Unit
  ) {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        // Prepare base64 image data
        val outputStream = java.io.ByteArrayOutputStream()
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, outputStream)
        val base64Image = android.util.Base64.encodeToString(outputStream.toByteArray(), android.util.Base64.NO_WRAP)

        val apiKey = com.example.BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "PLACEHOLDER") {
          throw IllegalStateException("API key is default or empty")
        }

        val client = okhttp3.OkHttpClient.Builder()
          .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
          .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
          .build()

        val requestJson = """
          {
            "contents": [
              {
                "parts": [
                  { "text": "Analyze this food item. Provide an estimate of nutrition. Response must be a single JSON object containing: 'foodName', 'calories' (integer kcal), 'protein' (integer grams), 'carbs' (integer grams), 'fat' (integer grams). No markdown, no formatting, no triple backticks, just the raw JSON." },
                  {
                    "inlineData": {
                      "mimeType": "image/jpeg",
                      "data": "$base64Image"
                    }
                  }
                ]
              }
            ],
            "generationConfig": {
              "responseMimeType": "application/json"
            }
          }
        """.trimIndent()

        val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
        val body = okhttp3.RequestBody.create(mediaType, requestJson)

        val request = okhttp3.Request.Builder()
          .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
          .post(body)
          .build()

        client.newCall(request).execute().use { response ->
          if (!response.isSuccessful) {
            throw java.io.IOException("Unsuccessful response: ${response.code} ${response.message}")
          }
          val responseStr = response.body?.string() ?: ""
          
          val mapAdapter = moshi.adapter<Map<String, Any>>(
            Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)
          )
          
          val root = mapAdapter.fromJson(responseStr)
          val candidates = root?.get("candidates") as? List<*>
          val firstCandidate = candidates?.firstOrNull() as? Map<*, *>
          val content = firstCandidate?.get("content") as? Map<*, *>
          val parts = content?.get("parts") as? List<*>
          val firstPart = parts?.firstOrNull() as? Map<*, *>
          val text = firstPart?.get("text") as? String ?: ""
          
          val cleanJson = text.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

          val resultAdapter = moshi.adapter<Map<String, Any>>(
            Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)
          )
          val resultObj = resultAdapter.fromJson(cleanJson)
          val foodName = resultObj?.get("foodName") as? String ?: "Scanned Food"
          
          val calories = ((resultObj?.get("calories") as? Double)?.toInt())
            ?: ((resultObj?.get("calories") as? Int))
            ?: 350
          val protein = ((resultObj?.get("protein") as? Double)?.toInt())
            ?: ((resultObj?.get("protein") as? Int))
            ?: 15
          val carbs = ((resultObj?.get("carbs") as? Double)?.toInt())
            ?: ((resultObj?.get("carbs") as? Int))
            ?: 30
          val fat = ((resultObj?.get("fat") as? Double)?.toInt())
            ?: ((resultObj?.get("fat") as? Int))
            ?: 10

          withContext(Dispatchers.Main) {
            onSuccess(foodName, calories, protein, carbs, fat)
          }
        }
      } catch (e: Exception) {
        withContext(Dispatchers.Main) {
          onFailure(e.localizedMessage ?: "Unknown scanning error")
        }
      }
    }
  }

  // --- Dynamic Achievement Badges Flow ---
  val achievementBadges: StateFlow<List<AchievementBadge>> = combine(
    repository.allSessions,
    repository.currentStreak,
    waterCups,
    loggedFoods
  ) { sessions, streak, water, foods ->
    calculateBadges(sessions, streak, water, foods)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private fun calculateBadges(
    sessions: List<WorkoutSession>,
    streak: Int,
    water: Int,
    foods: List<LoggedFood>
  ): List<AchievementBadge> {
    val list = mutableListOf<AchievementBadge>()

    // 1. First Step (WORKOUT)
    val hasCompletedSession = sessions.isNotEmpty()
    list.add(
      AchievementBadge(
        id = "first_step",
        title = "First Step",
        description = "Complete your very first PUMPD pose-detected workout.",
        category = "WORKOUT",
        iconName = "fitness_center",
        unlockCriteria = "Complete 1 workout",
        isUnlocked = hasCompletedSession,
        progress = if (hasCompletedSession) 1.0f else 0.0f,
        currentProgressText = if (hasCompletedSession) "1/1 Workout" else "0/1 Workout"
      )
    )

    // 2. Iron Clad (WORKOUT)
    val sessionCount = sessions.size
    val isIronClad = sessionCount >= 5
    list.add(
      AchievementBadge(
        id = "iron_clad",
        title = "Iron Clad",
        description = "Push your boundaries. Complete 5 workout sessions.",
        category = "WORKOUT",
        iconName = "star",
        unlockCriteria = "Complete 5 workouts",
        isUnlocked = isIronClad,
        progress = (sessionCount / 5f).coerceAtMost(1.0f),
        currentProgressText = "$sessionCount/5 Workouts"
      )
    )

    // 3. Form Master (WORKOUT)
    val hasFormMaster = sessions.any { it.averageFormScore >= 90 }
    val maxFormScore = if (sessions.isNotEmpty()) sessions.maxOf { it.averageFormScore } else 0
    list.add(
      AchievementBadge(
        id = "form_master",
        title = "Form Master",
        description = "Flawless execution. Complete a workout with an average form score of 90% or higher.",
        category = "WORKOUT",
        iconName = "emoji_events",
        unlockCriteria = "Form score >= 90%",
        isUnlocked = hasFormMaster,
        progress = (maxFormScore / 90f).coerceAtMost(1.0f),
        currentProgressText = "Best: $maxFormScore%"
      )
    )

    // 4. Consistent Beast (STREAK)
    val isConsistent = streak >= 3
    list.add(
      AchievementBadge(
        id = "consistent_beast",
        title = "Consistent Beast",
        description = "Maintain a 3-day workout streak.",
        category = "STREAK",
        iconName = "local_fire_department",
        unlockCriteria = "3-day streak",
        isUnlocked = isConsistent,
        progress = (streak / 3f).coerceAtMost(1.0f),
        currentProgressText = "$streak/3 Days"
      )
    )

    // 5. Hydration Hero (HYDRATION)
    val isHydrationHero = water >= 8
    list.add(
      AchievementBadge(
        id = "hydration_hero",
        title = "Hydration Hero",
        description = "Fuel your cells. Drink 8 cups of water today.",
        category = "HYDRATION",
        iconName = "local_drink",
        unlockCriteria = "Drink 8 cups today",
        isUnlocked = isHydrationHero,
        progress = (water / 8f).coerceAtMost(1.0f),
        currentProgressText = "$water/8 Cups"
      )
    )

    // 6. Mindful Eater (NUTRITION)
    val hasLoggedFood = foods.isNotEmpty()
    list.add(
      AchievementBadge(
        id = "mindful_eater",
        title = "Mindful Eater",
        description = "Analyze and track your meals with AI Image Capture.",
        category = "NUTRITION",
        iconName = "restaurant",
        unlockCriteria = "Log 1 meal today",
        isUnlocked = hasLoggedFood,
        progress = if (hasLoggedFood) 1.0f else 0.0f,
        currentProgressText = if (hasLoggedFood) "1/1 Meal" else "0/1 Meal"
      )
    )

    return list
  }


  val userProfile: StateFlow<UserProfile?> = repository.userProfile
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val allSessions: StateFlow<List<WorkoutSession>> = repository.allSessions
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val recentSessions: StateFlow<List<WorkoutSession>> = repository.recentSessions
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val todayStats: StateFlow<DailyStats?> = repository.todayStats
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val recentDailyStats: StateFlow<List<DailyStats>> = repository.recentDailyStats
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val currentStreak: StateFlow<Int> = repository.currentStreak
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

  val allReminders: StateFlow<List<Reminder>> = repository.allReminders
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  fun updateThemePreference(themeMode: String) {
    viewModelScope.launch {
      val current = userProfile.value ?: UserProfile()
      repository.updateProfile(current.copy(darkModePreference = themeMode))
    }
  }

  fun updateFitnessLevel(level: String) {
    viewModelScope.launch {
      val current = userProfile.value ?: UserProfile()
      repository.updateProfile(current.copy(fitnessLevel = level))
    }
  }

  fun updateDailyGoal(goalReps: Int) {
    viewModelScope.launch {
      val current = userProfile.value ?: UserProfile()
      repository.updateProfile(current.copy(dailyGoalReps = goalReps))
    }
  }

  fun toggleAudio(enabled: Boolean) {
    viewModelScope.launch {
      val current = userProfile.value ?: UserProfile()
      repository.updateProfile(current.copy(soundEnabled = enabled))
    }
  }

  fun toggleHaptic(enabled: Boolean) {
    viewModelScope.launch {
      val current = userProfile.value ?: UserProfile()
      repository.updateProfile(current.copy(hapticEnabled = enabled))
    }
  }

  fun toggleMirror(enabled: Boolean) {
    viewModelScope.launch {
      val current = userProfile.value ?: UserProfile()
      repository.updateProfile(current.copy(mirrorCamera = enabled))
    }
  }

  fun addReminder(title: String, hour: Int, minute: Int, days: String) {
    viewModelScope.launch {
      val amPm = if (hour < 12) "AM" else "PM"
      val displayHour = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
      val formatted = String.format(Locale.getDefault(), "%02d:%02d %s", displayHour, minute, amPm)
      repository.addReminder(
        Reminder(
          title = title,
          timeFormatted = formatted,
          hour = hour,
          minute = minute,
          daysOfWeek = days,
          isEnabled = true
        )
      )
    }
  }

  fun toggleReminder(reminder: Reminder) {
    viewModelScope.launch {
      repository.updateReminder(reminder.copy(isEnabled = !reminder.isEnabled))
    }
  }

  fun deleteReminder(id: Long) {
    viewModelScope.launch {
      repository.deleteReminder(id)
    }
  }

  fun testReminderNotification(reminder: Reminder) {
    notificationHelper.showWorkoutReminder(
      title = "Time to Train: ${reminder.title}",
      body = "Keep your streak alive! Tap to open your workout session."
    )
  }

  fun deleteSession(id: Long) {
    viewModelScope.launch {
      repository.deleteSession(id)
    }
  }

  override fun onCleared() {
    super.onCleared()
    notificationHelper.release()
  }
}
