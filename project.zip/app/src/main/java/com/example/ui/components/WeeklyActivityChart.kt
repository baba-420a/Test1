package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.DailyStats
import com.example.ui.theme.BentoIceBlue
import com.example.ui.theme.BentoSlateLight
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush

@Composable
fun WeeklyActivityChart(
  recentStats: List<DailyStats>,
  modifier: Modifier = Modifier
) {
  val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
  val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())

  val statsMap = recentStats.associateBy { it.dateString }

  val daysData = mutableListOf<Triple<String, String, Int>>()
  // Past 7 days
  for (i in 6 downTo 0) {
    val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
    val dateKey = sdf.format(cal.time)
    val dayLabel = dayFormat.format(cal.time).take(1)
    val reps = statsMap[dateKey]?.totalReps ?: 0
    daysData.add(Triple(dateKey, dayLabel, reps))
  }

  val maxReps = (daysData.maxOfOrNull { it.third } ?: 50).coerceAtLeast(30)
  val todayKey = sdf.format(Calendar.getInstance().time)

  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .height(125.dp)
        .padding(horizontal = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.Bottom
    ) {
      daysData.forEach { (dateKey, dayLabel, reps) ->
        val isToday = dateKey == todayKey
        val targetFraction = if (reps > 0) (reps.toFloat() / maxReps).coerceIn(0.18f, 1.0f) else 0.08f
        val animatedHeightFraction by animateFloatAsState(
          targetValue = targetFraction,
          animationSpec = tween(durationMillis = 600),
          label = "barHeight"
        )

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.width(38.dp)
        ) {
          if (reps > 0) {
            Text(
              text = reps.toString(),
              style = MaterialTheme.typography.labelSmall,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = if (isToday) BentoIceBlue else MaterialTheme.colorScheme.onSurfaceVariant
            )
          } else {
            Text(
              text = "—",
              style = MaterialTheme.typography.labelSmall,
              fontSize = 10.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
            )
          }

          Spacer(modifier = Modifier.height(4.dp))

          Box(
            modifier = Modifier
              .width(22.dp)
              .height(76.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
            contentAlignment = Alignment.BottomCenter
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(animatedHeightFraction)
                .clip(RoundedCornerShape(12.dp))
                .background(
                  when {
                    isToday && reps > 0 -> Brush.verticalGradient(
                      listOf(Color(0xFFE2EDFF), BentoIceBlue)
                    )
                    isToday -> Brush.verticalGradient(
                      listOf(BentoIceBlue.copy(alpha = 0.7f), BentoIceBlue.copy(alpha = 0.4f))
                    )
                    reps > 0 -> Brush.verticalGradient(
                      listOf(Color(0xFFBBC7DB), Color(0xFF768396))
                    )
                    else -> Brush.verticalGradient(
                      listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.03f))
                    )
                  }
                )
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = dayLabel,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isToday) FontWeight.Black else FontWeight.Medium,
            color = if (isToday) BentoIceBlue else MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp
          )

          if (isToday) {
            Spacer(modifier = Modifier.height(2.dp))
            Box(
              modifier = Modifier
                .size(4.dp)
                .background(BentoIceBlue, CircleShape)
            )
          } else {
            Spacer(modifier = Modifier.height(6.dp))
          }
        }
      }
    }
  }
}
