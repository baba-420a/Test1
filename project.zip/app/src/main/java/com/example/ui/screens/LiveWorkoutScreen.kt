package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pose.model.ExerciseType
import com.example.pose.model.RepPhase
import com.example.pose.simulation.PoseSimulator
import com.example.pose.ui.SkeletonOverlay
import com.example.ui.components.CircularScoreDial
import com.example.ui.components.ExerciseGuidanceSheet
import com.example.ui.components.StatusBadge
import com.example.ui.components.WorkoutMusicStickyWidget
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EnergyAmber
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PumpdAmber
import com.example.ui.theme.PumpdBorder
import com.example.ui.theme.PumpdBorderLight
import com.example.ui.theme.PumpdCardBg
import com.example.ui.theme.PumpdCardElevated
import com.example.ui.theme.PumpdCrimson
import com.example.ui.theme.PumpdEmerald
import com.example.ui.theme.PumpdObsidian
import com.example.ui.theme.PumpdTextMuted
import com.example.ui.theme.PumpdTextPrimary
import com.example.ui.theme.PumpdTextSecondary
import com.example.ui.theme.PumpdWhite
import com.example.ui.workout.CameraPreviewView
import com.example.ui.workout.ExerciseSet
import com.example.ui.workout.SetKind
import com.example.ui.workout.WorkoutViewModel
import java.util.Locale

@Composable
fun LiveWorkoutScreen(
  viewModel: WorkoutViewModel,
  onNavigateBack: () -> Unit,
  onFinishWorkout: (sessionId: Long) -> Unit,
  modifier: Modifier = Modifier
) {
  val liveState by viewModel.liveState.collectAsStateWithLifecycle()
  val elapsedSeconds by viewModel.elapsedSeconds.collectAsStateWithLifecycle()
  val isPaused by viewModel.isPaused.collectAsStateWithLifecycle()
  val isSimulationMode by viewModel.isSimulationMode.collectAsStateWithLifecycle()
  val isArCameraMode by viewModel.isArCameraMode.collectAsStateWithLifecycle()
  val currentFrame by viewModel.currentFrame.collectAsStateWithLifecycle()
  val cameraLensFacing by viewModel.cameraLensFacing.collectAsStateWithLifecycle()
  val simulationFlaw by viewModel.simulationFlaw.collectAsStateWithLifecycle()

  val sets by viewModel.sets.collectAsStateWithLifecycle()
  val notes by viewModel.notes.collectAsStateWithLifecycle()
  val restSecondsRemaining by viewModel.restSecondsRemaining.collectAsStateWithLifecycle()
  val isRestTimerActive by viewModel.isRestTimerActive.collectAsStateWithLifecycle()
  val isRestTimerPaused by viewModel.isRestTimerPaused.collectAsStateWithLifecycle()

  var showFinishConfirmDialog by remember { mutableStateOf(false) }
  var showGuidanceModal by remember { mutableStateOf(false) }
  var isEditingNotes by remember { mutableStateOf(false) }
  var tempNotes by remember(notes) { mutableStateOf(notes) }

  val minutes = elapsedSeconds / 60
  val seconds = elapsedSeconds % 60
  val formattedTimer = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)

  val completedSetsCount = sets.count { it.isCompleted }
  val progressPercent = if (sets.isNotEmpty()) ((completedSetsCount.toFloat() / sets.size) * 100).toInt() else 0

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PumpdObsidian)
  ) {
    if (isArCameraMode) {
      // -------------------------------------------------------------
      // MODE A: Full-Screen AR Pose & Rep Tracking View
      // -------------------------------------------------------------
      if (!isSimulationMode) {
        CameraPreviewView(
          lensFacing = cameraLensFacing,
          modifier = Modifier.fillMaxSize()
        )
      } else {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.radialGradient(
                colors = listOf(Color(0xFF1E0A12), PumpdObsidian),
                radius = 900f
              )
            )
        )
      }

      SkeletonOverlay(
        poseFrame = currentFrame,
        primaryAngle = liveState.primaryAngle,
        formScore = liveState.liveFormScore,
        isMirrored = cameraLensFacing == androidx.camera.core.CameraSelector.LENS_FACING_FRONT,
        modifier = Modifier.fillMaxSize()
      )

      // Top AR HUD
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 16.dp, vertical = 12.dp)
          .align(Alignment.TopCenter)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(
            onClick = { viewModel.toggleArCameraMode() },
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(PumpdCardElevated.copy(alpha = 0.9f))
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Switch to Set Logger",
              tint = PumpdWhite
            )
          }

          Surface(
            shape = RoundedCornerShape(24.dp),
            color = PumpdCardElevated.copy(alpha = 0.9f),
            border = androidx.compose.foundation.BorderStroke(1.dp, PumpdCrimson.copy(alpha = 0.5f))
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = viewModel.exerciseType.displayName.uppercase(),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Black,
                color = PumpdEmerald,
                letterSpacing = 1.sp
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(text = "·", color = Color.White.copy(alpha = 0.5f))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = formattedTimer,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconButton(
              onClick = { viewModel.toggleSimulationMode(!isSimulationMode) },
              modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(if (isSimulationMode) PumpdCrimson.copy(alpha = 0.4f) else PumpdCardElevated.copy(alpha = 0.9f))
                .border(1.dp, if (isSimulationMode) PumpdCrimson else PumpdBorder, CircleShape)
            ) {
              Icon(
                imageVector = if (isSimulationMode) Icons.Default.SmartToy else Icons.Default.Videocam,
                contentDescription = "Toggle Simulation",
                tint = if (isSimulationMode) PumpdCrimson else PumpdWhite
              )
            }

            if (!isSimulationMode) {
              IconButton(
                onClick = { viewModel.toggleCameraLens() },
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .background(PumpdCardElevated.copy(alpha = 0.9f))
              ) {
                Icon(
                  imageVector = Icons.Default.Cameraswitch,
                  contentDescription = "Switch Camera",
                  tint = PumpdWhite
                )
              }
            }
          }
        }
      }

      // Reps HUD Dial
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = PumpdCardElevated.copy(alpha = 0.9f),
        border = androidx.compose.foundation.BorderStroke(1.dp, PumpdBorder),
        modifier = Modifier
          .align(Alignment.CenterStart)
          .padding(start = 16.dp)
      ) {
        Column(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "REPS",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Black,
            color = PumpdTextMuted,
            letterSpacing = 1.sp
          )
          Text(
            text = "${liveState.correctReps}",
            style = MaterialTheme.typography.displayLarge,
            fontWeight = FontWeight.Black,
            color = PumpdEmerald
          )
          Spacer(modifier = Modifier.height(6.dp))
          CircularScoreDial(score = liveState.liveFormScore, sizeDp = 56, strokeWidthDp = 5)
        }
      }

      // Bottom Control in AR Mode
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .align(Alignment.BottomCenter)
          .navigationBarsPadding()
          .padding(horizontal = 18.dp, vertical = 18.dp)
      ) {
        Button(
          onClick = { viewModel.toggleArCameraMode() },
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp),
          shape = RoundedCornerShape(27.dp),
          colors = ButtonDefaults.buttonColors(containerColor = PumpdWhite, contentColor = Color.Black)
        ) {
          Icon(Icons.Default.FitnessCenter, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Return to Set Logger", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
      }

    } else {
      // -------------------------------------------------------------
      // MODE B: PUMPD Set Logger View (Matching IMG-20260904-WA0002)
      // -------------------------------------------------------------
      Column(
        modifier = Modifier
          .fillMaxSize()
          .statusBarsPadding()
      ) {
        // 1. Top App Bar: Options, Title, Timer/Percent, Finish Button
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Left: Options button
          IconButton(
            onClick = { viewModel.toggleArCameraMode() },
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(PumpdCardBg)
              .border(1.dp, PumpdBorder, CircleShape)
          ) {
            Icon(
              imageVector = Icons.Default.MoreHoriz,
              contentDescription = "Options",
              tint = PumpdTextSecondary,
              modifier = Modifier.size(20.dp)
            )
          }

          // Center: Workout Title & Progress Subtitle
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "Back Day",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Black,
              color = PumpdTextPrimary,
              fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "$formattedTimer • $progressPercent%",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.SemiBold,
              color = PumpdTextMuted,
              fontSize = 11.sp
            )
          }

          // Right: Solid White Circular Flag Button (Finish Workout)
          IconButton(
            onClick = { showFinishConfirmDialog = true },
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(PumpdWhite)
          ) {
            Icon(
              imageVector = Icons.Default.Flag,
              contentDescription = "Finish Workout",
              tint = Color.Black,
              modifier = Modifier.size(18.dp)
            )
          }
        }

        // 2. Segmented Progress Bar across top
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          val segmentCount = (sets.size).coerceAtLeast(3)
          for (i in 0 until segmentCount) {
            val isCompleted = i < completedSetsCount
            val isCurrent = i == completedSetsCount
            Box(
              modifier = Modifier
                .weight(1f)
                .height(3.5.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(
                  when {
                    isCompleted -> PumpdEmerald
                    isCurrent -> PumpdCrimson
                    else -> Color.White.copy(alpha = 0.15f)
                  }
                )
            )
          }
        }

        // 3. Scrollable Exercise & Set Content
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .padding(bottom = if (isRestTimerActive) 100.dp else 24.dp)
        ) {
          // Dynamic Music Deck Controller
          WorkoutMusicStickyWidget(
            modifier = Modifier.padding(bottom = 14.dp)
          )

          // Section header: ⚡ CURRENT
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(vertical = 6.dp)
          ) {
            Text(
              text = "⚡ CURRENT",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Black,
              color = PumpdCrimson,
              letterSpacing = 1.sp,
              fontSize = 11.sp
            )
          }

          // Primary Exercise Card (Matching IMG-20260904-WA0002)
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = PumpdCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, PumpdBorder)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              // Header: Icon + Title + Muscles + Menu
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                  // Exercise Avatar with status dot
                  Box(modifier = Modifier.size(44.dp)) {
                    Box(
                      modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(PumpdCardElevated),
                      contentAlignment = Alignment.Center
                    ) {
                      Icon(
                        imageVector = Icons.Default.FitnessCenter,
                        contentDescription = null,
                        tint = PumpdWhite,
                        modifier = Modifier.size(22.dp)
                      )
                    }
                    Box(
                      modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(PumpdAmber)
                        .border(1.5.dp, PumpdCardBg, CircleShape)
                        .align(Alignment.TopEnd)
                    )
                  }

                  Column {
                    Text(
                      text = viewModel.exerciseType.displayName,
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Black,
                      color = PumpdTextPrimary,
                      fontSize = 16.sp
                    )
                    Text(
                      text = when (viewModel.exerciseType) {
                        ExerciseType.SQUATS -> "Quadriceps, Glutes, Hamstrings"
                        ExerciseType.PUSHUPS -> "Chest, Shoulders, Triceps"
                        ExerciseType.BICEP_CURLS -> "Biceps, Forearms"
                      },
                      style = MaterialTheme.typography.bodySmall,
                      color = PumpdTextMuted,
                      fontSize = 11.sp
                    )
                  }
                }

                IconButton(onClick = { showGuidanceModal = true }) {
                  Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options",
                    tint = PumpdTextMuted
                  )
                }
              }

              Spacer(modifier = Modifier.height(14.dp))

              // Notes row with pencil icon
              Surface(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .clickable { isEditingNotes = !isEditingNotes },
                color = PumpdCardElevated,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, PumpdBorder)
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = null,
                    tint = PumpdTextMuted,
                    modifier = Modifier.size(14.dp)
                  )
                  Text(
                    text = notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = PumpdTextSecondary,
                    fontSize = 11.sp,
                    maxLines = if (isEditingNotes) 3 else 1
                  )
                }
              }

              Spacer(modifier = Modifier.height(16.dp))

              // Set Table Header: SET | KG ↗ | REPS ↘ | RPE | ✓
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "SET",
                  style = MaterialTheme.typography.labelSmall,
                  color = PumpdTextMuted,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.weight(1.3f)
                )
                Row(modifier = Modifier.weight(1.2f), verticalAlignment = Alignment.CenterVertically) {
                  Text(text = "KG", style = MaterialTheme.typography.labelSmall, color = PumpdTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = PumpdEmerald, modifier = Modifier.size(10.dp))
                }
                Row(modifier = Modifier.weight(1.2f), verticalAlignment = Alignment.CenterVertically) {
                  Text(text = "REPS", style = MaterialTheme.typography.labelSmall, color = PumpdTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = PumpdCrimson, modifier = Modifier.size(10.dp))
                }
                Text(
                  text = "RPE",
                  style = MaterialTheme.typography.labelSmall,
                  color = PumpdTextMuted,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.weight(1f)
                )
                Box(modifier = Modifier.width(36.dp), contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Check, contentDescription = null, tint = PumpdTextMuted, modifier = Modifier.size(14.dp))
                }
              }

              // Set Rows
              Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                sets.forEach { setItem ->
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(12.dp))
                      .background(if (setItem.isCompleted) Color(0xFF1B2321) else PumpdCardElevated)
                      .border(
                        0.5.dp,
                        if (setItem.isCompleted) PumpdEmerald.copy(alpha = 0.3f) else PumpdBorder,
                        RoundedCornerShape(12.dp)
                      )
                      .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    // Set Kind Pill
                    Row(
                      modifier = Modifier.weight(1.3f),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(
                        text = "${setItem.setNumber} ",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black,
                        color = PumpdTextPrimary
                      )
                      Text(
                        text = setItem.kind.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (setItem.kind) {
                          SetKind.WARMUP -> PumpdAmber
                          SetKind.WORKING -> PumpdEmerald
                          SetKind.DROPSET -> PumpdCrimson
                        },
                        fontSize = 10.sp
                      )
                    }

                    // Weight stepper
                    Row(
                      modifier = Modifier
                        .weight(1.2f)
                        .clickable { viewModel.updateSetWeight(setItem.id, 2.5f) },
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(
                        text = "${setItem.weightKg.toInt()}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = PumpdTextPrimary
                      )
                    }

                    // Reps stepper
                    Row(
                      modifier = Modifier
                        .weight(1.2f)
                        .clickable { viewModel.updateSetReps(setItem.id, 1) },
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(
                        text = "${setItem.reps}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = PumpdTextPrimary
                      )
                    }

                    // RPE
                    Text(
                      text = "${setItem.rpe}",
                      style = MaterialTheme.typography.labelMedium,
                      fontWeight = FontWeight.SemiBold,
                      color = PumpdTextSecondary,
                      modifier = Modifier.weight(1f)
                    )

                    // Checkmark Toggle Button (White pill when completed, dark pill when pending)
                    Box(
                      modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(if (setItem.isCompleted) PumpdWhite else Color(0xFF22242E))
                        .border(1.dp, if (setItem.isCompleted) PumpdWhite else PumpdBorderLight, CircleShape)
                        .clickable { viewModel.toggleSetCompleted(setItem.id) },
                      contentAlignment = Alignment.Center
                    ) {
                      if (setItem.isCompleted) {
                        Icon(
                          imageVector = Icons.Default.Check,
                          contentDescription = "Completed",
                          tint = Color.Black,
                          modifier = Modifier.size(18.dp)
                        )
                      }
                    }
                  }
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Add Set Button
              Button(
                onClick = { viewModel.addSet() },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(42.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = Color.White.copy(alpha = 0.08f),
                  contentColor = PumpdWhite
                )
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("+ Add Set", fontWeight = FontWeight.Bold, fontSize = 12.sp)
              }

              Spacer(modifier = Modifier.height(14.dp))

              // AI Camera Guidance & AR Pose Toggle Button
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(14.dp))
                  .background(PumpdCrimson.copy(alpha = 0.12f))
                  .border(1.dp, PumpdCrimson.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                  .clickable { showGuidanceModal = true }
                  .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                  Box(
                    modifier = Modifier
                      .size(8.dp)
                      .clip(CircleShape)
                      .background(PumpdEmerald)
                  )
                  Column {
                    Text(
                      text = "Live AI Form Guidance",
                      style = MaterialTheme.typography.labelMedium,
                      fontWeight = FontWeight.Black,
                      color = PumpdWhite
                    )
                    Text(
                      text = "Tap to inspect execution cues & AR pose PIP",
                      style = MaterialTheme.typography.bodySmall,
                      color = PumpdTextMuted,
                      fontSize = 10.sp
                    )
                  }
                }

                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(PumpdWhite)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                  Text(
                    text = "CHECK",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = Color.Black,
                    fontSize = 10.sp
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Next Exercise Preview Card (Matching IMG-20260904-WA0002)
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = PumpdCardBg.copy(alpha = 0.6f)),
            border = androidx.compose.foundation.BorderStroke(0.8.dp, PumpdBorder)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
              ) {
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PumpdCardElevated),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.FitnessCenter,
                    contentDescription = null,
                    tint = PumpdTextMuted,
                    modifier = Modifier.size(20.dp)
                  )
                }

                Column {
                  Text(
                    text = "Next: Lat Pulldown",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = PumpdTextSecondary
                  )
                  Text(
                    text = "3 sets • 8-12 reps",
                    style = MaterialTheme.typography.bodySmall,
                    color = PumpdTextMuted,
                    fontSize = 11.sp
                  )
                }
              }

              Icon(
                imageVector = Icons.Default.ExpandLess,
                contentDescription = null,
                tint = PumpdTextMuted,
                modifier = Modifier.size(20.dp)
              )
            }
          }
        }
      }

      // 4. Floating Rest Timer Dock (Matching IMG-20260904-WA0002)
      AnimatedVisibility(
        visible = isRestTimerActive && restSecondsRemaining > 0,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 14.dp)
      ) {
        val restMin = restSecondsRemaining / 60
        val restSec = restSecondsRemaining % 60
        val formattedRest = String.format(Locale.getDefault(), "%d:%02d", restMin, restSec)

        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .height(58.dp),
          shape = RoundedCornerShape(29.dp),
          color = Color(0xFF13151D),
          border = androidx.compose.foundation.BorderStroke(1.dp, PumpdBorderLight),
          shadowElevation = 16.dp
        ) {
          Row(
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Skip Rest Button
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.1f))
                .clickable { viewModel.skipRest() }
                .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
              Text(
                text = "Skip Rest",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = PumpdTextPrimary,
                fontSize = 11.sp
              )
            }

            // Countdown Timer +15 sec pill
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Text(
                text = formattedRest,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = PumpdWhite,
                fontSize = 18.sp
              )

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .background(Color.White.copy(alpha = 0.12f))
                  .clickable { viewModel.addRestTime(15) }
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(
                  text = "+15 sec",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = PumpdTextSecondary,
                  fontSize = 10.sp
                )
              }
            }

            // Pause and Expand Actions
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              IconButton(
                onClick = { viewModel.toggleRestTimerPause() },
                modifier = Modifier.size(34.dp)
              ) {
                Icon(
                  imageVector = if (isRestTimerPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                  contentDescription = "Pause Rest",
                  tint = PumpdWhite,
                  modifier = Modifier.size(18.dp)
                )
              }

              IconButton(
                onClick = { viewModel.skipRest() },
                modifier = Modifier.size(34.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.ExpandLess,
                  contentDescription = "Collapse",
                  tint = PumpdTextMuted,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }
        }
      }
    }
  }

  // Live AI Form Guidance Modal (Matching IMG-20260904-WA0000 & WA0004)
  if (showGuidanceModal) {
    ExerciseGuidanceSheet(
      exercise = viewModel.exerciseType,
      onDismiss = { showGuidanceModal = false },
      onStartWorkout = { showGuidanceModal = false }
    )
  }

  // Confirm Finish Dialog
  if (showFinishConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showFinishConfirmDialog = false },
      containerColor = PumpdCardBg,
      title = {
        Text(
          text = "Complete Workout?",
          fontWeight = FontWeight.Black,
          color = PumpdWhite
        )
      },
      text = {
        Text(
          text = "You logged $completedSetsCount sets with ${liveState.correctReps} tracked reps. Ready to view your performance summary?",
          color = PumpdTextSecondary
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showFinishConfirmDialog = false
            viewModel.finishWorkout { sessionId ->
              onFinishWorkout(sessionId)
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = PumpdWhite, contentColor = Color.Black),
          shape = RoundedCornerShape(16.dp)
        ) {
          Text("Save & Summary", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showFinishConfirmDialog = false }) {
          Text("Keep Going", color = PumpdTextMuted)
        }
      }
    )
  }
}
