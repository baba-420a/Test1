package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.WorkoutSession
import com.example.pose.model.ExerciseType
import com.example.ui.FitnessViewModel
import com.example.ui.components.BentoActionCard
import com.example.ui.components.BentoHeroCard
import com.example.ui.components.BentoSplitCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.StylizedCard
import com.example.ui.components.WeeklyActivityChart
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.BentoBlushDark
import com.example.ui.theme.BentoBlushPink
import com.example.ui.theme.BentoDarkBackground
import com.example.ui.theme.BentoDarkBorder
import com.example.ui.theme.BentoGraphite
import com.example.ui.theme.BentoIceBlue
import com.example.ui.theme.BentoIceBlueDark
import com.example.ui.theme.BentoSageDark
import com.example.ui.theme.BentoSageGreen
import com.example.ui.theme.BentoSlateBlue
import com.example.ui.theme.BentoSlateLight
import com.example.ui.theme.BentoTextMuted
import com.example.ui.theme.BentoTextPrimary
import com.example.ui.theme.BentoTextSecondary
import com.example.ui.theme.EnergyAmber
import com.example.ui.theme.StreakFire
import com.example.ui.theme.NeonLime
import com.example.ui.theme.ElectricCyan
import com.example.ui.components.WorkoutMusicStickyWidget
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
  viewModel: FitnessViewModel,
  onStartWorkout: (ExerciseType) -> Unit,
  onNavigateToHistory: () -> Unit,
  onNavigateToReminders: () -> Unit,
  onNavigateToExercises: () -> Unit,
  onNavigateToSettings: () -> Unit,
  modifier: Modifier = Modifier
) {
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val todayStats by viewModel.todayStats.collectAsStateWithLifecycle()
  val recentDailyStats by viewModel.recentDailyStats.collectAsStateWithLifecycle()
  val streak by viewModel.currentStreak.collectAsStateWithLifecycle()
  val recentSessions by viewModel.recentSessions.collectAsStateWithLifecycle()
  val reminders by viewModel.allReminders.collectAsStateWithLifecycle()
  val waterCups by viewModel.waterCups.collectAsStateWithLifecycle()
  val loggedFoods by viewModel.loggedFoods.collectAsStateWithLifecycle()
  var showFoodScannerDialog by remember { mutableStateOf(false) }

  val dailyGoal = userProfile?.dailyGoalReps ?: 50
  val todayReps = todayStats?.totalReps ?: 0
  val progressFraction = (todayReps.toFloat() / dailyGoal).coerceIn(0f, 1f)
  val todayCalories = todayStats?.estimatedCalories ?: 0.0
  val activeMinutes = todayStats?.activeMinutes ?: 0
  val averageScore = if (recentSessions.isNotEmpty()) {
    recentSessions.take(5).map { it.averageFormScore }.average().toInt()
  } else {
    84
  }

  val isDark = userProfile?.darkModePreference != "LIGHT"

  // Formatted date string matching Bento design header: e.g. "TUESDAY, OCT 24"
  val dateFormat = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())
  val todayDateString = dateFormat.format(Date()).uppercase()

  // Initials for avatar
  val initials = userProfile?.name?.split(" ")?.mapNotNull { it.firstOrNull()?.toString() }?.take(2)?.joinToString("") ?: "JD"

  val currentSegment = (progressFraction * 4).toInt().coerceIn(0, 4)

  var selectedExerciseForGuidance by remember { mutableStateOf<ExerciseType?>(null) }

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(horizontal = 18.dp),
      contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 1. Bento Header
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = todayDateString,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = BentoTextSecondary,
              letterSpacing = 1.2.sp,
              fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "PUMPD AI Coach",
              style = MaterialTheme.typography.headlineMedium,
              fontWeight = FontWeight.Black,
              color = MaterialTheme.colorScheme.onBackground,
              letterSpacing = (-0.5).sp
            )
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Streak Chip
            Surface(
              shape = RoundedCornerShape(18.dp),
              color = BentoGraphite,
              border = androidx.compose.foundation.BorderStroke(1.dp, BentoDarkBorder)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = Icons.Default.LocalFireDepartment,
                  contentDescription = "Streak",
                  tint = StreakFire,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "${streak}D",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = BentoTextPrimary
                )
              }
            }

            // Dark/Light Theme Toggle
            IconButton(
              onClick = {
                val newPref = if (isDark) "LIGHT" else "DARK"
                viewModel.updateThemePreference(newPref)
              },
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(BentoGraphite)
                .border(1.dp, BentoDarkBorder, CircleShape)
                .testTag("theme_toggle_button")
            ) {
              Icon(
                imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                contentDescription = "Toggle Theme",
                tint = if (isDark) EnergyAmber else BentoIceBlue,
                modifier = Modifier.size(20.dp)
              )
            }

            // User Profile Avatar with Bento Ice Blue border
            Box(
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(BentoGraphite)
                .border(2.dp, BentoIceBlue, CircleShape)
                .clickable { onNavigateToSettings() },
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = initials,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = BentoTextPrimary,
                fontSize = 14.sp
              )
            }
          }
        }
      }

      // 2. Featured PUMPD Hero Card (Matching IMG-20260904-WA0001 & WA0005)
      item {
        com.example.ui.components.PumpdWelcomeHeroCard(
          onStartWorkout = { onStartWorkout(ExerciseType.SQUATS) },
          onOpenGuidance = { selectedExerciseForGuidance = ExerciseType.SQUATS }
        )
      }

      // 3. Bento Hero Card: Energy & Form Score (#d1e4ff)
      item {
        BentoHeroCard(
          title = "Energy & Form Score",
          scoreValue = averageScore.toString(),
          statusBadgeText = if (todayReps >= dailyGoal) "Goal Met" else if (averageScore >= 80) "Optimal" else "Good Progress",
          currentSegment = currentSegment,
          totalSegments = 4,
          metricSubtext = "$todayReps of $dailyGoal reps",
          onClick = { onNavigateToExercises() }
        )
      }

    // 3. Bento 2-Column Split: Slate Blue (#33485d) and Graphite (#44474e)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Left Bento Cell: Reps / Steps style
        BentoSplitCard(
          title = "Today's Reps",
          value = "$todayReps",
          containerColor = BentoSlateBlue,
          iconContainerColor = BentoSlateLight,
          iconColor = BentoDarkBackground,
          icon = Icons.Default.FitnessCenter,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToExercises() }
        )

        // Right Bento Cell: Restorative / Active duration
        BentoSplitCard(
          title = "Active Minutes",
          value = if (activeMinutes > 0) "${activeMinutes}m" else "${todayCalories.toInt()} kcal",
          containerColor = BentoGraphite,
          iconContainerColor = BentoIceBlue,
          iconColor = BentoIceBlueDark,
          icon = Icons.Default.Timer,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToHistory() }
        )
      }
    }

    // 4. Bento Next Session / Training Reminder Card (#1c1b1f with #efb8c8 blush chip)
    item {
      val activeReminder = reminders.firstOrNull { it.isEnabled }
      BentoActionCard(
        badgeText = "Next Session",
        title = if (activeReminder != null) activeReminder.title else "Squat & Core Training",
        subtitle = if (activeReminder != null) "Scheduled for ${activeReminder.timeFormatted}" else "Starts in 15 mins",
        accentColor = BentoBlushPink,
        accentDarkColor = BentoBlushDark,
        icon = Icons.Default.Alarm,
        onClick = { onNavigateToReminders() }
      )
    }

    // 4b. Bento Row for Water Tracker and Food Calories Calculator (AI Vision)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Hydration Card with quick buttons
        StylizedCard(
          containerColor = BentoSlateBlue,
          borderColor = BentoDarkBorder,
          modifier = Modifier.weight(1f)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "HYDRATION",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = ElectricCyan,
                letterSpacing = 0.5.sp
              )
              Icon(
                imageVector = Icons.Default.LocalDrink,
                contentDescription = null,
                tint = ElectricCyan,
                modifier = Modifier.size(16.dp)
              )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "$waterCups / 8 cups",
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Black,
              color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Goal: 8 cups today",
              style = MaterialTheme.typography.labelSmall,
              color = BentoTextSecondary,
              fontSize = 10.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              IconButton(
                onClick = { viewModel.removeWaterCup() },
                modifier = Modifier
                  .weight(1f)
                  .height(32.dp)
                  .background(Color(0xFF14161F), RoundedCornerShape(8.dp))
                  .border(1.dp, Color(0xFF262938), RoundedCornerShape(8.dp))
              ) {
                Icon(
                  imageVector = Icons.Default.Remove,
                  contentDescription = "Remove cup",
                  tint = Color.White,
                  modifier = Modifier.size(14.dp)
                )
              }
              IconButton(
                onClick = { viewModel.addWaterCup() },
                modifier = Modifier
                  .weight(1f)
                  .height(32.dp)
                  .background(ElectricCyan, RoundedCornerShape(8.dp))
              ) {
                Icon(
                  imageVector = Icons.Default.Add,
                  contentDescription = "Add cup",
                  tint = Color.Black,
                  modifier = Modifier.size(14.dp)
                )
              }
            }
          }
        }

        // AI Nutrition Vision Card
        val foodCalories = loggedFoods.sumOf { it.calories }
        StylizedCard(
          containerColor = BentoGraphite,
          borderColor = BentoDarkBorder,
          modifier = Modifier.weight(1f),
          onClick = { showFoodScannerDialog = true }
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "AI NUTRITION",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = NeonLime,
                letterSpacing = 0.5.sp
              )
              Icon(
                imageVector = Icons.Default.CameraAlt,
                contentDescription = null,
                tint = NeonLime,
                modifier = Modifier.size(16.dp)
              )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "$foodCalories kcal",
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Black,
              color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "${loggedFoods.size} logged items",
              style = MaterialTheme.typography.labelSmall,
              color = BentoTextSecondary,
              fontSize = 10.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(32.dp)
                .background(NeonLime.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                .border(1.dp, NeonLime.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "SCAN MEAL",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Black,
                color = NeonLime,
                fontSize = 10.sp
              )
            }
          }
        }
      }
    }

    // Music Training Deck Widget
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Text(
          text = "GYM PLAYLIST",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Black,
          color = ElectricCyan,
          letterSpacing = 1.sp,
          modifier = Modifier.padding(start = 4.dp, end = 4.dp, bottom = 8.dp)
        )
        WorkoutMusicStickyWidget()
      }
    }

    // 5. Section: Workout Modules
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Training Modules",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onBackground,
          letterSpacing = (-0.2).sp
        )
        Text(
          text = "All Exercises →",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = BentoIceBlue,
          letterSpacing = 0.5.sp,
          modifier = Modifier.clickable { onNavigateToExercises() }
        )
      }
    }

    // Bento Exercise Cards
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        BentoExerciseCard(
          exercise = ExerciseType.SQUATS,
          chipColor = BentoIceBlue,
          chipDarkColor = BentoIceBlueDark,
          onStart = { onStartWorkout(ExerciseType.SQUATS) }
        )
        BentoExerciseCard(
          exercise = ExerciseType.PUSHUPS,
          chipColor = BentoBlushPink,
          chipDarkColor = BentoBlushDark,
          onStart = { onStartWorkout(ExerciseType.PUSHUPS) }
        )
        BentoExerciseCard(
          exercise = ExerciseType.BICEP_CURLS,
          chipColor = BentoSageGreen,
          chipDarkColor = BentoSageDark,
          onStart = { onStartWorkout(ExerciseType.BICEP_CURLS) }
        )
      }
    }

    // 6. Bento Weekly Activity Card
    item {
      StylizedCard(containerColor = MaterialTheme.colorScheme.surface) {
        Column(modifier = Modifier.padding(20.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "WEEKLY REPS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = BentoTextSecondary,
                letterSpacing = 1.sp,
                fontSize = 10.sp
              )
              Text(
                text = "7-Day Performance",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BentoTextPrimary
              )
            }
            Text(
              text = "Log →",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = BentoIceBlue,
              modifier = Modifier.clickable { onNavigateToHistory() }
            )
          }

          Spacer(modifier = Modifier.height(16.dp))
          WeeklyActivityChart(recentStats = recentDailyStats)
        }
      }
    }

    // 7. Recent Sessions
    if (recentSessions.isNotEmpty()) {
      item {
        Text(
          text = "Recent Activity",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onBackground,
          modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
      }

      items(recentSessions.take(3)) { session ->
        BentoHistoryCard(session = session)
      }
    }
  }

    // Live Exercise Guidance Sheet (Matching IMG-20260904-WA0000 & WA0004)
    val guidanceEx = selectedExerciseForGuidance
    if (guidanceEx != null) {
      com.example.ui.components.ExerciseGuidanceSheet(
        exercise = guidanceEx,
        onDismiss = { selectedExerciseForGuidance = null },
        onStartWorkout = {
          selectedExerciseForGuidance = null
          onStartWorkout(guidanceEx)
        }
      )
    }

    if (showFoodScannerDialog) {
      com.example.ui.components.FoodScannerDialog(
        viewModel = viewModel,
        onDismiss = { showFoodScannerDialog = false }
      )
    }
  }
}

@Composable
fun BentoExerciseCard(
  exercise: ExerciseType,
  chipColor: Color,
  chipDarkColor: Color,
  onStart: () -> Unit
) {
  val calorieRate = when (exercise) {
    ExerciseType.SQUATS -> "~10-12 kcal/min"
    ExerciseType.PUSHUPS -> "~8-10 kcal/min"
    ExerciseType.BICEP_CURLS -> "~6-8 kcal/min"
  }

  StylizedCard(
    containerColor = MaterialTheme.colorScheme.surface,
    borderColor = BentoDarkBorder,
    onClick = onStart
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(chipColor),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.FitnessCenter,
            contentDescription = null,
            tint = chipDarkColor,
            modifier = Modifier.size(24.dp)
          )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = exercise.displayName,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = BentoTextPrimary
            )
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = chipColor.copy(alpha = 0.2f)
            ) {
              Text(
                text = exercise.difficulty.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = chipColor,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "${exercise.targetMuscles} · $calorieRate",
            style = MaterialTheme.typography.bodySmall,
            color = BentoTextSecondary,
            fontSize = 12.sp
          )
        }
      }

      Button(
        onClick = onStart,
        shape = RoundedCornerShape(20.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = chipColor,
          contentColor = chipDarkColor
        ),
        modifier = Modifier
          .height(44.dp)
          .testTag("start_${exercise.name.lowercase()}")
      ) {
        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "START", fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 0.5.sp)
      }
    }
  }
}

@Composable
fun BentoHistoryCard(
  session: WorkoutSession
) {
  val sdf = SimpleDateFormat("MMM dd · hh:mm a", Locale.getDefault())
  val formattedDate = sdf.format(Date(session.startTime))
  val durationMin = session.durationSeconds / 60
  val durationSec = session.durationSeconds % 60

  StylizedCard(
    containerColor = MaterialTheme.colorScheme.surface,
    borderColor = BentoDarkBorder
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column {
        Text(
          text = session.exerciseName,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.SemiBold,
          color = BentoTextPrimary
        )
        Text(
          text = formattedDate,
          style = MaterialTheme.typography.bodySmall,
          color = BentoTextSecondary,
          fontSize = 12.sp
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "${session.correctReps} reps",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = BentoIceBlue
          )
          Text(
            text = "${String.format(Locale.getDefault(), "%02d:%02d", durationMin, durationSec)} · ${session.estimatedCalories.toInt()} kcal",
            style = MaterialTheme.typography.labelSmall,
            color = BentoTextMuted,
            fontSize = 10.sp
          )
        }

        Surface(
          shape = RoundedCornerShape(12.dp),
          color = BentoGraphite,
          border = androidx.compose.foundation.BorderStroke(1.dp, BentoDarkBorder)
        ) {
          Text(
            text = "${session.averageFormScore}%",
            color = BentoIceBlue,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }
    }
  }
}
