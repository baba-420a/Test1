package com.example.ui.components

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow

data class WorkoutTrack(
  val title: String,
  val artist: String,
  val genre: String,
  val streamUrl: String,
  val duration: String
)

// List of actual curated public high-energy streams and royalty-free training tracks
val WORKOUT_TRACKS = listOf(
  WorkoutTrack(
    title = "Hyper-Drive Cyber Synth",
    artist = "PUMPD Beats System",
    genre = "SYNTHWAVE",
    streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    duration = "6:12"
  ),
  WorkoutTrack(
    title = "Titanium Shred Factor",
    artist = "Heavy Metal Core",
    genre = "HEAVY ROCK",
    streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    duration = "7:05"
  ),
  WorkoutTrack(
    title = "Liquid Electron Power",
    artist = "EDM Club Training",
    genre = "UPBEAT EDM",
    streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    duration = "5:44"
  ),
  WorkoutTrack(
    title = "Apex Intensity Flow",
    artist = "High Tempo Electro",
    genre = "HARDCORE ELECTRO",
    streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
    duration = "5:02"
  ),
  WorkoutTrack(
    title = "Deep Focus Iron Beats",
    artist = "Lofi Chill-Hop Base",
    genre = "LO-FI FOCUS",
    streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
    duration = "5:38"
  )
)

object WorkoutMusicManager {
  private var mediaPlayer: MediaPlayer? = null
  
  val currentTrackIndex = MutableStateFlow(0)
  val isPlaying = MutableStateFlow(false)
  val isLoading = MutableStateFlow(false)
  val progress = MutableStateFlow(0f) // 0.0 to 1.0
  val currentDurationText = MutableStateFlow("00:00")
  val isPlayerVisible = MutableStateFlow(false)
  val isSimulatedMode = MutableStateFlow(false)

  private val handler = Handler(Looper.getMainLooper())
  private val updateProgressRunnable = object : Runnable {
    override fun run() {
      if (isSimulatedMode.value) {
        if (isPlaying.value) {
          val nextProgress = progress.value + 0.005f
          if (nextProgress >= 1f) {
            progress.value = 0f
            currentDurationText.value = "00:00"
            val nextIdx = (currentTrackIndex.value + 1) % WORKOUT_TRACKS.size
            currentTrackIndex.value = nextIdx
          } else {
            progress.value = nextProgress
            val totalSecs = 300
            val currentSecs = (totalSecs * nextProgress).toInt()
            val mins = currentSecs / 60
            val secs = currentSecs % 60
            currentDurationText.value = String.format("%02d:%02d", mins, secs)
          }
        }
      } else {
        mediaPlayer?.let { player ->
          if (player.isPlaying && player.duration > 0) {
            val curr = player.currentPosition.toFloat()
            val total = player.duration.toFloat()
            progress.value = (curr / total).coerceIn(0f, 1f)
            
            val mins = (player.currentPosition / 1000) / 60
            val secs = (player.currentPosition / 1000) % 60
            currentDurationText.value = String.format("%02d:%02d", mins, secs)
          }
        }
      }
      handler.postDelayed(this, 1000)
    }
  }

  fun playTrack(context: Context, index: Int) {
    if (index !in WORKOUT_TRACKS.indices) return
    currentTrackIndex.value = index
    isLoading.value = true
    isPlaying.value = false
    progress.value = 0f
    currentDurationText.value = "00:00"

    try {
      mediaPlayer?.stop()
      mediaPlayer?.release()
    } catch (e: Exception) {
      // Ignore
    }

    mediaPlayer = MediaPlayer().apply {
      setAudioAttributes(
        AudioAttributes.Builder()
          .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
          .setUsage(AudioAttributes.USAGE_MEDIA)
          .build()
      )
      setDataSource(WORKOUT_TRACKS[index].streamUrl)
      setOnPreparedListener { player ->
        WorkoutMusicManager.isSimulatedMode.value = false
        WorkoutMusicManager.isLoading.value = false
        player.start()
        WorkoutMusicManager.isPlaying.value = true
        handler.removeCallbacks(updateProgressRunnable)
        handler.post(updateProgressRunnable)
      }
      setOnCompletionListener {
        nextTrack(context)
      }
      setOnErrorListener { _, _, _ ->
        // Graceful automatic offline simulation mode fallback
        WorkoutMusicManager.isSimulatedMode.value = true
        WorkoutMusicManager.isLoading.value = false
        WorkoutMusicManager.isPlaying.value = true
        handler.removeCallbacks(updateProgressRunnable)
        handler.post(updateProgressRunnable)
        true
      }
      prepareAsync()
    }
  }

  fun togglePlayPause(context: Context) {
    if (isSimulatedMode.value) {
      isPlaying.value = !isPlaying.value
      return
    }
    val player = mediaPlayer
    if (player != null) {
      if (player.isPlaying) {
        player.pause()
        isPlaying.value = false
      } else {
        player.start()
        isPlaying.value = true
      }
    } else {
      playTrack(context, currentTrackIndex.value)
    }
  }

  fun nextTrack(context: Context) {
    val nextIdx = (currentTrackIndex.value + 1) % WORKOUT_TRACKS.size
    playTrack(context, nextIdx)
  }

  fun previousTrack(context: Context) {
    var prevIdx = currentTrackIndex.value - 1
    if (prevIdx < 0) prevIdx = WORKOUT_TRACKS.size - 1
    playTrack(context, prevIdx)
  }

  fun seekTo(positionPercent: Float) {
    mediaPlayer?.let { player ->
      val targetMs = (player.duration * positionPercent).toInt()
      player.seekTo(targetMs)
    }
  }

  fun release() {
    handler.removeCallbacks(updateProgressRunnable)
    try {
      mediaPlayer?.stop()
      mediaPlayer?.release()
    } catch (e: Exception) {
      // Ignore
    }
    mediaPlayer = null
    isPlaying.value = false
    isLoading.value = false
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutMusicPlayerDialog(
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val activeTrackIndex by WorkoutMusicManager.currentTrackIndex.collectAsState()
  val isPlaying by WorkoutMusicManager.isPlaying.collectAsState()
  val isLoading by WorkoutMusicManager.isLoading.collectAsState()
  val playbackProgress by WorkoutMusicManager.progress.collectAsState()
  val currentTimeText by WorkoutMusicManager.currentDurationText.collectAsState()

  val currentTrack = WORKOUT_TRACKS[activeTrackIndex]

  // Animated bars for high-tech equalizer visualizer
  val animatedBarCount = 8
  val coroutineScope = rememberCoroutineScope()
  val heights = remember { mutableStateListOf(*Array(animatedBarCount) { 4f }) }

  LaunchedEffect(isPlaying) {
    if (isPlaying) {
      while (true) {
        for (i in 0 until animatedBarCount) {
          heights[i] = kotlin.random.Random.Default.nextInt(10, 45).toFloat()
        }
        delay(120)
      }
    } else {
      for (i in 0 until animatedBarCount) {
        heights[i] = 4f
      }
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      topBar = {
        TopAppBar(
          title = {
            Text(
              "WORKOUT MUSIC DECK",
              fontWeight = FontWeight.Black,
              fontSize = 14.sp,
              letterSpacing = 1.2.sp,
              color = Color.White
            )
          },
          navigationIcon = {
            IconButton(onClick = onDismiss) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color(0xFF0C0D11)
          )
        )
      },
      containerColor = Color(0xFF0C0D11)
    ) { paddingValues ->
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // 1. Interactive Audio Deck Card
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF14161F)),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF262938))
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            // Neon genre tag
            Box(
              modifier = Modifier
                .background(NeonLime.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                .border(1.dp, NeonLime.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Text(
                text = currentTrack.genre,
                style = MaterialTheme.typography.labelSmall,
                color = NeonLime,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
              )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Simulated Track Visualizer Disk & Equalizer
            Row(
              modifier = Modifier
                .height(55.dp)
                .fillMaxWidth(),
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.Bottom
            ) {
              heights.forEach { h ->
                Box(
                  modifier = Modifier
                    .padding(horizontal = 3.dp)
                    .width(6.dp)
                    .height(h.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(
                      Brush.verticalGradient(
                        colors = listOf(NeonLime, ElectricCyan)
                      )
                    )
                )
              }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Track details
            Text(
              text = currentTrack.title,
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Black,
              color = Color.White,
              textAlign = TextAlign.Center,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = currentTrack.artist,
              style = MaterialTheme.typography.bodyMedium,
              color = BentoTextSecondary,
              textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Playback duration slider
            Slider(
              value = playbackProgress,
              onValueChange = { WorkoutMusicManager.seekTo(it) },
              colors = SliderDefaults.colors(
                thumbColor = NeonLime,
                activeTrackColor = NeonLime,
                inactiveTrackColor = Color(0xFF222636)
              ),
              modifier = Modifier.fillMaxWidth()
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = currentTimeText,
                style = MaterialTheme.typography.labelSmall,
                color = BentoTextSecondary
              )
              Text(
                text = currentTrack.duration,
                style = MaterialTheme.typography.labelSmall,
                color = BentoTextSecondary
              )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Transport Control Buttons
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically
            ) {
              IconButton(
                onClick = { WorkoutMusicManager.previousTrack(context) },
                modifier = Modifier.size(48.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.SkipPrevious,
                  contentDescription = "Previous",
                  tint = Color.White,
                  modifier = Modifier.size(28.dp)
                )
              }

              Spacer(modifier = Modifier.width(16.dp))

              Box(
                modifier = Modifier
                  .size(64.dp)
                  .clip(CircleShape)
                  .background(NeonLime)
                  .clickable {
                    WorkoutMusicManager.togglePlayPause(context)
                  },
                contentAlignment = Alignment.Center
              ) {
                if (isLoading) {
                  CircularProgressIndicator(
                    color = Color.Black,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(24.dp)
                  )
                } else {
                  Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.Black,
                    modifier = Modifier.size(32.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.width(16.dp))

              IconButton(
                onClick = { WorkoutMusicManager.nextTrack(context) },
                modifier = Modifier.size(48.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.SkipNext,
                  contentDescription = "Next",
                  tint = Color.White,
                  modifier = Modifier.size(28.dp)
                )
              }
            }
          }
        }

        // 2. Playlist Selection header
        Text(
          text = "CHOOSE YOUR TRAINING STATION",
          style = MaterialTheme.typography.labelSmall,
          color = BentoTextSecondary,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp,
          modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
        )

        // Track Listing with active item indicator
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          itemsIndexed(WORKOUT_TRACKS) { index, track ->
            val isActive = index == activeTrackIndex
            val trackColor = if (isActive) NeonLime else Color.White

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(if (isActive) Color(0xFF1A1D2B) else Color(0xFF14161F))
                .border(
                  width = 1.dp,
                  color = if (isActive) NeonLime.copy(alpha = 0.5f) else Color(0xFF262938),
                  shape = RoundedCornerShape(12.dp)
                )
                .clickable {
                  WorkoutMusicManager.playTrack(context, index)
                }
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
              ) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .background(
                      if (isActive) NeonLime.copy(alpha = 0.15f) else Color(0xFF222636),
                      CircleShape
                    ),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = if (isActive && isPlaying) Icons.Default.GraphicEq else Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = if (isActive) NeonLime else Color.LightGray,
                    modifier = Modifier.size(16.dp)
                  )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                  Text(
                    text = track.title,
                    color = trackColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                  Text(
                    text = "${track.artist} · ${track.genre}",
                    color = BentoTextSecondary,
                    fontSize = 10.sp
                  )
                }
              }

              Text(
                text = track.duration,
                color = BentoTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun WorkoutMusicStickyWidget(
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val activeTrackIndex by WorkoutMusicManager.currentTrackIndex.collectAsState()
  val isPlaying by WorkoutMusicManager.isPlaying.collectAsState()
  val currentTrack = WORKOUT_TRACKS[activeTrackIndex]

  var showMusicDeckDialog by remember { mutableStateOf(false) }

  Row(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(Color(0xFF14161F))
      .border(1.dp, Color(0xFF262938), RoundedCornerShape(14.dp))
      .clickable { showMusicDeckDialog = true }
      .padding(horizontal = 12.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.weight(1f)
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .background(NeonLime.copy(alpha = 0.15f), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.MusicNote,
          contentDescription = null,
          tint = NeonLime,
          modifier = Modifier.size(18.dp)
        )
      }

      Spacer(modifier = Modifier.width(10.dp))

      Column {
        Text(
          text = currentTrack.title,
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = if (isPlaying) "Playing now" else "Paused",
          color = BentoTextSecondary,
          fontSize = 10.sp
        )
      }
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(
        onClick = { WorkoutMusicManager.togglePlayPause(context) },
        modifier = Modifier.size(32.dp)
      ) {
        Icon(
          imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
          contentDescription = "Play/Pause",
          tint = NeonLime,
          modifier = Modifier.size(20.dp)
        )
      }
    }

    if (showMusicDeckDialog) {
      WorkoutMusicPlayerDialog(
        onDismiss = { showMusicDeckDialog = false }
      )
    }
  }
}
