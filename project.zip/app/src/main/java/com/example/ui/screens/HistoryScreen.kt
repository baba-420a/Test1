package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.WorkoutSession
import com.example.ui.FitnessViewModel
import com.example.ui.components.StatMetricBox
import com.example.ui.components.StatusBadge
import com.example.ui.components.StylizedCard
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.BentoIceBlue
import com.example.ui.theme.BentoIceBlueDark
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EnergyAmber
import com.example.ui.theme.NeonLime
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
  viewModel: FitnessViewModel,
  onNavigateBack: () -> Unit,
  onSessionClicked: (Long) -> Unit,
  modifier: Modifier = Modifier
) {
  val allSessions by viewModel.allSessions.collectAsStateWithLifecycle()
  val badges by viewModel.achievementBadges.collectAsStateWithLifecycle()
  var selectedFilterIndex by remember { mutableStateOf(0) }
  val filterOptions = listOf("All", "Squats", "Push-ups", "Bicep Curls")
  var selectedBadgeForDetail by remember { mutableStateOf<com.example.ui.models.AchievementBadge?>(null) }

  var sessionToDelete by remember { mutableStateOf<WorkoutSession?>(null) }

  val filteredSessions = remember(allSessions, selectedFilterIndex) {
    if (selectedFilterIndex == 0) {
      allSessions
    } else {
      val filterName = filterOptions[selectedFilterIndex]
      allSessions.filter { it.exerciseName.equals(filterName, ignoreCase = true) }
    }
  }

  val totalReps = allSessions.sumOf { it.correctReps }
  val totalSessions = allSessions.size
  val avgScore = if (allSessions.isNotEmpty()) allSessions.map { it.averageFormScore }.average().toInt() else 0

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 18.dp),
    contentPadding = PaddingValues(top = 20.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onNavigateBack,
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = MaterialTheme.colorScheme.onSurface
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = "TRAINING LOG",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Black,
            color = NeonLime,
            letterSpacing = 1.sp
          )
          Text(
            text = "Workout History",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.onBackground
          )
        }
      }
    }

    // Stats Overview Row
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        StatMetricBox(
          label = "Total Reps",
          value = "$totalReps",
          accentColor = NeonLime,
          modifier = Modifier.weight(1f)
        )
        StatMetricBox(
          label = "Sessions",
          value = "$totalSessions",
          accentColor = ElectricCyan,
          modifier = Modifier.weight(1f)
        )
        StatMetricBox(
          label = "Avg Form",
          value = if (avgScore > 0) "$avgScore%" else "—",
          accentColor = EnergyAmber,
          modifier = Modifier.weight(1f)
        )
      }
    }

    // Achievement Badges Horizontal Section
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "CHAMPION BADGES",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Black,
              color = NeonLime,
              letterSpacing = 1.sp
            )
            Text(
              text = "Milestones & Achievements",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Black,
              color = MaterialTheme.colorScheme.onBackground
            )
          }
          Text(
            text = "${badges.count { it.isUnlocked }}/${badges.size} Unlocked",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = BentoIceBlue,
            modifier = Modifier
              .background(BentoIceBlue.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyRow(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(14.dp),
          contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
          items(badges) { badge ->
            val iconVec = when (badge.iconName) {
              "fitness_center" -> Icons.Default.FitnessCenter
              "star" -> Icons.Default.Star
              "emoji_events" -> Icons.Default.EmojiEvents
              "local_fire_department" -> Icons.Default.LocalFireDepartment
              "local_drink" -> Icons.Default.LocalDrink
              "restaurant" -> Icons.Default.Restaurant
              else -> Icons.Default.EmojiEvents
            }

            val badgeColor = when (badge.category) {
              "WORKOUT" -> NeonLime
              "STREAK" -> EnergyAmber
              "HYDRATION" -> ElectricCyan
              "NUTRITION" -> AlertCoral
              else -> NeonLime
            }

            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier
                .width(76.dp)
                .clickable { selectedBadgeForDetail = badge }
            ) {
              Box(
                modifier = Modifier
                  .size(60.dp)
                  .clip(CircleShape)
                  .background(
                    if (badge.isUnlocked) badgeColor.copy(alpha = 0.2f)
                    else Color(0xFF161A26)
                  )
                  .border(
                    width = if (badge.isUnlocked) 2.dp else 1.dp,
                    color = if (badge.isUnlocked) badgeColor else Color(0xFF2B3045),
                    shape = CircleShape
                  ),
                contentAlignment = Alignment.Center
              ) {
                if (badge.isUnlocked) {
                  Icon(
                    imageVector = iconVec,
                    contentDescription = badge.title,
                    tint = badgeColor,
                    modifier = Modifier.size(24.dp)
                  )
                } else {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(
                      imageVector = iconVec,
                      contentDescription = badge.title,
                      tint = Color(0xFF4C526E),
                      modifier = Modifier.size(20.dp)
                    )
                    Box(
                      modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.15f))
                    )
                    Icon(
                      imageVector = Icons.Default.Lock,
                      contentDescription = "Locked",
                      tint = Color(0xFF7A829E),
                      modifier = Modifier
                        .size(12.dp)
                        .align(Alignment.BottomEnd)
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = badge.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (badge.isUnlocked) Color.White else Color(0xFF828A9E),
                textAlign = TextAlign.Center,
                maxLines = 1
              )
            }
          }
        }
      }
    }

    // Filter Pill Chips
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        filterOptions.forEachIndexed { index, option ->
          val isSelected = selectedFilterIndex == index
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(16.dp))
              .background(if (isSelected) BentoIceBlue else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
              .clickable { selectedFilterIndex = index }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = option,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) BentoIceBlueDark else MaterialTheme.colorScheme.onSurfaceVariant,
              fontSize = 11.sp
            )
          }
        }
      }
    }

    // List of Sessions
    if (filteredSessions.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.FitnessCenter,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "No recorded sessions",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "Workouts completed with live pose detection will appear here.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(filteredSessions) { session ->
        val sdf = SimpleDateFormat("MMM dd, yyyy · hh:mm a", Locale.getDefault())
        val formattedDate = sdf.format(Date(session.startTime))
        val min = session.durationSeconds / 60
        val sec = session.durationSeconds % 60

        StylizedCard(
          onClick = { onSessionClicked(session.id) }
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = session.exerciseName,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Black,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(8.dp))
                StatusBadge(
                  text = "${session.averageFormScore}% FORM",
                  color = if (session.averageFormScore >= 75) NeonLime else EnergyAmber
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = formattedDate,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "${session.correctReps} valid reps · ${session.rejectedReps} rejected · ${String.format(Locale.getDefault(), "%02d:%02d", min, sec)} · ${session.estimatedCalories.toInt()} kcal",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold
              )
            }

            IconButton(
              onClick = { sessionToDelete = session },
              modifier = Modifier.testTag("delete_session_${session.id}")
            ) {
              Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Delete",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }
    }
  }

  // Delete Confirmation Dialog
  sessionToDelete?.let { session ->
    AlertDialog(
      onDismissRequest = { sessionToDelete = null },
      title = { Text("Delete Session?") },
      text = { Text("Are you sure you want to remove this ${session.exerciseName} workout record? This action cannot be undone.") },
      confirmButton = {
        TextButton(
          onClick = {
            viewModel.deleteSession(session.id)
            sessionToDelete = null
          }
        ) {
          Text("Delete", color = AlertCoral)
        }
      },
      dismissButton = {
        TextButton(onClick = { sessionToDelete = null }) {
          Text("Cancel")
        }
      }
    )
  }

  // Achievement Detail Dialog
  selectedBadgeForDetail?.let { badge ->
    val iconVec = when (badge.iconName) {
      "fitness_center" -> Icons.Default.FitnessCenter
      "star" -> Icons.Default.Star
      "emoji_events" -> Icons.Default.EmojiEvents
      "local_fire_department" -> Icons.Default.LocalFireDepartment
      "local_drink" -> Icons.Default.LocalDrink
      "restaurant" -> Icons.Default.Restaurant
      else -> Icons.Default.EmojiEvents
    }

    val badgeColor = when (badge.category) {
      "WORKOUT" -> NeonLime
      "STREAK" -> EnergyAmber
      "HYDRATION" -> ElectricCyan
      "NUTRITION" -> AlertCoral
      else -> NeonLime
    }

    AlertDialog(
      onDismissRequest = { selectedBadgeForDetail = null },
      title = null,
      text = {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Large glowing icon circle
          Box(
            modifier = Modifier
              .size(80.dp)
              .clip(CircleShape)
              .background(
                if (badge.isUnlocked) badgeColor.copy(alpha = 0.15f)
                else Color(0xFF1E212B)
              )
              .border(
                width = 3.dp,
                color = if (badge.isUnlocked) badgeColor else Color(0xFF2B3045),
                shape = CircleShape
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = iconVec,
              contentDescription = badge.title,
              tint = if (badge.isUnlocked) badgeColor else Color(0xFF555973),
              modifier = Modifier.size(40.dp)
            )
          }

          Spacer(modifier = Modifier.height(20.dp))

          Text(
            text = badge.title.uppercase(),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black,
            color = Color.White,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = if (badge.isUnlocked) "UNLOCKED ⚡" else "LOCKED 🔒",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (badge.isUnlocked) badgeColor else Color(0xFF7A829E)
          )

          Spacer(modifier = Modifier.height(16.dp))

          Text(
            text = badge.description,
            style = MaterialTheme.typography.bodyMedium,
            color = Color.LightGray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
          )

          Spacer(modifier = Modifier.height(20.dp))

          // Progress Card
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF14161F))
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Requirements",
                  style = MaterialTheme.typography.labelMedium,
                  color = Color.LightGray,
                  fontWeight = FontWeight.SemiBold
                )
                Text(
                  text = badge.currentProgressText,
                  style = MaterialTheme.typography.labelMedium,
                  color = if (badge.isUnlocked) badgeColor else Color.White,
                  fontWeight = FontWeight.Bold
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              LinearProgressIndicator(
                progress = badge.progress,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(6.dp)
                  .clip(RoundedCornerShape(3.dp)),
                color = badgeColor,
                trackColor = Color(0xFF222636)
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Criteria: ${badge.unlockCriteria}",
                fontSize = 11.sp,
                color = Color.Gray,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }
      },
      confirmButton = {
        TextButton(
          onClick = { selectedBadgeForDetail = null },
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("GOT IT", fontWeight = FontWeight.Black, color = badgeColor)
        }
      },
      dismissButton = null,
      containerColor = Color(0xFF0C0D11),
      shape = RoundedCornerShape(20.dp)
    )
  }
}
