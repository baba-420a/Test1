package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val BentoDarkColorScheme = darkColorScheme(
  primary = BentoIceBlue,
  onPrimary = BentoIceBlueDark,
  primaryContainer = BentoSlateBlue,
  onPrimaryContainer = BentoSlateLight,
  secondary = BentoSlateLight,
  onSecondary = BentoDarkBackground,
  secondaryContainer = BentoGraphite,
  onSecondaryContainer = BentoIceBlue,
  tertiary = BentoBlushPink,
  onTertiary = BentoBlushDark,
  tertiaryContainer = Color(0xFF3B2830),
  onTertiaryContainer = BentoBlushPink,
  error = AlertCoral,
  onError = AlertCoralDark,
  errorContainer = Color(0xFF4A1A24),
  onErrorContainer = AlertCoral,
  background = BentoDarkBackground,
  onBackground = BentoTextPrimary,
  surface = BentoDarkSurface,
  onSurface = BentoTextPrimary,
  surfaceVariant = BentoDarkSurfaceVariant,
  onSurfaceVariant = BentoTextSecondary,
  outline = BentoDarkBorder,
  outlineVariant = Color(0xFF37383E)
)

private val BentoLightColorScheme = lightColorScheme(
  primary = Color(0xFF1E6091),
  onPrimary = Color.White,
  primaryContainer = BentoIceBlue,
  onPrimaryContainer = BentoIceBlueDark,
  secondary = BentoSlateBlue,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFD8E4F2),
  onSecondaryContainer = BentoIceBlueDark,
  tertiary = Color(0xFF7D4E5C),
  onTertiary = Color.White,
  tertiaryContainer = Color(0xFFFFD8E4),
  onTertiaryContainer = BentoBlushDark,
  error = Color(0xFFBA1A1A),
  onError = Color.White,
  errorContainer = Color(0xFFFFDAD6),
  onErrorContainer = Color(0xFF410002),
  background = LightBackground,
  onBackground = LightTextPrimary,
  surface = LightSurface,
  onSurface = LightTextPrimary,
  surfaceVariant = LightSurfaceVariant,
  onSurfaceVariant = LightTextSecondary,
  outline = LightBorder,
  outlineVariant = Color(0xFFDEE3EC)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Enforce Bento Grid styling consistency
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> BentoDarkColorScheme
    else -> BentoLightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
