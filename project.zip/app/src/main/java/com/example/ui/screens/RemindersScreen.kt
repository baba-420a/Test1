package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.Reminder
import com.example.ui.FitnessViewModel
import com.example.ui.components.StylizedCard
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonLime

@Composable
fun RemindersScreen(
  viewModel: FitnessViewModel,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val reminders by viewModel.allReminders.collectAsStateWithLifecycle()
  var showAddDialog by remember { mutableStateOf(false) }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = MaterialTheme.colorScheme.background,
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.testTag("add_reminder_fab")
      ) {
        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Alarm")
      }
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 18.dp),
      contentPadding = PaddingValues(top = 20.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = MaterialTheme.colorScheme.onSurface
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = "DAILY SCHEDULE",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Black,
              color = NeonLime,
              letterSpacing = 1.sp
            )
            Text(
              text = "Workout Alarms",
              style = MaterialTheme.typography.headlineMedium,
              fontWeight = FontWeight.Black,
              color = MaterialTheme.colorScheme.onBackground
            )
          }
        }
      }

      item {
        StylizedCard(borderColor = ElectricCyan.copy(alpha = 0.35f)) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(ElectricCyan.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.NotificationsActive,
                contentDescription = null,
                tint = ElectricCyan,
                modifier = Modifier.size(24.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Keep Your Streak Alive",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "Scheduled local notifications remind you when it's time to train.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      if (reminders.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = Icons.Default.Alarm,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp)
              )
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "No alarms configured",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "Tap the + button to schedule your workout reminder.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      } else {
        items(reminders) { reminder ->
          ReminderItemCard(
            reminder = reminder,
            onToggle = { viewModel.toggleReminder(reminder) },
            onTest = { viewModel.testReminderNotification(reminder) },
            onDelete = { viewModel.deleteReminder(reminder.id) }
          )
        }
      }
    }
  }

  if (showAddDialog) {
    AddReminderDialog(
      onDismiss = { showAddDialog = false },
      onConfirm = { title, hour, minute, days ->
        viewModel.addReminder(title, hour, minute, days)
        showAddDialog = false
      }
    )
  }
}

@Composable
fun ReminderItemCard(
  reminder: Reminder,
  onToggle: () -> Unit,
  onTest: () -> Unit,
  onDelete: () -> Unit
) {
  StylizedCard {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = reminder.timeFormatted,
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Black,
            color = if (reminder.isEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
          )
          Text(
            text = reminder.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (reminder.isEnabled) NeonLime else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Switch(
          checked = reminder.isEnabled,
          onCheckedChange = { onToggle() },
          colors = SwitchDefaults.colors(
            checkedThumbColor = Color(0xFF041E0F),
            checkedTrackColor = NeonLime
          )
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = reminder.daysOfWeek,
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          TextButton(onClick = onTest) {
            Text(
              text = "Test Alarm",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = ElectricCyan
            )
          }

          IconButton(onClick = onDelete) {
            Icon(
              imageVector = Icons.Default.Delete,
              contentDescription = "Delete",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
fun AddReminderDialog(
  onDismiss: () -> Unit,
  onConfirm: (title: String, hour: Int, minute: Int, days: String) -> Unit
) {
  var title by remember { mutableStateOf("Daily Calisthenics") }
  var hour by remember { mutableIntStateOf(8) }
  var minute by remember { mutableIntStateOf(0) }
  var isPm by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Set Workout Reminder", fontWeight = FontWeight.Bold) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Alarm Title") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Text("Select Time", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Hour Stepper
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            TextButton(onClick = { hour = if (hour == 12) 1 else hour + 1 }) { Text("+") }
            Text(String.format(java.util.Locale.getDefault(), "%02d", hour), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            TextButton(onClick = { hour = if (hour == 1) 12 else hour - 1 }) { Text("-") }
          }
          Text(":", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
          // Minute Stepper
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            TextButton(onClick = { minute = (minute + 5) % 60 }) { Text("+") }
            Text(String.format(java.util.Locale.getDefault(), "%02d", minute), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            TextButton(onClick = { minute = if (minute < 5) 55 else minute - 5 }) { Text("-") }
          }
          // AM / PM Toggle
          Button(
            onClick = { isPm = !isPm },
            colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = Color(0xFF041E0F)),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text(if (isPm) "PM" else "AM", fontWeight = FontWeight.Black)
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val actualHour = when {
            isPm && hour < 12 -> hour + 12
            !isPm && hour == 12 -> 0
            else -> hour
          }
          onConfirm(title, actualHour, minute, "Mon,Tue,Wed,Thu,Fri,Sat,Sun")
        },
        colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = Color(0xFF041E0F)),
        shape = RoundedCornerShape(10.dp)
      ) {
        Text("Save Alarm", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
