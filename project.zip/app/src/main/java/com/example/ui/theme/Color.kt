package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// PUMPD Premium Dark Aesthetic (Inspired by PUMPD Reference System)
val PumpdObsidian = Color(0xFF0B0C10)
val PumpdCardBg = Color(0xFF14161E)
val PumpdCardElevated = Color(0xFF1E212B)
val PumpdBorder = Color(0xFF262936)
val PumpdBorderLight = Color(0xFF363A4B)
val PumpdCrimson = Color(0xFFE5383B)
val PumpdCrimsonGlow = Color(0x40E5383B)
val PumpdDarkRedGlow = Color(0x55380811)
val PumpdEmerald = Color(0xFF34D399)
val PumpdAmber = Color(0xFFF59E0B)
val PumpdWhite = Color(0xFFFFFFFF)
val PumpdTextPrimary = Color(0xFFF8FAFC)
val PumpdTextSecondary = Color(0xFF94A3B8)
val PumpdTextMuted = Color(0xFF64748B)

// Bento Grid Design Theme Palette (Retained for backward compatibility)
val BentoDarkBackground = PumpdObsidian
val BentoDarkSurface = PumpdCardBg
val BentoDarkSurfaceVariant = PumpdCardElevated
val BentoDarkBorder = PumpdBorder
val BentoTextPrimary = PumpdTextPrimary
val BentoTextSecondary = PumpdTextSecondary
val BentoTextMuted = PumpdTextMuted

// Bento Distinct Box Fills & Accent Tokens
val BentoIceBlue = Color(0xFFD1E4FF)
val BentoIceBlueDark = Color(0xFF001D36)
val BentoSlateBlue = Color(0xFF1E2430)
val BentoSlateLight = Color(0xFF94A3B8)
val BentoGraphite = Color(0xFF1A1C24)
val BentoBlushPink = Color(0xFFE5383B)
val BentoBlushDark = Color(0xFF380811)
val BentoSageGreen = Color(0xFF34D399)
val BentoSageDark = Color(0xFF063323)
val BentoAmber = Color(0xFFF59E0B)
val BentoAmberDark = Color(0xFF451A03)

// Core Semantic Brand Mappings
val NeonLime = PumpdEmerald
val NeonLimeDark = Color(0xFF063323)
val ElectricCyan = Color(0xFF38BDF8)
val ElectricCyanDark = Color(0xFF0C4A6E)
val EnergyAmber = PumpdAmber
val EnergyAmberDark = Color(0xFF451A03)
val AlertCoral = PumpdCrimson
val AlertCoralDark = Color(0xFF380811)

// Dark Mode Palette
val DarkBackground = PumpdObsidian
val DarkSurface = PumpdCardBg
val DarkSurfaceVariant = PumpdCardElevated
val DarkSurfaceElevated = Color(0xFF232734)
val DarkBorder = PumpdBorder
val DarkTextPrimary = PumpdTextPrimary
val DarkTextSecondary = PumpdTextSecondary
val DarkTextMuted = PumpdTextMuted

// Light Mode Palette
val LightBackground = Color(0xFFF2F4F8)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E7F0)
val LightSurfaceElevated = Color(0xFFFFFFFF)
val LightBorder = Color(0xFFCBD3E1)
val LightTextPrimary = Color(0xFF111318)
val LightTextSecondary = Color(0xFF5C6069)
val LightTextMuted = Color(0xFF888E9B)

// Pose & HUD Specific Colors
val PoseJointValid = Color(0xFFD1E4FF)
val PoseJointWarning = Color(0xFFFFD180)
val PoseJointInvalid = Color(0xFFEFB8C8)
val PoseBoneValid = Color(0xDDD1E4FF)
val PoseBoneInvalid = Color(0xDDEFB8C8)
val HudOverlayBg = Color(0xDD111318)
val GlowLime = Color(0x40D1E4FF)
val GlowCyan = Color(0x40BBC7DB)
val StreakFire = Color(0xFFFFB74D)
