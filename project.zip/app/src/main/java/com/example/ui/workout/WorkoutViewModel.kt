package com.example.ui.workout

import android.app.Application
import androidx.camera.core.CameraSelector
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.NotificationHelper
import com.example.data.local.FitnessDatabase
import com.example.data.local.entity.WorkoutSession
import com.example.data.repository.FitnessRepository
import com.example.pose.engine.RepStateMachine
import com.example.pose.engine.WorkoutLiveState
import com.example.pose.model.ExerciseType
import com.example.pose.model.PoseFrame
import com.example.pose.simulation.PoseSimulator
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class SetKind(val label: String) {
  WARMUP("WU"),
  WORKING("WRK"),
  DROPSET("DS")
}

data class ExerciseSet(
  val id: Int,
  val setNumber: Int,
  val kind: SetKind = SetKind.WORKING,
  val weightKg: Float = 65f,
  val reps: Int = 10,
  val rpe: Int = 7,
  val isCompleted: Boolean = false
)

class WorkoutViewModel(
  application: Application,
  val exerciseType: ExerciseType
) : AndroidViewModel(application) {

  private val database = FitnessDatabase.getDatabase(application, viewModelScope)
  private val repository = FitnessRepository(database.fitnessDao())
  private val notificationHelper = NotificationHelper(application)

  private val repStateMachine = RepStateMachine(
    exerciseType = exerciseType,
    minFormScoreThreshold = 70,
    onCueTriggered = { isSuccess, _ ->
      notificationHelper.playTone(isSuccess)
      notificationHelper.vibrate(isSuccess)
    }
  )

  val liveState: StateFlow<WorkoutLiveState> = repStateMachine.state

  private val _elapsedSeconds = MutableStateFlow(0)
  val elapsedSeconds: StateFlow<Int> = _elapsedSeconds.asStateFlow()

  private val _isPaused = MutableStateFlow(false)
  val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

  private val _isSimulationMode = MutableStateFlow(false)
  val isSimulationMode: StateFlow<Boolean> = _isSimulationMode.asStateFlow()

  private val _isArCameraMode = MutableStateFlow(false)
  val isArCameraMode: StateFlow<Boolean> = _isArCameraMode.asStateFlow()

  private val _currentFrame = MutableStateFlow<PoseFrame?>(null)
  val currentFrame: StateFlow<PoseFrame?> = _currentFrame.asStateFlow()

  private val _cameraLensFacing = MutableStateFlow(CameraSelector.LENS_FACING_FRONT)
  val cameraLensFacing: StateFlow<Int> = _cameraLensFacing.asStateFlow()

  // Sets state matching PUMPD Reference Set Logger (IMG-20260904-WA0002)
  private val _sets = MutableStateFlow(
    listOf(
      ExerciseSet(id = 1, setNumber = 1, kind = SetKind.WARMUP, weightKg = 65f, reps = 10, rpe = 7, isCompleted = true),
      ExerciseSet(id = 2, setNumber = 2, kind = SetKind.WORKING, weightKg = 65f, reps = 10, rpe = 7, isCompleted = false),
      ExerciseSet(id = 3, setNumber = 3, kind = SetKind.DROPSET, weightKg = 65f, reps = 10, rpe = 7, isCompleted = false)
    )
  )
  val sets: StateFlow<List<ExerciseSet>> = _sets.asStateFlow()

  private val _notes = MutableStateFlow("Felt really good on this session — form was crisp and core locked in!")
  val notes: StateFlow<String> = _notes.asStateFlow()

  // Rest Timer State
  private val _restSecondsRemaining = MutableStateFlow(69)
  val restSecondsRemaining: StateFlow<Int> = _restSecondsRemaining.asStateFlow()

  private val _isRestTimerActive = MutableStateFlow(true)
  val isRestTimerActive: StateFlow<Boolean> = _isRestTimerActive.asStateFlow()

  private val _isRestTimerPaused = MutableStateFlow(false)
  val isRestTimerPaused: StateFlow<Boolean> = _isRestTimerPaused.asStateFlow()

  private var restJob: Job? = null

  private val poseSimulator = PoseSimulator(exerciseType)
  private val _simulationFlaw = MutableStateFlow(PoseSimulator.FormFlawMode.PERFECT)
  val simulationFlaw: StateFlow<PoseSimulator.FormFlawMode> = _simulationFlaw.asStateFlow()

  private var timerJob: Job? = null
  private var simulationJob: Job? = null
  private val startTime = System.currentTimeMillis()

  init {
    startTimer()
    startSimulationLoop()
    startRestTimerInternal()
  }

  private fun startTimer() {
    timerJob?.cancel()
    timerJob = viewModelScope.launch {
      while (isActive) {
        delay(1000)
        if (!_isPaused.value) {
          _elapsedSeconds.value += 1
        }
      }
    }
  }

  private fun startSimulationLoop() {
    simulationJob?.cancel()
    simulationJob = viewModelScope.launch {
      while (isActive) {
        delay(40) // ~25 FPS
        if (!_isPaused.value && _isSimulationMode.value) {
          val frame = poseSimulator.nextFrame()
          _currentFrame.value = frame
          repStateMachine.processFrame(frame)
        }
      }
    }
  }

  private fun startRestTimerInternal() {
    restJob?.cancel()
    restJob = viewModelScope.launch {
      while (isActive) {
        delay(1000)
        if (_isRestTimerActive.value && !_isRestTimerPaused.value && _restSecondsRemaining.value > 0) {
          _restSecondsRemaining.value -= 1
        }
      }
    }
  }

  fun toggleSetCompleted(setId: Int) {
    val current = _sets.value.toMutableList()
    val index = current.indexOfFirst { it.id == setId }
    if (index != -1) {
      val target = current[index]
      val newCompleted = !target.isCompleted
      current[index] = target.copy(isCompleted = newCompleted)
      _sets.value = current
      if (newCompleted) {
        notificationHelper.playTone(true)
        notificationHelper.vibrate(true)
        // Auto trigger rest timer
        _restSecondsRemaining.value = 90
        _isRestTimerActive.value = true
        _isRestTimerPaused.value = false
      }
    }
  }

  fun addSet() {
    val current = _sets.value
    val nextNumber = current.size + 1
    val lastWeight = current.lastOrNull()?.weightKg ?: 65f
    val lastReps = current.lastOrNull()?.reps ?: 10
    val newSet = ExerciseSet(
      id = (current.maxOfOrNull { it.id } ?: 0) + 1,
      setNumber = nextNumber,
      kind = SetKind.WORKING,
      weightKg = lastWeight,
      reps = lastReps,
      rpe = 7,
      isCompleted = false
    )
    _sets.value = current + newSet
  }

  fun updateSetWeight(setId: Int, delta: Float) {
    val current = _sets.value.toMutableList()
    val index = current.indexOfFirst { it.id == setId }
    if (index != -1) {
      val target = current[index]
      val newWeight = (target.weightKg + delta).coerceAtLeast(0f)
      current[index] = target.copy(weightKg = newWeight)
      _sets.value = current
    }
  }

  fun updateSetReps(setId: Int, delta: Int) {
    val current = _sets.value.toMutableList()
    val index = current.indexOfFirst { it.id == setId }
    if (index != -1) {
      val target = current[index]
      val newReps = (target.reps + delta).coerceAtLeast(1)
      current[index] = target.copy(reps = newReps)
      _sets.value = current
    }
  }

  fun updateSetRpe(setId: Int, rpe: Int) {
    val current = _sets.value.toMutableList()
    val index = current.indexOfFirst { it.id == setId }
    if (index != -1) {
      current[index] = current[index].copy(rpe = rpe)
      _sets.value = current
    }
  }

  fun updateNotes(notes: String) {
    _notes.value = notes
  }

  fun toggleArCameraMode() {
    _isArCameraMode.value = !_isArCameraMode.value
  }

  fun skipRest() {
    _isRestTimerActive.value = false
    _restSecondsRemaining.value = 0
  }

  fun addRestTime(seconds: Int = 15) {
    _restSecondsRemaining.value += seconds
    _isRestTimerActive.value = true
  }

  fun toggleRestTimerPause() {
    _isRestTimerPaused.value = !_isRestTimerPaused.value
  }

  fun togglePause() {
    _isPaused.value = !_isPaused.value
  }

  fun toggleCameraLens() {
    _cameraLensFacing.value = if (_cameraLensFacing.value == CameraSelector.LENS_FACING_FRONT) {
      CameraSelector.LENS_FACING_BACK
    } else {
      CameraSelector.LENS_FACING_FRONT
    }
  }

  fun toggleSimulationMode(enabled: Boolean) {
    _isSimulationMode.value = enabled
    if (enabled) {
      poseSimulator.formFlawMode = _simulationFlaw.value
    }
  }

  fun setSimulationFlaw(flaw: PoseSimulator.FormFlawMode) {
    _simulationFlaw.value = flaw
    poseSimulator.formFlawMode = flaw
  }

  fun onCameraFrameReceived(frame: PoseFrame) {
    if (!_isSimulationMode.value && !_isPaused.value) {
      _currentFrame.value = frame
      repStateMachine.processFrame(frame)
    }
  }

  fun finishWorkout(onSaved: (sessionId: Long) -> Unit) {
    viewModelScope.launch {
      val state = liveState.value
      val endTime = System.currentTimeMillis()
      val durationSec = _elapsedSeconds.value
      val calories = state.correctReps * exerciseType.caloriesPerRep

      val session = WorkoutSession(
        exerciseName = exerciseType.displayName,
        startTime = startTime,
        endTime = endTime,
        durationSeconds = durationSec,
        totalReps = state.totalReps,
        correctReps = state.correctReps,
        rejectedReps = state.rejectedReps,
        averageFormScore = state.averageFormScore,
        estimatedCalories = calories,
        notes = "Completed with ${state.correctReps} valid reps and ${state.averageFormScore}% avg form score."
      )

      val id = repository.saveCompletedSession(session, state.repEvents)
      onSaved(id)
    }
  }

  override fun onCleared() {
    super.onCleared()
    timerJob?.cancel()
    simulationJob?.cancel()
    notificationHelper.release()
  }
}
