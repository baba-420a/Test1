package com.example.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.pose.model.ExerciseType
import com.example.ui.FitnessViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExerciseLibraryScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.LiveWorkoutScreen
import com.example.ui.screens.RemindersScreen
import com.example.ui.screens.SessionSummaryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BentoIceBlue
import com.example.ui.theme.BentoIceBlueDark
import com.example.ui.theme.BentoTextSecondary
import com.example.ui.theme.NeonLime
import com.example.ui.workout.WorkoutViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
  object Dashboard : Screen("dashboard", "Home", Icons.Default.Home)
  object Reminders : Screen("reminders", "Plan", Icons.Default.Alarm)
  object History : Screen("history", "Stats", Icons.Default.History)
  object Settings : Screen("settings", "Profile", Icons.Default.Settings)
  object Library : Screen("library", "Exercises", Icons.AutoMirrored.Filled.MenuBook)
}

@Composable
fun AppNavigation(
  fitnessViewModel: FitnessViewModel,
  navController: NavHostController = rememberNavController()
) {
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route

  val bottomNavItems = listOf(
    Screen.Dashboard,
    Screen.Reminders,
    Screen.History,
    Screen.Settings
  )

  val isBottomNavVisible = bottomNavItems.any { it.route == currentRoute } || currentRoute == Screen.Library.route

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = MaterialTheme.colorScheme.background,
    bottomBar = {
      AnimatedVisibility(
        visible = isBottomNavVisible,
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it })
      ) {
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
          shape = RoundedCornerShape(36.dp),
          color = Color(0xFF12141C),
          shadowElevation = 16.dp,
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Color(0xFF262938)
          )
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
          ) {
            // 1. Home
            val isHome = currentRoute == Screen.Dashboard.route
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier
                .clickable {
                  if (!isHome) {
                    navController.navigate(Screen.Dashboard.route) {
                      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                      launchSingleTop = true
                      restoreState = true
                    }
                  }
                }
                .padding(vertical = 4.dp, horizontal = 8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Home,
                contentDescription = "Home",
                tint = if (isHome) Color.White else Color(0xFF7A8194),
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "Home",
                fontWeight = if (isHome) FontWeight.Bold else FontWeight.Medium,
                fontSize = 10.sp,
                color = if (isHome) Color.White else Color(0xFF7A8194)
              )
            }

            // 2. Plan
            val isPlan = currentRoute == Screen.Reminders.route
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier
                .clickable {
                  if (!isPlan) {
                    navController.navigate(Screen.Reminders.route) {
                      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                      launchSingleTop = true
                      restoreState = true
                    }
                  }
                }
                .padding(vertical = 4.dp, horizontal = 8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Alarm,
                contentDescription = "Plan",
                tint = if (isPlan) Color.White else Color(0xFF7A8194),
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "Plan",
                fontWeight = if (isPlan) FontWeight.Bold else FontWeight.Medium,
                fontSize = 10.sp,
                color = if (isPlan) Color.White else Color(0xFF7A8194)
              )
            }

            // 3. Center "P" Brand Action Button (Matching IMG-20260904-WA0003)
            Box(
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Color.White)
                .clickable {
                  navController.navigate("workout/SQUATS")
                },
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "P",
                fontWeight = FontWeight.Black,
                color = Color.Black,
                fontSize = 22.sp
              )
            }

            // 4. Stats
            val isStats = currentRoute == Screen.History.route
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier
                .clickable {
                  if (!isStats) {
                    navController.navigate(Screen.History.route) {
                      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                      launchSingleTop = true
                      restoreState = true
                    }
                  }
                }
                .padding(vertical = 4.dp, horizontal = 8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.History,
                contentDescription = "Stats",
                tint = if (isStats) Color.White else Color(0xFF7A8194),
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "Stats",
                fontWeight = if (isStats) FontWeight.Bold else FontWeight.Medium,
                fontSize = 10.sp,
                color = if (isStats) Color.White else Color(0xFF7A8194)
              )
            }

            // 5. Profile
            val isProfile = currentRoute == Screen.Settings.route
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier
                .clickable {
                  if (!isProfile) {
                    navController.navigate(Screen.Settings.route) {
                      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                      launchSingleTop = true
                      restoreState = true
                    }
                  }
                }
                .padding(vertical = 4.dp, horizontal = 8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Profile",
                tint = if (isProfile) Color.White else Color(0xFF7A8194),
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "Profile",
                fontWeight = if (isProfile) FontWeight.Bold else FontWeight.Medium,
                fontSize = 10.sp,
                color = if (isProfile) Color.White else Color(0xFF7A8194)
              )
            }
          }
        }
      }
    }
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = Screen.Dashboard.route,
      modifier = Modifier
        .fillMaxSize()
        .padding(bottom = if (isBottomNavVisible) innerPadding.calculateBottomPadding() else 0.dp)
    ) {
      // 1. Dashboard
      composable(Screen.Dashboard.route) {
        DashboardScreen(
          viewModel = fitnessViewModel,
          onStartWorkout = { exercise ->
            navController.navigate("workout/${exercise.name}")
          },
          onNavigateToHistory = {
            navController.navigate(Screen.History.route)
          },
          onNavigateToReminders = {
            navController.navigate(Screen.Reminders.route)
          },
          onNavigateToExercises = {
            navController.navigate(Screen.Library.route)
          },
          onNavigateToSettings = {
            navController.navigate(Screen.Settings.route)
          }
        )
      }

      // 2. Exercise Library
      composable(Screen.Library.route) {
        ExerciseLibraryScreen(
          onStartExercise = { exercise ->
            navController.navigate("workout/${exercise.name}")
          },
          onNavigateBack = {
            navController.popBackStack()
          }
        )
      }

      // 3. History
      composable(Screen.History.route) {
        HistoryScreen(
          viewModel = fitnessViewModel,
          onNavigateBack = {
            navController.popBackStack()
          },
          onSessionClicked = { sessionId ->
            navController.navigate("summary/$sessionId")
          }
        )
      }

      // 4. Reminders
      composable(Screen.Reminders.route) {
        RemindersScreen(
          viewModel = fitnessViewModel,
          onNavigateBack = {
            navController.popBackStack()
          }
        )
      }

      // 5. Settings
      composable(Screen.Settings.route) {
        SettingsScreen(
          viewModel = fitnessViewModel,
          onNavigateBack = {
            navController.popBackStack()
          }
        )
      }

      // 6. Live Workout (Fullscreen)
      composable(
        route = "workout/{exerciseType}",
        arguments = listOf(navArgument("exerciseType") { type = NavType.StringType })
      ) { backStackEntry ->
        val exerciseTypeName = backStackEntry.arguments?.getString("exerciseType") ?: ExerciseType.SQUATS.name
        val exerciseType = try {
          ExerciseType.valueOf(exerciseTypeName)
        } catch (e: Exception) {
          ExerciseType.SQUATS
        }

        val app = androidx.compose.ui.platform.LocalContext.current.applicationContext as android.app.Application
        val workoutViewModel: WorkoutViewModel = viewModel(
          key = "workout_$exerciseTypeName",
          factory = object : androidx.lifecycle.ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
              return WorkoutViewModel(app, exerciseType) as T
            }
          }
        )

        LiveWorkoutScreen(
          viewModel = workoutViewModel,
          onNavigateBack = {
            navController.popBackStack()
          },
          onFinishWorkout = { sessionId ->
            navController.navigate("summary/$sessionId") {
              popUpTo("workout/{exerciseType}") {
                inclusive = true
              }
            }
          }
        )
      }

      // 7. Workout Summary
      composable(
        route = "summary/{sessionId}",
        arguments = listOf(navArgument("sessionId") { type = NavType.LongType })
      ) { backStackEntry ->
        val sessionId = backStackEntry.arguments?.getLong("sessionId") ?: 0L
        SessionSummaryScreen(
          sessionId = sessionId,
          viewModel = fitnessViewModel,
          onNavigateHome = {
            navController.navigate(Screen.Dashboard.route) {
              popUpTo(Screen.Dashboard.route) { inclusive = true }
            }
          }
        )
      }
    }
  }
}
