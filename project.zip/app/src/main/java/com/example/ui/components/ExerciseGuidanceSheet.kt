package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.pose.model.ExerciseType
import com.example.ui.theme.PumpdAmber
import com.example.ui.theme.PumpdBorder
import com.example.ui.theme.PumpdBorderLight
import com.example.ui.theme.PumpdCardBg
import com.example.ui.theme.PumpdCardElevated
import com.example.ui.theme.PumpdCrimson
import com.example.ui.theme.PumpdEmerald
import com.example.ui.theme.PumpdObsidian
import com.example.ui.theme.PumpdTextMuted
import com.example.ui.theme.PumpdTextPrimary
import com.example.ui.theme.PumpdTextSecondary
import com.example.ui.theme.PumpdWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExerciseGuidanceSheet(
  exercise: ExerciseType,
  onDismiss: () -> Unit,
  onStartWorkout: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var isAudioMuted by remember { mutableStateOf(false) }
  var isPlaying by remember { mutableStateOf(true) }
  var showPipCamera by remember { mutableStateOf(true) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = PumpdObsidian,
    contentColor = PumpdTextPrimary,
    dragHandle = null,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp)
        .padding(bottom = 36.dp)
    ) {
      // Top handle & actions row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 16.dp, bottom = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = { isAudioMuted = !isAudioMuted },
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(PumpdCardElevated)
        ) {
          Icon(
            imageVector = if (isAudioMuted) Icons.Default.VolumeDown else Icons.Default.VolumeUp,
            contentDescription = "Audio Toggle",
            tint = PumpdTextSecondary,
            modifier = Modifier.size(18.dp)
          )
        }

        // Center drag handle
        Box(
          modifier = Modifier
            .width(44.dp)
            .height(4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(PumpdBorderLight)
        )

        IconButton(
          onClick = onDismiss,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(PumpdCardElevated)
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close",
            tint = PumpdTextSecondary,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      // Tags Row: Category, Form Guidance, Difficulty
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          // Category Pill (Red)
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .background(PumpdCrimson.copy(alpha = 0.15f))
              .border(1.dp, PumpdCrimson.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
              .padding(horizontal = 10.dp, vertical = 5.dp)
          ) {
            Text(
              text = when (exercise) {
                ExerciseType.SQUATS -> "LOWER BODY & GLUTES"
                ExerciseType.PUSHUPS -> "CHEST, SHOULDERS, TRICEPS"
                ExerciseType.BICEP_CURLS -> "ARMS & BICEPS"
              },
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = PumpdCrimson,
              fontSize = 9.sp,
              letterSpacing = 0.5.sp
            )
          }

          // Form Guidance Pill (Green)
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .background(PumpdEmerald.copy(alpha = 0.15f))
              .border(1.dp, PumpdEmerald.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
              .padding(horizontal = 10.dp, vertical = 5.dp)
          ) {
            Text(
              text = "FORM GUIDANCE",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = PumpdEmerald,
              fontSize = 9.sp,
              letterSpacing = 0.5.sp
            )
          }
        }

        // Difficulty tag on the right
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "DIFFICULTY",
            style = MaterialTheme.typography.labelSmall,
            color = PumpdTextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = exercise.difficulty.replaceFirstChar { it.uppercase() },
            style = MaterialTheme.typography.labelSmall,
            color = PumpdAmber,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Exercise Title
      Text(
        text = exercise.displayName,
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Black,
        color = PumpdTextPrimary,
        letterSpacing = (-0.5).sp
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Video & Live AI Check Player Container
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(230.dp)
          .clip(RoundedCornerShape(20.dp))
          .background(PumpdCardBg)
          .border(1.dp, PumpdBorder, RoundedCornerShape(20.dp))
      ) {
        // Hero Tutorial Image
        Image(
          painter = painterResource(id = R.drawable.img_ab_wheel_rollout),
          contentDescription = exercise.displayName,
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )

        // Dark gradient vignette
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                listOf(
                  Color.Black.copy(alpha = 0.35f),
                  Color.Transparent,
                  Color.Black.copy(alpha = 0.85f)
                )
              )
            )
        )

        // Top-left status pill: Live AI Form Checks Active
        val transition = rememberInfiniteTransition(label = "pulse")
        val alphaAnim by transition.animateFloat(
          initialValue = 0.4f,
          targetValue = 1.0f,
          animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
          ),
          label = "pulseAlpha"
        )

        Box(
          modifier = Modifier
            .padding(12.dp)
            .align(Alignment.TopStart)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = 0.65f))
            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Box(
              modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(PumpdEmerald.copy(alpha = alphaAnim))
            )
            Text(
              text = "Live AI Form Checks: Active",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = PumpdTextPrimary,
              fontSize = 10.sp
            )
          }
        }

        // Center Play Button Overlay
        Box(
          modifier = Modifier
            .align(Alignment.Center)
            .size(52.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.65f))
            .border(1.5.dp, Color.White.copy(alpha = 0.5f), CircleShape)
            .clickable { isPlaying = !isPlaying },
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = "Play Tutorial",
            tint = PumpdWhite,
            modifier = Modifier.size(28.dp)
          )
        }

        // Floating PIP window: Live AR Skeleton Tracker
        androidx.compose.animation.AnimatedVisibility(
          visible = showPipCamera,
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(bottom = 14.dp, end = 10.dp)
        ) {
          Box(
            modifier = Modifier
              .width(170.dp)
              .height(95.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(Color(0xFF13141B).copy(alpha = 0.95f))
              .border(1.dp, PumpdCrimson.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
              .padding(6.dp)
          ) {
            Column(
              modifier = Modifier.fillMaxSize(),
              verticalArrangement = Arrangement.SpaceBetween
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  Box(
                    modifier = Modifier
                      .size(5.dp)
                      .clip(CircleShape)
                      .background(PumpdEmerald)
                  )
                  Text(
                    text = "LIVE 60fps",
                    style = MaterialTheme.typography.labelSmall,
                    color = PumpdTextSecondary,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                  )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  Icon(
                    imageVector = Icons.Default.FlipCameraAndroid,
                    contentDescription = null,
                    tint = PumpdTextMuted,
                    modifier = Modifier.size(11.dp)
                  )
                  Icon(
                    imageVector = Icons.Default.Fullscreen,
                    contentDescription = null,
                    tint = PumpdTextMuted,
                    modifier = Modifier.size(11.dp)
                  )
                }
              }

              // Mini simulated pose angle visualizer
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(vertical = 4.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "Spine 4° Dev",
                    style = MaterialTheme.typography.labelSmall,
                    color = PumpdEmerald,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                  )
                }

                Box(
                  modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(PumpdCrimson.copy(alpha = 0.25f))
                    .border(0.5.dp, PumpdCrimson.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    .padding(vertical = 4.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "Fix Pelvis",
                    style = MaterialTheme.typography.labelSmall,
                    color = PumpdCrimson,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }
          }
        }

        // Bottom Red Scrub Progress Bar
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(3.dp)
            .align(Alignment.BottomCenter)
            .background(Color.White.copy(alpha = 0.2f))
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth(0.58f)
              .height(3.dp)
              .background(PumpdCrimson)
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // ESSENTIAL EXECUTION CUES Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Check,
            contentDescription = null,
            tint = PumpdCrimson,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = "ESSENTIAL EXECUTION CUES",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Black,
            color = PumpdTextPrimary,
            letterSpacing = 0.8.sp,
            fontSize = 11.sp
          )
        }

        Text(
          text = "3 Key Steps",
          style = MaterialTheme.typography.labelSmall,
          color = PumpdTextMuted,
          fontSize = 10.sp
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Execution Cues Cards
      val cues = when (exercise) {
        ExerciseType.SQUATS -> listOf(
          Triple("1", "Pelvic & Spine Neutrality", "Brace your core like taking a punch; maintain chest proud and avoid lower back rounding at the bottom."),
          Triple("2", "Knee Tracking & Hip Depth", "Drive knees outwards in line with toes, descending until hip crease reaches or breaks knee parallel."),
          Triple("3", "Breathing & Ascent Drive", "Inhale deep diaphragmatic breath before eccentric descent; push through midfoot and exhale on explosive drive up.")
        )
        ExerciseType.PUSHUPS -> listOf(
          Triple("1", "Plank & Core Tension", "Engage glutes and quads; keep your body in a rigid straight line with no hip sagging."),
          Triple("2", "Elbow Tuck Angle", "Tuck elbows at roughly 45 degrees to protect shoulders; lower chest until 2 inches from the floor."),
          Triple("3", "Controlled Tempo", "Control the descent in 2 seconds; aggressively push through the palms to lock out cleanly at top.")
        )
        ExerciseType.BICEP_CURLS -> listOf(
          Triple("1", "Elbow Pinning", "Keep upper arms glued perpendicular to your torso; avoid swinging the elbows forward."),
          Triple("2", "Full Range of Motion", "Curl up until biceps reach peak contraction, then lower fully to eccentric stretch."),
          Triple("3", "Strict Tempo & Wrist Neutrality", "Do not rock or hyperextend wrists; breathe out smoothly during concentric contraction.")
        )
      }

      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        cues.forEach { (step, title, description) ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PumpdCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, PumpdBorder)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              verticalAlignment = Alignment.Top
            ) {
              Box(
                modifier = Modifier
                  .size(24.dp)
                  .clip(CircleShape)
                  .background(PumpdEmerald.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = step,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Black,
                  color = PumpdEmerald,
                  fontSize = 11.sp
                )
              }

              Column {
                Text(
                  text = title,
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = PumpdTextPrimary,
                  fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = description,
                  style = MaterialTheme.typography.bodySmall,
                  color = PumpdTextSecondary,
                  fontSize = 11.sp,
                  lineHeight = 15.sp
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // BIOMECHANICAL ACTIVATION Header
      Text(
        text = "BIOMECHANICAL ACTIVATION",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Black,
        color = PumpdTextMuted,
        letterSpacing = 0.8.sp,
        fontSize = 10.sp
      )

      Spacer(modifier = Modifier.height(8.dp))

      // 3 Activation Cards
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        val (m1, m2, m3) = when (exercise) {
          ExerciseType.SQUATS -> Triple(
            Pair("Quadriceps", "95% Prime"),
            Pair("Glutes & Hamstrings", "85% Assisting"),
            Pair("Core Stabilizer", "Active")
          )
          ExerciseType.PUSHUPS -> Triple(
            Pair("Pectoralis Major", "92% Prime"),
            Pair("Triceps & Deltoids", "82% Assisting"),
            Pair("Anterior Core", "Active")
          )
          ExerciseType.BICEP_CURLS -> Triple(
            Pair("Biceps Brachii", "96% Prime"),
            Pair("Brachialis & Forearms", "78% Assisting"),
            Pair("Posture Guard", "Active")
          )
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(PumpdCardBg)
            .border(1.dp, PumpdBorder, RoundedCornerShape(12.dp))
            .padding(vertical = 10.dp, horizontal = 8.dp)
        ) {
          Column {
            Text(text = m1.first, style = MaterialTheme.typography.labelSmall, color = PumpdTextMuted, fontSize = 9.sp, maxLines = 1)
            Spacer(modifier = Modifier.height(3.dp))
            Row {
              val parts = m1.second.split(" ")
              Text(text = parts[0] + " ", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PumpdTextPrimary, fontSize = 10.sp)
              Text(text = parts.getOrNull(1) ?: "", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PumpdEmerald, fontSize = 10.sp)
            }
          }
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(PumpdCardBg)
            .border(1.dp, PumpdBorder, RoundedCornerShape(12.dp))
            .padding(vertical = 10.dp, horizontal = 8.dp)
        ) {
          Column {
            Text(text = m2.first, style = MaterialTheme.typography.labelSmall, color = PumpdTextMuted, fontSize = 9.sp, maxLines = 1)
            Spacer(modifier = Modifier.height(3.dp))
            Row {
              val parts = m2.second.split(" ")
              Text(text = parts[0] + " ", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PumpdTextPrimary, fontSize = 10.sp)
              Text(text = parts.getOrNull(1) ?: "", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PumpdWhite, fontSize = 10.sp)
            }
          }
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(PumpdCardBg)
            .border(1.dp, PumpdBorder, RoundedCornerShape(12.dp))
            .padding(vertical = 10.dp, horizontal = 8.dp)
        ) {
          Column {
            Text(text = m3.first, style = MaterialTheme.typography.labelSmall, color = PumpdTextMuted, fontSize = 9.sp, maxLines = 1)
            Spacer(modifier = Modifier.height(3.dp))
            Text(text = m3.second, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PumpdEmerald, fontSize = 10.sp)
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Solid White Pill Button: Start Workout
      Button(
        onClick = {
          onDismiss()
          onStartWorkout()
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp),
        shape = RoundedCornerShape(26.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = PumpdWhite,
          contentColor = Color.Black
        )
      ) {
        Text(
          text = "Start Training",
          fontWeight = FontWeight.Black,
          fontSize = 15.sp,
          letterSpacing = 0.5.sp
        )
      }
    }
  }
}
