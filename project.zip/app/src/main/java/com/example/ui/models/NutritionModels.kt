package com.example.ui.models

data class LoggedFood(
  val id: String,
  val name: String,
  val calories: Int,
  val protein: Int,
  val carbs: Int,
  val fat: Int,
  val timestamp: Long,
  val imageUrl: String? = null
)

data class AchievementBadge(
  val id: String,
  val title: String,
  val description: String,
  val category: String, // "WORKOUT", "HYDRATION", "NUTRITION", "STREAK"
  val iconName: String, // e.g. "fitness_center", "local_drink", "restaurant", "star"
  val unlockCriteria: String,
  val isUnlocked: Boolean = false,
  val progress: Float = 0f, // 0.0f to 1.0f
  val currentProgressText: String = ""
)
