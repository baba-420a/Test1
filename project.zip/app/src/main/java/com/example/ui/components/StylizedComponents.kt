package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.BentoDarkBorder
import com.example.ui.theme.BentoDarkSurface
import com.example.ui.theme.BentoGraphite
import com.example.ui.theme.BentoIceBlue
import com.example.ui.theme.BentoIceBlueDark
import com.example.ui.theme.BentoSlateBlue
import com.example.ui.theme.BentoSlateLight
import com.example.ui.theme.BentoTextMuted
import com.example.ui.theme.BentoTextPrimary
import com.example.ui.theme.BentoTextSecondary
import com.example.ui.theme.EnergyAmber

import androidx.compose.ui.graphics.Brush

// Bento Grid Base Card with 28dp capsule curves
@Composable
fun StylizedCard(
  modifier: Modifier = Modifier,
  containerColor: Color = MaterialTheme.colorScheme.surface,
  borderColor: Color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
  onClick: (() -> Unit)? = null,
  content: @Composable () -> Unit
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
  ) {
    content()
  }
}

// Bento Hero Card (Clean gradient background, high-contrast display typography, segmented goal indicator)
@Composable
fun BentoHeroCard(
  title: String,
  scoreValue: String,
  statusBadgeText: String,
  currentSegment: Int,
  totalSegments: Int = 4,
  metricSubtext: String,
  onClick: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          Brush.linearGradient(
            colors = listOf(
              Color(0xFFD8E7FF),
              Color(0xFFBAD8FF)
            )
          )
        )
        .padding(22.dp)
    ) {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        // Top row: Label & pulse indicator
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top
        ) {
          Column {
            Text(
              text = title.uppercase(),
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = BentoIceBlueDark.copy(alpha = 0.75f),
              letterSpacing = 1.2.sp,
              fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.Bottom) {
              Text(
                text = scoreValue,
                style = MaterialTheme.typography.displayLarge,
                fontWeight = FontWeight.Light,
                color = BentoIceBlueDark,
                fontSize = 54.sp,
                lineHeight = 56.sp
              )
              Text(
                text = " / 100",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = BentoIceBlueDark.copy(alpha = 0.5f),
                modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
              )
            }
          }

          // Pulse pill with subtle status tag
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .background(Color.White.copy(alpha = 0.5f))
              .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
              .padding(horizontal = 12.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .background(BentoIceBlueDark, CircleShape)
              )
              Text(
                text = statusBadgeText.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = BentoIceBlueDark,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Bottom row: Segmented goal bar & subtext
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Bottom
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = "DAILY TARGET PROGRESS",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = BentoIceBlueDark.copy(alpha = 0.7f),
              letterSpacing = 1.sp,
              fontSize = 10.sp
            )
            BentoSegmentedBars(
              currentSegment = currentSegment,
              totalSegments = totalSegments,
              activeColor = BentoIceBlueDark,
              inactiveColor = BentoIceBlueDark.copy(alpha = 0.18f)
            )
          }

          Text(
            text = metricSubtext,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = BentoIceBlueDark.copy(alpha = 0.85f),
            fontSize = 12.sp
          )
        }
      }
    }
  }
}

// Bento Segmented Progress Bar
@Composable
fun BentoSegmentedBars(
  currentSegment: Int,
  totalSegments: Int = 4,
  activeColor: Color = BentoIceBlueDark,
  inactiveColor: Color = BentoIceBlueDark.copy(alpha = 0.2f)
) {
  Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
    for (i in 0 until totalSegments) {
      val isFilled = i < currentSegment
      Box(
        modifier = Modifier
          .width(32.dp)
          .height(6.dp)
          .clip(RoundedCornerShape(3.dp))
          .background(if (isFilled) activeColor else inactiveColor)
      )
    }
  }
}

// Bento Split Card (Tactile modular bento cells with rounded corners & clean icons)
@Composable
fun BentoSplitCard(
  title: String,
  value: String,
  containerColor: Color,
  iconContainerColor: Color,
  iconColor: Color,
  icon: ImageVector,
  modifier: Modifier = Modifier,
  onClick: (() -> Unit)? = null
) {
  Card(
    modifier = modifier
      .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
    shape = RoundedCornerShape(26.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(iconContainerColor),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconColor,
            modifier = Modifier.size(20.dp)
          )
        }

        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowForward,
          contentDescription = null,
          tint = Color.White.copy(alpha = 0.3f),
          modifier = Modifier.size(16.dp)
        )
      }

      Spacer(modifier = Modifier.height(18.dp))

      Column {
        Text(
          text = value,
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
          color = BentoTextPrimary,
          fontSize = 24.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = title,
          style = MaterialTheme.typography.bodySmall,
          color = BentoTextSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }
  }
}

// Bento Action / Feature Row Card (e.g. Next Session card: #1c1b1f border #49454f with #efb8c8 chip)
@Composable
fun BentoActionCard(
  badgeText: String,
  title: String,
  subtitle: String,
  accentColor: Color,
  accentDarkColor: Color,
  icon: ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clickable { onClick() },
    shape = RoundedCornerShape(26.dp),
    colors = CardDefaults.cardColors(containerColor = BentoDarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, BentoDarkBorder)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Box(
          modifier = Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(accentColor),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentDarkColor,
            modifier = Modifier.size(26.dp)
          )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column {
          Text(
            text = badgeText.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = BentoTextSecondary,
            letterSpacing = 0.5.sp,
            fontSize = 10.sp
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = BentoTextPrimary,
            fontSize = 16.sp
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = accentColor,
            fontSize = 12.sp
          )
        }
      }

      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = "Open",
        tint = BentoTextSecondary,
        modifier = Modifier.size(20.dp)
      )
    }
  }
}

@Composable
fun StatMetricBox(
  label: String,
  value: String,
  accentColor: Color,
  icon: ImageVector? = null,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(20.dp))
      .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
      .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
      .padding(horizontal = 14.dp, vertical = 12.dp)
  ) {
    Column {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        if (icon != null) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(16.dp)
          )
        }
        Text(
          text = label.uppercase(),
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.8.sp,
          fontSize = 10.sp
        )
      }
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }
  }
}

@Composable
fun CircularScoreDial(
  score: Int,
  sizeDp: Int = 100,
  strokeWidthDp: Int = 10,
  modifier: Modifier = Modifier
) {
  val animatedProgress by animateFloatAsState(
    targetValue = (score / 100f).coerceIn(0f, 1f),
    animationSpec = tween(durationMillis = 600),
    label = "scoreProgress"
  )

  val color = when {
    score >= 80 -> BentoIceBlue
    score >= 60 -> EnergyAmber
    else -> AlertCoral
  }

  Box(
    contentAlignment = Alignment.Center,
    modifier = modifier.size(sizeDp.dp)
  ) {
    CircularProgressIndicator(
      progress = { 1f },
      modifier = Modifier.fillMaxWidth(),
      color = MaterialTheme.colorScheme.surfaceVariant,
      strokeWidth = strokeWidthDp.dp,
      trackColor = Color.Transparent,
      strokeCap = StrokeCap.Round
    )
    CircularProgressIndicator(
      progress = { animatedProgress },
      modifier = Modifier.fillMaxWidth(),
      color = color,
      strokeWidth = strokeWidthDp.dp,
      trackColor = Color.Transparent,
      strokeCap = StrokeCap.Round
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = "$score%",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = "SCORE",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 9.sp,
        letterSpacing = 1.sp
      )
    }
  }
}

@Composable
fun StatusBadge(
  text: String,
  color: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = color.copy(alpha = 0.16f),
    border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f)),
    modifier = modifier
  ) {
    Text(
      text = text,
      color = color,
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.5.sp,
      fontSize = 11.sp,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
    )
  }
}

// PUMPD Welcome Hero Banner (Matching IMG-20260904-WA0001 & WA0005)
@Composable
fun PumpdWelcomeHeroCard(
  onStartWorkout: () -> Unit,
  onOpenGuidance: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(26.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFF14161F)),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF262936))
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(310.dp)
    ) {
      // Hero Image
      androidx.compose.foundation.Image(
        painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_pumpd_welcome_hero),
        contentDescription = "PUMPD Coach",
        modifier = Modifier.fillMaxSize(),
        contentScale = androidx.compose.ui.layout.ContentScale.Crop
      )

      // Crimson & Obsidian Gradient Overlay
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              listOf(
                Color.Black.copy(alpha = 0.45f),
                Color(0x70380811),
                Color(0xFF0C0D11).copy(alpha = 0.95f)
              )
            )
          )
      )

      // Content inside Hero
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(18.dp),
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        // Top Badges: 250+ Exercises & Personalized Plans
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(14.dp))
              .background(Color.Black.copy(alpha = 0.55f))
              .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text(
              text = "250+ Exercises",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              fontSize = 10.sp
            )
          }

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(14.dp))
              .background(Color.Black.copy(alpha = 0.55f))
              .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text(
              text = "Personalized Plans",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              fontSize = 10.sp
            )
          }
        }

        // Bottom Logo, Subtitle & Dual Action Buttons
        Column(modifier = Modifier.fillMaxWidth()) {
          // PUMPD Brand Header
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.White),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "P",
                fontWeight = FontWeight.Black,
                color = Color.Black,
                fontSize = 16.sp
              )
            }

            Text(
              text = "PUMPD",
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Black,
              color = Color.White,
              letterSpacing = 1.sp
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Your AI coach for smarter training and real progress.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFFBBC7DB),
            fontSize = 12.sp,
            lineHeight = 16.sp
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Action Buttons: Solid White Pill & Dark Translucent Pill
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Box(
              modifier = Modifier
                .weight(1.2f)
                .height(44.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White)
                .clickable { onStartWorkout() },
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "Start Training",
                fontWeight = FontWeight.Black,
                color = Color.Black,
                fontSize = 12.sp
              )
            }

            Box(
              modifier = Modifier
                .weight(1f)
                .height(44.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White.copy(alpha = 0.12f))
                .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(22.dp))
                .clickable { onOpenGuidance() },
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "AI Form Check",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 12.sp
              )
            }
          }
        }
      }
    }
  }
}

