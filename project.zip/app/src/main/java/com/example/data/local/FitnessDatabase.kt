package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.FitnessDao
import com.example.data.local.entity.DailyStats
import com.example.data.local.entity.Reminder
import com.example.data.local.entity.RepEvent
import com.example.data.local.entity.UserProfile
import com.example.data.local.entity.WorkoutSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    UserProfile::class,
    WorkoutSession::class,
    RepEvent::class,
    DailyStats::class,
    Reminder::class
  ],
  version = 1,
  exportSchema = false
)
abstract class FitnessDatabase : RoomDatabase() {

  abstract fun fitnessDao(): FitnessDao

  companion object {
    @Volatile
    private var INSTANCE: FitnessDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): FitnessDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          FitnessDatabase::class.java,
          "fitness_master.db"
        )
        .addCallback(DatabaseCallback(scope))
        .fallbackToDestructiveMigration(false)
        .build()
        INSTANCE = instance
        instance
      }
    }

    private class DatabaseCallback(
      private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          scope.launch {
            val dao = database.fitnessDao()
            // Prepopulate initial profile
            dao.insertOrUpdateProfile(
              UserProfile(
                id = 1,
                name = "Athlete",
                fitnessLevel = "Intermediate",
                dailyGoalReps = 50,
                darkModePreference = "DARK", // Default to stylized dark mode for best readability
                soundEnabled = true,
                hapticEnabled = true,
                mirrorCamera = true,
                minFormScore = 70
              )
            )

            // Prepopulate default reminders
            dao.insertReminder(
              Reminder(
                title = "Morning Calisthenics",
                timeFormatted = "07:30 AM",
                hour = 7,
                minute = 30,
                daysOfWeek = "Mon,Tue,Wed,Thu,Fri",
                isEnabled = true
              )
            )
            dao.insertReminder(
              Reminder(
                title = "Evening Core & Strength",
                timeFormatted = "06:00 PM",
                hour = 18,
                minute = 0,
                daysOfWeek = "Mon,Wed,Fri,Sat",
                isEnabled = true
              )
            )
          }
        }
      }
    }
  }
}
