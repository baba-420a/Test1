package com.example.data.repository

import com.example.data.local.dao.FitnessDao
import com.example.data.local.entity.DailyStats
import com.example.data.local.entity.Reminder
import com.example.data.local.entity.RepEvent
import com.example.data.local.entity.UserProfile
import com.example.data.local.entity.WorkoutSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class FitnessRepository(private val dao: FitnessDao) {

  val userProfile: Flow<UserProfile?> = dao.getUserProfile()

  val allSessions: Flow<List<WorkoutSession>> = dao.getAllSessions()

  val recentSessions: Flow<List<WorkoutSession>> = dao.getRecentSessions(10)

  val allReminders: Flow<List<Reminder>> = dao.getAllReminders()

  fun getSession(id: Long): Flow<WorkoutSession?> = dao.getSessionById(id)

  fun getRepEvents(sessionId: Long): Flow<List<RepEvent>> = dao.getRepEventsForSession(sessionId)

  fun getTodayDateString(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    return sdf.format(Date())
  }

  val todayStats: Flow<DailyStats?> = dao.getStatsForDate(getTodayDateString())

  val recentDailyStats: Flow<List<DailyStats>> = dao.getRecentDailyStats(7)

  // Calculate consecutive workout days streak
  val currentStreak: Flow<Int> = dao.getAllDailyStats().map { allStats ->
    calculateConsecutiveStreak(allStats)
  }

  suspend fun updateProfile(profile: UserProfile) = withContext(Dispatchers.IO) {
    dao.insertOrUpdateProfile(profile)
  }

  suspend fun saveCompletedSession(
    session: WorkoutSession,
    events: List<RepEvent>
  ): Long = withContext(Dispatchers.IO) {
    val sessionId = dao.insertSession(session)
    val eventsWithSessionId = events.map { it.copy(sessionId = sessionId) }
    dao.insertRepEvents(eventsWithSessionId)

    // Update DailyStats for today
    val today = getTodayDateString()
    val existingStats = dao.getStatsForDateDirect(today) ?: DailyStats(dateString = today)
    val updatedStats = existingStats.copy(
      workoutCount = existingStats.workoutCount + 1,
      totalReps = existingStats.totalReps + session.totalReps,
      correctReps = existingStats.correctReps + session.correctReps,
      rejectedReps = existingStats.rejectedReps + session.rejectedReps,
      estimatedCalories = existingStats.estimatedCalories + session.estimatedCalories,
      activeMinutes = existingStats.activeMinutes + (session.durationSeconds / 60).coerceAtLeast(1)
    )
    dao.insertOrUpdateDailyStats(updatedStats)

    sessionId
  }

  suspend fun deleteSession(id: Long) = withContext(Dispatchers.IO) {
    dao.deleteSessionById(id)
  }

  suspend fun addReminder(reminder: Reminder): Long = withContext(Dispatchers.IO) {
    dao.insertReminder(reminder)
  }

  suspend fun updateReminder(reminder: Reminder) = withContext(Dispatchers.IO) {
    dao.updateReminder(reminder)
  }

  suspend fun deleteReminder(id: Long) = withContext(Dispatchers.IO) {
    dao.deleteReminderById(id)
  }

  private fun calculateConsecutiveStreak(allStats: List<DailyStats>): Int {
    if (allStats.isEmpty()) return 0
    val activeDates = allStats
      .filter { it.workoutCount > 0 || it.totalReps > 0 }
      .map { it.dateString }
      .toSet()

    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val calendar = Calendar.getInstance()

    var streak = 0
    // Check today first. If no workout today yet, check if yesterday was worked out
    var checkDate = sdf.format(calendar.time)
    val workedOutToday = activeDates.contains(checkDate)

    if (workedOutToday) {
      streak++
      calendar.add(Calendar.DAY_OF_YEAR, -1)
    } else {
      // Check yesterday to maintain streak if today is in progress
      calendar.add(Calendar.DAY_OF_YEAR, -1)
      val workedOutYesterday = activeDates.contains(sdf.format(calendar.time))
      if (!workedOutYesterday) {
        return 0
      }
    }

    while (true) {
      checkDate = sdf.format(calendar.time)
      if (activeDates.contains(checkDate)) {
        streak++
        calendar.add(Calendar.DAY_OF_YEAR, -1)
      } else {
        break
      }
    }
    return streak
  }
}
