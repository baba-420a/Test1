package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.DailyStats
import com.example.data.local.entity.Reminder
import com.example.data.local.entity.RepEvent
import com.example.data.local.entity.UserProfile
import com.example.data.local.entity.WorkoutSession
import kotlinx.coroutines.flow.Flow

@Dao
interface FitnessDao {

  // User Profile
  @Query("SELECT * FROM user_profile WHERE id = 1")
  fun getUserProfile(): Flow<UserProfile?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateProfile(profile: UserProfile)

  // Workout Sessions
  @Query("SELECT * FROM workout_sessions ORDER BY startTime DESC")
  fun getAllSessions(): Flow<List<WorkoutSession>>

  @Query("SELECT * FROM workout_sessions WHERE id = :id")
  fun getSessionById(id: Long): Flow<WorkoutSession?>

  @Query("SELECT * FROM workout_sessions ORDER BY startTime DESC LIMIT :limit")
  fun getRecentSessions(limit: Int): Flow<List<WorkoutSession>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSession(session: WorkoutSession): Long

  @Query("DELETE FROM workout_sessions WHERE id = :id")
  suspend fun deleteSessionById(id: Long)

  // Rep Events
  @Query("SELECT * FROM rep_events WHERE sessionId = :sessionId ORDER BY repNumber ASC")
  fun getRepEventsForSession(sessionId: Long): Flow<List<RepEvent>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRepEvent(repEvent: RepEvent): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRepEvents(repEvents: List<RepEvent>)

  // Daily Stats
  @Query("SELECT * FROM daily_stats WHERE dateString = :dateString")
  fun getStatsForDate(dateString: String): Flow<DailyStats?>

  @Query("SELECT * FROM daily_stats WHERE dateString = :dateString")
  suspend fun getStatsForDateDirect(dateString: String): DailyStats?

  @Query("SELECT * FROM daily_stats ORDER BY dateString DESC LIMIT :limit")
  fun getRecentDailyStats(limit: Int): Flow<List<DailyStats>>

  @Query("SELECT * FROM daily_stats ORDER BY dateString DESC")
  fun getAllDailyStats(): Flow<List<DailyStats>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateDailyStats(stats: DailyStats)

  // Reminders
  @Query("SELECT * FROM reminders ORDER BY hour ASC, minute ASC")
  fun getAllReminders(): Flow<List<Reminder>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReminder(reminder: Reminder): Long

  @Update
  suspend fun updateReminder(reminder: Reminder)

  @Query("DELETE FROM reminders WHERE id = :id")
  suspend fun deleteReminderById(id: Long)
}
