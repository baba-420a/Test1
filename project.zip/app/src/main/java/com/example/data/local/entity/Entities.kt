package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
  @PrimaryKey val id: Int = 1,
  val name: String = "Athlete",
  val fitnessLevel: String = "Intermediate", // Beginner, Intermediate, Advanced
  val dailyGoalReps: Int = 50,
  val darkModePreference: String = "SYSTEM", // SYSTEM, DARK, LIGHT
  val soundEnabled: Boolean = true,
  val hapticEnabled: Boolean = true,
  val mirrorCamera: Boolean = true,
  val minFormScore: Int = 70
)

@Entity(tableName = "workout_sessions")
data class WorkoutSession(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val exerciseName: String, // Squats, Push-ups, Bicep Curls
  val startTime: Long,
  val endTime: Long,
  val durationSeconds: Int,
  val totalReps: Int,
  val correctReps: Int,
  val rejectedReps: Int,
  val averageFormScore: Int,
  val estimatedCalories: Double,
  val notes: String = ""
)

@Entity(tableName = "rep_events")
data class RepEvent(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val sessionId: Long,
  val repNumber: Int,
  val isValid: Boolean,
  val formScore: Int,
  val feedbackMessage: String,
  val timestamp: Long
)

@Entity(tableName = "daily_stats")
data class DailyStats(
  @PrimaryKey val dateString: String, // YYYY-MM-DD
  val workoutCount: Int = 0,
  val totalReps: Int = 0,
  val correctReps: Int = 0,
  val rejectedReps: Int = 0,
  val estimatedCalories: Double = 0.0,
  val activeMinutes: Int = 0
)

@Entity(tableName = "reminders")
data class Reminder(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val timeFormatted: String,
  val hour: Int,
  val minute: Int,
  val daysOfWeek: String, // e.g. "Mon,Tue,Wed,Thu,Fri,Sat,Sun"
  val isEnabled: Boolean = true
)
