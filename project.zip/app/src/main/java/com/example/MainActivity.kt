package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.FitnessViewModel
import com.example.ui.navigation.AppNavigation
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  private val fitnessViewModel: FitnessViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      val userProfile by fitnessViewModel.userProfile.collectAsStateWithLifecycle()

      // Determine theme mode based on user setting
      val systemDark = isSystemInDarkTheme()
      val isDarkTheme = when (userProfile?.darkModePreference) {
        "LIGHT" -> false
        "SYSTEM" -> systemDark
        else -> true // default to stylized Dark Mode
      }

      // Permission handling for Camera and Notifications
      RequestAppPermissions()

      MyApplicationTheme(darkTheme = isDarkTheme) {
        AppNavigation(fitnessViewModel = fitnessViewModel)
      }
    }
  }
}

@Composable
fun RequestAppPermissions() {
  val context = androidx.compose.ui.platform.LocalContext.current

  val permissionsToRequest = buildList {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
      add(Manifest.permission.CAMERA)
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        add(Manifest.permission.POST_NOTIFICATIONS)
      }
    }
  }

  val launcher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestMultiplePermissions()
  ) { /* Permissions granted or denied handled gracefully with fallbacks */ }

  LaunchedEffect(Unit) {
    if (permissionsToRequest.isNotEmpty()) {
      launcher.launch(permissionsToRequest.toTypedArray())
    }
  }
}

