package com.example.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class NotificationHelper(private val context: Context) {

  companion object {
    const val CHANNEL_ID = "fitness_reminders"
    const val CHANNEL_NAME = "Workout Reminders"
    const val NOTIFICATION_ID = 1001
  }

  private var toneGenerator: ToneGenerator? = null

  init {
    createNotificationChannel()
    try {
      toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
    } catch (e: Exception) {
      // Ignored if audio device unavailable
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = "Daily fitness workout reminders & alarms"
        enableVibration(true)
      }
      val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      manager?.createNotificationChannel(channel)
    }
  }

  fun showWorkoutReminder(title: String, body: String) {
    val intent = Intent(context, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val pendingIntent = PendingIntent.getActivity(
      context,
      0,
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val notification = NotificationCompat.Builder(context, CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
      .setContentTitle(title)
      .setContentText(body)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setAutoCancel(true)
      .setContentIntent(pendingIntent)
      .build()

    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    manager?.notify(NOTIFICATION_ID, notification)
  }

  fun playTone(isSuccess: Boolean) {
    try {
      if (isSuccess) {
        // High ascending double tone
        toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
      } else {
        // Low error tone
        toneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 250)
      }
    } catch (e: Exception) {
      // Audio fallback
    }
  }

  fun vibrate(isSuccess: Boolean) {
    try {
      val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
      } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
      }

      vibrator?.let {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          if (isSuccess) {
            it.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
          } else {
            it.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 70, 60, 100), -1))
          }
        } else {
          @Suppress("DEPRECATION")
          it.vibrate(if (isSuccess) 80 else 180)
        }
      }
    } catch (e: Exception) {
      // Haptics fallback
    }
  }

  fun release() {
    toneGenerator?.release()
    toneGenerator = null
  }
}
